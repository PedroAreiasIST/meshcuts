# Code of "Incremental, persistent and concurrent finite element connectivity for mesh cutting and crack growth"

P. Areias and N. Silvestre, Instituto Superior Técnico, Universidade de Lisboa. This package is the part of the
open-source ManyToMany repository (https://github.com/PedroAreiasIST/ManyToMany, GPL-3.0) that the manuscript describes
and measures: the library, the two projects it builds on, the verification and measurement driver, and the scripts behind
the tables and figures. Every file is the version of commit `621e587` ("step2: incremental MM3 connectivity, mesh cutting
and crack insertion", 2026-10-11), except the three figure scripts marked below, which were changed on 2026-10-23 and are
in the working copy of the repository. The data and logs of the runs are not included; the corner-crack EnSight Gold files
are available from the corresponding author on request.

| Folder | Content | Manuscript |
|---|---|---|
| `src/Incremental` | the library `Step2.Core`: persistent arrays, the incremental mesh, the cutter, crack insertion | Sections 2 to 6 |
| `src/Relations` | the MM3 kernel of typed mesh relations, the recomputation baseline | Sections 1, 6, 7 |
| `src/Meshing` | the Steiner-point-free batch cutter and the structured mesh generators | Sections 5, 6 |
| `benchmarks/Step2Bench` | `Step2.Bench`: verification, measurements and the fracture examples | Sections 6 to 8 |
| `benchmarks/Step2` | drivers of the runs (`run-*.sh`, `run-*.sbatch`), log reduction, table and figure scripts | Sections 6 to 8 |

## Library (`src/Incremental`)

| File | Content | Section |
|---|---|---|
| `PArray.cs` | two-level persistent arrays, owner tags, commit, rollback | 4 |
| `IncrementalMesh.cs` | rows, transpose with node positions, gapped pattern with stable slots, destinations, facet adjacency, boundary set, coloring; Algorithm 1 | 2, 3 |
| `Snapshot.cs` | read access to a committed version | 4 |
| `Attributes.cs` | versioned per-element and per-node attributes | 4 |
| `FlatBuild.cs`, `FlatPattern.cs` | the tuned recomputation; the flat copy of the pattern for the solver | 6 |
| `Cutter.cs`, `ParallelCutter.cs` | local cut, revert and concurrent cut; the templates of the batch cutter are `src/Meshing/SubdivisionTemplates.cs` | 5.1, 5.2, 5.4 |
| `CrackInserter.cs` | crack increments from two level sets | 5.3 |
| `ElementSpec.cs` | element types | 2 |

## Build

.NET SDK 9.0.200 (`global.json`), x64. `Step2.Bench` references `Step2.Core` and the `Relations` and `Meshing` projects by
relative paths, so the package builds as unpacked:

```bash
dotnet build benchmarks/Step2Bench -c Release
```

`benchmarks/Step2Bench/run-maxperf.sh <mode> [args]` runs the driver under the conditions of Section 7.1 (pinned to the
physical cores, `STEP2_CPUS`; tiered compilation and ReadyToRun off; server collector without concurrent collection; the
generation-0 budget `STEP2_GEN0`). Results go to the directory `STEP2_DATA`.

## Verification (Sections 6.2 and 6.3)

```bash
./run-maxperf.sh verify-fuzz 3 3000 5 12345     # randomized batches: independent program after every batch, immutability, rollback, destination stability
./run-maxperf.sh verify-work 6                  # crack advance, recursive bisection and erosion with the independent program after every step
./run-maxperf.sh verify-cut 4 9 1               # local cut against the batch cutter
./run-maxperf.sh verify-uncut 4 10 1            # local revert
./run-maxperf.sh verify-crack 8 6 0             # level-set crack insertion
./run-maxperf.sh verify-cutpar 6 8 1 8          # concurrent cut against the sequential cut
./run-maxperf.sh verify-rowlimit 6 20           # a cut that would overflow a pattern row is rejected
./run-maxperf.sh verify-flatbuild 30            # parallel recomputation against the sequential one
```

The randomized runs of the manuscript are `verify-fuzz` with `3 3000 5 12345`, `2 5000 3 1`, `4 2000 20 7`, `5 1000 50 99`
and `3 20000 2 2024` (160 000 edits, 837 rollbacks, 31 000 immutability checks, 6 467 348 destination blocks compared).
The independent program is `Oracle.cs` of `Step2.Bench`.

## Measurements (Section 7) and examples (Section 8)

| Mode of `Step2.Bench` | Table or figure |
|---|---|
| `mm3ref` | the MM3 re-measurement of Section 7.1 |
| `work crack|bisect|erode n` | Table 1, Table 2, Figure 2 (Section 7.2) |
| `crossover`, `interleaved` | Figures 3 and 4 (Sections 7.3, 7.4) |
| `reads`, `concurrent`, `persist`, `memory` | Table 3, Figure 5, Table 4 (Sections 7.5, 7.6) |
| `endtoend`, `profile` | Table 5 (Section 7.7), Table 2 (Section 7.2) |
| `batchcut`, `cutpar`, `cutgc` | Tables 6 and 7, Figure 6 (Section 7.8); `cutgc` is the collector study of Section 7.1 |
| `interfaces` | the concurrent cut of spherical interfaces, not in the manuscript |
| `penny`, `growth`, `surface`, `corner` | Sections 8.2 to 8.5 |

The timed run behind Section 7 is `benchmarks/Step2/run-fin4-timed-amd2.sh` (one measurement at a time on an idle
workstation); `run-fin5` to `run-fin8` are the follow-up controls; `run-cutpar7-deu.sbatch` and `run-pennyctl-deu.sbatch`
are the Deucalion runs. `table_work.py` and `compare_logs.py` reduce the logs to table rows (their data directory, `B` in
`compare_logs.py`, is set to the current folder here).

## Figure scripts (`benchmarks/Step2/figs`)

`make_data.py` and `make_examples.py` with the gnuplot files (`*.gp`) draw the curve figures; `structures.tex` is Figure 1;
`fig_penny_section.py` and `fig_surface_section.py` draw the mesh sections (Xfig); `fig_penny_color.py` and
`fig_surface_color.py` write the crack face as EnSight Gold for the IST Vector Postprocessor and flatten the colour field with
`shading_to_image.py`; `clip_front.py` clips the drawn face at the front curve (new on 2026-10-23, used by the two colour
scripts, which were changed the same day); `fig_corner_color.py` draws the corner-crack sequence of Figure 15, and `corner/`
holds the processing of the EnSight EPS files of Figure 14. `figxfig.py` and `figbuild.py` are the Xfig helpers the section scripts import.
The IST Vector Postprocessor is in-house software and is not included; the EnSight Gold writer the colour scripts import,
`ist_ensight_gold.py`, is a module of that program.

Tested with .NET 9.0.2 on Linux (AMD Ryzen 9 9950X), and on the A64FX and EPYC 7742 nodes of Deucalion.

## License

GPL-3.0, as the repository.
