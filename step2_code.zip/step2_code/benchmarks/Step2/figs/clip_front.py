#!/usr/bin/env python3
"""Clip a triangulated crack face at the front curve (figure helper, 2026-10-23).

The cutter inserts the crack in the region rho < R(psi) + h_min/4, so the drawn upper face ends on mesh nodes up to a
quarter element beyond the front and its outline is a sawtooth. For the figures the face is clipped at the front curve
g(x) = 0 (g < 0 inside), by marching triangles on the UNDEFORMED coordinates: every triangle crossing the curve is cut
along the straight segment between the two zero crossings of g on its edges, and the fields (displacement, opening)
are interpolated linearly to the crossings. The result is the same polygonal face with a boundary that lies exactly on
the curve, as the corner-crack figure already clips its colour at the prescribed front.

    P2, fields2, F2, rim = clip_triangles(P, F, [U, opening], g)

P (n, 3) undeformed node coordinates, F (m, 3) triangles (indices into P), fields: list of (n,) or (n, k) arrays,
g (n,) signed values (inside <= 0). Returns the clipped coordinates, fields, triangles (indices into P2) and a mask of
the vertices created on the curve (the rim), where a field such as the opening is set to its front value by the caller:
the crack front has no jump, and the nodes beyond it that the interpolation would otherwise use are split nodes of the
cutter's crack region, whose small jumps gave the old outline its dark teeth.
"""
import numpy as np


def clip_triangles(P, F, fields, g, eps=1e-12):
    P = np.asarray(P, float)
    F = np.asarray(F, np.int64)
    g = np.asarray(g, float)
    fields = [np.asarray(f, float) for f in fields]
    inside = g <= eps
    n_in = inside[F].sum(axis=1)
    keep = F[n_in == 3]
    cross = F[(n_in == 1) | (n_in == 2)]

    newP, newFields = [P], [[f] for f in fields]
    base = len(P)
    cache = {}

    def crossing(i, j):
        key = (i, j) if i < j else (j, i)
        k = cache.get(key)
        if k is None:
            t = g[i] / (g[i] - g[j])
            t = min(max(t, 0.0), 1.0)
            newP.append((P[i] + t * (P[j] - P[i]))[None])
            for q, f in enumerate(fields):
                newFields[q].append((f[i] + t * (f[j] - f[i]))[None])
            k = base + len(cache)
            cache[key] = k
        return k

    tris = [keep]
    out = []
    for a, b, c in cross:
        v = [a, b, c]
        ins = [inside[x] for x in v]
        # rotate so that the odd vertex (the single inside one, or the single outside one) comes first
        if ins.count(True) == 1:
            k0 = ins.index(True)
        else:
            k0 = ins.index(False)
        v = v[k0:] + v[:k0]
        p0, p1, p2 = v
        if ins.count(True) == 1:  # p0 inside, p1 and p2 outside: one triangle
            q1, q2 = crossing(p0, p1), crossing(p0, p2)
            out.append((p0, q1, q2))
        else:  # p0 outside, p1 and p2 inside: a quadrilateral, two triangles
            q1, q2 = crossing(p0, p1), crossing(p0, p2)
            out.append((q1, p1, p2))
            out.append((q1, p2, q2))
    if out:
        tris.append(np.array(out, np.int64))
    F2 = np.concatenate(tris)
    P2 = np.concatenate(newP)
    fields2 = [np.concatenate(fl) for fl in newFields]
    # drop unreferenced vertices
    used = np.unique(F2)
    remap = np.full(len(P2), -1, np.int64)
    remap[used] = np.arange(len(used))
    rim = used >= len(P)  # vertices created on the curve
    return P2[used], [f[used] for f in fields2], remap[F2], rim
