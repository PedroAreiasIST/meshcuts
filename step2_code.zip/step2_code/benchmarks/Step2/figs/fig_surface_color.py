#!/usr/bin/env python3
"""Colour figure of the semi-elliptical surface crack through the headless IST Vector Postprocessor.

    python3 fig_surface_color.py <dump dir> [stem] [scale] [t] [a] [h] [c]

<dump dir>: nodes.txt, tets.txt, boundary.txt, u.txt (Step2.Bench surface ... dump=<dir>). The crack faces are the
boundary faces off the faces of the plate [-1,1] x [-t,0] x [-h,h]; the upper face (tetrahedra above the crack plane z = 0) is written as EnSight Gold
(figs/ensight/<stem>.case, ist_ensight_gold) with the deformed coordinates (displacements scaled by <scale>) and the
node field "opening", the normal jump [u].n against the partner node across the crack (the other node at the same
undeformed position; front nodes are not split and have none), divided by 8 (1 - nu^2) sigma a / (pi E) as in the
plot of the jump. ISTVectorPostprocessor --headless frames it from its best view and writes the vector PDF
figs/pdf/<stem>.pdf (cropped). Planar sections are drawn in xfig instead (fig_penny_section.py): the headless
export chooses its own view, which is not normal to a plane.
"""
import os
import subprocess
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from clip_front import clip_triangles  # noqa: E402

IVP = os.path.expanduser("~/RiderProjects/Numerical/ISTVectorPostprocessor")
sys.path.insert(0, IVP)
from ist_ensight_gold import write_ensight_gold  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
FIGS = os.path.join(HERE, "..")
EXE = os.path.join(IVP, "csharp/ISTVectorPostprocessor.Desktop/bin/Release/net10.0/linux-x64/ISTVectorPostprocessor")
SIGMA, E, NU = 1.0, 1.0, 0.3


def crack_mask(X, B, t, h):
    """Boundary faces off the faces of the plate."""
    F = B[:, :3]
    onbox = np.zeros(len(F), bool)
    for ax, vals in ((0, (-1.0, 1.0)), (1, (-t, 0.0)), (2, (-h, h))):
        for v in vals:
            onbox |= np.all(np.abs(X[F][:, :, ax] - v) < 1e-12, axis=1)
    return ~onbox


def main():
    d = sys.argv[1]
    stem = sys.argv[2] if len(sys.argv) > 2 else "surface_opening"
    scale = float(sys.argv[3]) if len(sys.argv) > 3 else 0.1
    t = float(sys.argv[4]) if len(sys.argv) > 4 else 1.0
    A = float(sys.argv[5]) if len(sys.argv) > 5 else 0.15
    h = float(sys.argv[6]) if len(sys.argv) > 6 else 2.0
    C = float(sys.argv[7]) if len(sys.argv) > 7 else 0.3
    X = np.loadtxt(os.path.join(d, "nodes.txt"))
    T4 = np.loadtxt(os.path.join(d, "tets.txt"), dtype=np.int64)
    B = np.loadtxt(os.path.join(d, "boundary.txt"), dtype=np.int64)
    U = np.loadtxt(os.path.join(d, "u.txt"))
    n = np.array([0.0, 0.0, 1.0])

    crack = B[crack_mask(X, B, t, h)]
    allnodes = np.unique(crack[:, :3])
    # side of each crack face: the fourth node of its tetrahedron against the crack normal (robust for flat tetrahedra)
    tets = T4[crack[:, 3]]
    fourth = np.array([next(v for v in row if v not in face) for row, face in zip(tets, crack[:, :3])])
    upper = (X[fourth] - X[crack[:, 0]]) @ n > 0
    F = crack[upper, :3]
    nodes = np.unique(F)
    # partner across the crack: the other crack node at the same undeformed position (exact match of the coordinates)
    key = {}
    for g in allnodes:
        key.setdefault(tuple(np.round(X[g], 9)), []).append(g)
    partner = np.array([next((h for h in key[tuple(np.round(X[g], 9))] if h != g), g) for g in nodes])
    ref = 8 * (1 - NU ** 2) * SIGMA * A / (np.pi * E)
    opening = np.abs((U[nodes] - U[partner]) @ n) / ref
    print("  upper crack face: %d triangles, %d nodes (%d front nodes); opening / ref: max %.4f (closed form %.4f)"
          % (len(F), len(nodes), int(np.sum(partner == nodes)), opening.max(), 0.0))

    local = np.full(len(X), -1, dtype=np.int64)
    local[nodes] = np.arange(len(nodes))
    # The drawn face ends on mesh nodes up to h_min/4 beyond the front: clip it at the semi-ellipse
    # (x/c)^2 + ((y+t)/a)^2 = 1 of the first front, in the undeformed coordinates (clip_front.py), for a smooth outline.
    P = X[nodes]
    g = (P[:, 0] / C) ** 2 + ((P[:, 1] + t) / A) ** 2 - 1.0
    P2, (U2, opening2), F2, rim = clip_triangles(P, local[F], [U[nodes], opening], g)
    opening2[rim] = 0.0  # the front has no jump
    print("  clipped at the front ellipse: %d -> %d triangles, %d -> %d nodes" % (len(F), len(F2), len(nodes), len(P2)))
    out = os.path.join(FIGS, "ensight")
    os.makedirs(out, exist_ok=True)
    case = os.path.join(out, stem + ".case")
    write_ensight_gold(case, nodes=P2 + scale * U2, elements={"tria3": F2},
                       node_data={"opening": opening2}, part_name="crack", binary=True)
    pdfdir = os.path.join(FIGS, "pdf")
    r = subprocess.run([EXE, "--headless", "-o", pdfdir, "-n", stem, "--views", "best", "--size", "520x300", "--field", "opening", case],
                       capture_output=True, text=True, timeout=600)
    if r.returncode != 0:
        sys.exit("headless export failed (%d): %s" % (r.returncode, r.stderr.strip()[-2000:]))
    raw = os.path.join(pdfdir, stem + "_best.pdf")
    mesh = os.path.join(pdfdir, stem + "_mesh.pdf")
    subprocess.run(["pdfcrop", "--margins", "2", raw, mesh], check=True, stdout=subprocess.DEVNULL)
    os.remove(raw)
    # The Gouraud mesh is slow in PDF viewers: the field becomes a 450 dpi image (as in fig_penny_color.py).
    subprocess.run([sys.executable, os.path.join(HERE, "shading_to_image.py"), mesh, os.path.join(pdfdir, stem + ".pdf"),
                    "--dpi", "450", "--jpeg", "92"], check=True)
    os.remove(mesh)
    print("  wrote", os.path.join(pdfdir, stem + ".pdf"))


if __name__ == "__main__":
    main()
