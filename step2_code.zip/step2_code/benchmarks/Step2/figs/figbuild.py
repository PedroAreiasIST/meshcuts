#!/usr/bin/env python3
"""figbuild — author XFig `.fig` (Format 3.2) files programmatically, in the P. Areias house style.

Use as a library (compose a figure object-by-object) or run __main__ for a demo/self-test. Defaults
match the corpus: Landscape/Center/Metric/A4, 1200 dpi, coord_system 2 (upper-left origin, y DOWN);
LaTeX text via the Special font-flag (flags=6, font Times) with backslashes doubled + `\\001`
terminator; user colors as class-0 pseudo-objects emitted before any object that uses them.

    from figbuild import Fig
    f = Fig()
    f.color(32, "#5e80b1")
    f.box(1000, 1000, 4000, 3000, thickness=2)
    f.polyline([(1000,3200),(4000,3200)], fwd_arrow=True)          # leader with arrowhead
    f.text(2500, 900, r"$\\sigma_{\\max}$", size=22)                # LaTeX label (Special flag)
    f.picture("mesh.eps", 5000, 1000, 9000, 4000)                  # imported EPS/JPG
    f.write("out.fig")

Convert with fig2x.sh (eps/pdf/png/svg/tikz, or the pstex/pdftex LaTeX-overlay used by figtex2*.sh).
Units are Fig units = 1/1200 inch. Geometry: depth 0..50 = foreground, ~999 = background.
"""
import sys

STD = {"black": 0, "blue": 1, "green": 2, "cyan": 3, "red": 4, "magenta": 5,
       "yellow": 6, "white": 7}

# The canonical palette that plotgnu's fig-terminal export writes into ~108 corpus figures
# (colour indices 32..71): #9400d3 + Okabe-Ito (33-37) + the gnuplot default line colours
# (41-61) + a grayscale ramp (62-71). Reuse it so authored figures match the corpus; after
# Fig.use_corpus_palette() you can reference any entry by its index (e.g. pen=35 = Okabe orange).
CORPUS_PALETTE = {
    32: "#9400d3", 33: "#009e73", 34: "#56b4e9", 35: "#e69f00", 36: "#f0e442", 37: "#0072b2",
    38: "#e51e10", 39: "#000000", 40: "#ffffff",
    41: "#000000", 42: "#a0a0a0", 43: "#ff0000", 44: "#00c000", 45: "#0080ff", 46: "#c000ff",
    47: "#00eeee", 48: "#c04000", 49: "#c8c800", 50: "#4169e1", 51: "#ffc020", 52: "#008040",
    53: "#c080ff", 54: "#306080", 55: "#8b0000", 56: "#408000", 57: "#ff80ff", 58: "#7fffd4",
    59: "#a52a2a", 60: "#ffff00", 61: "#40e0d0",
    62: "#000000", 63: "#1a1a1a", 64: "#333333", 65: "#4d4d4d", 66: "#666666", 67: "#7f7f7f",
    68: "#999999", 69: "#b3b3b3", 70: "#c0c0c0", 71: "#cccccc",
}
# Okabe-Ito colour-blind-safe set — the publication palette (corpus indices 33-37 + others).
OKABE_ITO = {"black": "#000000", "orange": "#e69f00", "skyblue": "#56b4e9", "green": "#009e73",
             "yellow": "#f0e442", "blue": "#0072b2", "vermillion": "#d55e00", "purple": "#cc79a7"}


class Fig:
    def __init__(self, orientation="Landscape", justification="Center", units="Metric",
                 paper="A4", magnification="100.00", resolution=1200):
        self.header = [
            "#FIG 3.2  Produced by figbuild (gid/xfig skill)",
            "#encoding: UTF-8",
            orientation, justification, units, paper, magnification, "Single", "-2",
            f"{resolution} 2",
        ]
        self.colors = []   # (num, hex) class-0 pseudo-objects (emitted first)
        self.objs = []     # list of already-formatted text blocks (str)

    # ---- colors -------------------------------------------------------------
    def color(self, num, hexstr):
        assert num >= 32, "user color numbers must be >= 32"
        self.colors.append(f"0 {num} {hexstr.lower()}")
        return num

    def use_corpus_palette(self):
        """Register the canonical plotgnu/SimPlas export palette (indices 32-71) so this
        figure matches the corpus. Returns the {index: hex} map; reference colours by index."""
        for num, hexstr in CORPUS_PALETTE.items():
            self.colors.append(f"0 {num} {hexstr}")
        return CORPUS_PALETTE

    # ---- helpers ------------------------------------------------------------
    @staticmethod
    def _pts(points):
        return "\t " + " ".join(f"{int(round(x))} {int(round(y))}" for x, y in points)

    @staticmethod
    def _arrow(spec):
        # spec: (type, style, thickness, width, height); defaults match the corpus
        t, s, th, w, h = spec if spec is not True else (1, 1, 1.0, 60.0, 120.0)
        return f"\t{t} {s} {th:.2f} {w:.2f} {h:.2f}"

    # ---- objects ------------------------------------------------------------
    def polyline(self, points, sub=1, line_style=0, thickness=1, pen=0, fill=-1, depth=50,
                 area_fill=-1, style_val=0.0, join=0, cap=0, radius=-1,
                 fwd_arrow=None, bwd_arrow=None):
        pts = list(points)
        head = (f"2 {sub} {line_style} {thickness} {pen} {fill} {depth} -1 {area_fill} "
                f"{style_val:.3f} {join} {cap} {radius} {1 if fwd_arrow else 0} "
                f"{1 if bwd_arrow else 0} {len(pts)}")
        lines = [head]
        if fwd_arrow:
            lines.append(self._arrow(fwd_arrow))
        if bwd_arrow:
            lines.append(self._arrow(bwd_arrow))
        lines.append(self._pts(pts))
        self.objs.append("\n".join(lines))

    def box(self, x0, y0, x1, y1, **kw):
        self.polyline([(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)], sub=2, **kw)

    def text(self, x, y, s, sub=0, color=0, depth=50, font=0, size=22, angle=0.0,
             latex=True):
        # latex -> Special(2)+PostScript-font(4) = flags 6 (corpus default), font Times(0)
        flags = 6 if latex else 4
        body = s.replace("\\", "\\\\")               # backslashes doubled in the .fig file
        height = int(round(size * 15.75))
        length = max(1, int(round(len(s) * size * 8)))
        self.objs.append(
            f"4 {sub} {color} {depth} -1 {font} {size:g} {angle:.4f} {flags} "
            f"{height} {length} {int(round(x))} {int(round(y))} {body}\\001")

    def ellipse(self, cx, cy, rx, ry, sub=1, line_style=0, thickness=1, pen=0, fill=-1,
                depth=50, area_fill=-1, style_val=0.0, angle=0.0):
        self.objs.append(
            f"1 {sub} {line_style} {thickness} {pen} {fill} {depth} -1 {area_fill} "
            f"{style_val:.3f} 1 {angle:.4f} {int(cx)} {int(cy)} {int(rx)} {int(ry)} "
            f"{int(cx)} {int(cy)} {int(cx+rx)} {int(cy)}")

    def arc(self, cx, cy, p1, p2, p3, sub=1, line_style=0, thickness=1, pen=0, fill=-1,
            depth=50, area_fill=-1, style_val=0.0, cap=0, direction=1,
            fwd_arrow=None, bwd_arrow=None):
        head = (f"5 {sub} {line_style} {thickness} {pen} {fill} {depth} -1 {area_fill} "
                f"{style_val:.3f} {cap} {direction} {1 if fwd_arrow else 0} "
                f"{1 if bwd_arrow else 0} {cx:.3f} {cy:.3f} "
                f"{int(p1[0])} {int(p1[1])} {int(p2[0])} {int(p2[1])} {int(p3[0])} {int(p3[1])}")
        lines = [head]
        if fwd_arrow:
            lines.append(self._arrow(fwd_arrow))
        if bwd_arrow:
            lines.append(self._arrow(bwd_arrow))
        self.objs.append("\n".join(lines))

    def spline(self, points, controls=None, sub=2, line_style=0, thickness=1, pen=0,
               fill=-1, depth=50, area_fill=-1, style_val=0.0, cap=0,
               fwd_arrow=None, bwd_arrow=None):
        pts = list(points)
        if controls is None:                          # interpolated default: endpoints sharp
            controls = [0.0] + [1.0] * (len(pts) - 2) + [0.0] if len(pts) > 2 else [0.0] * len(pts)
        head = (f"3 {sub} {line_style} {thickness} {pen} {fill} {depth} -1 {area_fill} "
                f"{style_val:.3f} {cap} {1 if fwd_arrow else 0} {1 if bwd_arrow else 0} {len(pts)}")
        lines = [head]
        if fwd_arrow:
            lines.append(self._arrow(fwd_arrow))
        if bwd_arrow:
            lines.append(self._arrow(bwd_arrow))
        lines.append(self._pts(pts))
        lines.append("\t " + " ".join(f"{c:.3f}" for c in controls))
        self.objs.append("\n".join(lines))

    def picture(self, filename, x0, y0, x1, y1, flipped=0, depth=50, thickness=1):
        # class-2 sub-type 5 imported picture: header, "\t<flipped> <file>", "\t<5 corner coords>"
        corners = [(x0, y0), (x1, y0), (x1, y1), (x0, y1), (x0, y0)]
        head = f"2 5 0 {thickness} 0 -1 {depth} -1 -1 0.000 0 0 -1 0 0 5"
        self.objs.append(f"{head}\n\t{flipped} {filename}\n" + self._pts(corners))

    def compound(self, inner, bbox=None):
        """Group a list of already-built Fig fragments (or a sub-Fig's .objs)."""
        objs = inner.objs if isinstance(inner, Fig) else list(inner)
        if bbox is None:
            bbox = (0, 0, 0, 0)
        x0, y0, x1, y1 = bbox
        self.objs.append(f"6 {int(x0)} {int(y0)} {int(x1)} {int(y1)}\n"
                         + "\n".join(objs) + "\n-6")

    # ---- output -------------------------------------------------------------
    def dumps(self):
        return "\n".join(self.header + self.colors + self.objs) + "\n"

    def write(self, path):
        with open(path, "w") as f:
            f.write(self.dumps())
        return path


def _demo(path):
    f = Fig()
    blue = f.color(32, "#5e80b1")
    f.box(1000, 1000, 6000, 4000, thickness=2)
    f.polyline([(1000, 4400), (6000, 4400)], pen=blue, thickness=2,
               fwd_arrow=True, bwd_arrow=True)                  # dimension line
    f.text(3500, 4800, r"$L = 5\,\mathrm{mm}$", size=22)        # LaTeX label
    f.ellipse(3500, 2500, 300, 300, sub=3, fill=7, area_fill=20)
    f.spline([(1500, 1500), (3000, 800), (5500, 1800)], sub=2, pen=4)
    f.text(3000, 600, r"$\sigma(\varepsilon)$", size=22, color=4)
    f.write(path)
    return path


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "/tmp/figbuild_demo.fig"
    print("wrote", _demo(out))
