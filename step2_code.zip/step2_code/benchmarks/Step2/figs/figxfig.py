#!/usr/bin/env python3
"""Full-vector design figures in Xfig (Fig 3.2), typeset with the manuscript's fonts.

Every design panel is drawn from the element densities as vector primitives, never as an image:

  void      the domain, filled with VOID (98.5 % white);
  material  the region x >= 0.5 of the physical density averaged to the nodes, as closed polygons filled with
            SOLID (very dark gray); Fig polygons have no holes, so the rings of the 0.5 iso-contour are layered
            by nesting depth (material, then its holes in VOID on top, then islands in SOLID on top of those);
  interface the 0.5 iso-contour itself, a fine dashed line;
  fibers    evenly spaced, smoothed streamlines of the director fields (make_figures.trace_streamlines) in white,
            0.5625 pt (1.25 times the 0.45 pt lines; Fig thickness 2 in the .fig, set in the PostScript by
            fiber_width), a second family dashed;
  outline   the domain boundary, a fine solid line;
  titles    Special (LaTeX) text, typeset by pdflatex through fig2dev's pdftex/pdftex_t split.

The figure is laid out at its printed width (TEXTW = 16 cm, \\textwidth of the manuscript), so line widths,
dashes and the 8 pt titles print at their nominal sizes. Each figure is kept as figs/xfig/<stem>.fig (editable
in xfig) and exported to figs/pdf/<stem>.pdf: fig2dev -L pdftex + pdftex_t, wrapped in a standalone document and
compiled with pdflatex.
"""
import os
import shutil
import subprocess
import sys
import tempfile

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                  # noqa: E402
from matplotlib.path import Path                                 # noqa: E402

sys.path.insert(0, os.path.expanduser("."))
from figbuild import Fig                                         # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
FIGS = os.path.join(HERE, "..", "figs", "pdf")
XFIG = os.path.join(HERE, "..", "figs", "xfig")

CM = 1200.0/2.54                 # Fig units per cm (1200 per inch)
TEXTW = 16.0                     # cm: \textwidth (a4paper, 2.5 cm margins)
VOID = "#fbfbfb"                 # 98.5 % white
SOLID = "#333333"                # very dark gray
C_VOID, C_SOLID = 32, 33
C_FIB = 7                        # fibers: Fig's white, family 2 dashed
FIB_T = 2                        # Fig thickness of the fibers: a marker, drawn FIB_PT wide (fiber_width)
FIB_PT = 1.25*0.45               # fiber width [pt]: 1.25 times thickness 1
TITLE_PT = 8                     # title size [pt]
DASH = 1.5                       # interface dash, 1/80 inch (1.35 pt); thickness 1 = 0.45 pt


# ------------------------------------------------------------------ geometry
def nodal(g):
    """Element field g (nx, ny), NaN outside the domain -> node field (nx+1, ny+1): the mean of the adjacent domain
    elements, NaN at nodes that touch none."""
    nx, ny = g.shape
    m = ~np.isnan(g)
    v = np.where(m, g, 0.0)
    s = np.zeros((nx + 1, ny + 1))
    c = np.zeros((nx + 1, ny + 1))
    for a in (0, 1):
        for b in (0, 1):
            s[a:a + nx, b:b + ny] += v
            c[a:a + nx, b:b + ny] += m
    out = np.full((nx + 1, ny + 1), np.nan)
    out[c > 0] = s[c > 0]/c[c > 0]
    return out


def iso(g, level=0.5):
    """Rings of the region {x >= level} with their nesting depth, and the iso-lines x = level, in element
    coordinates (x along the first index, y along the second). A quad with a node outside the domain is left out
    (corner_mask=False), so the L-shape's corner stays empty."""
    gn = nodal(g)
    X, Y = np.meshgrid(np.arange(gn.shape[0]), np.arange(gn.shape[1]))
    Z = np.ma.masked_invalid(gn.T)
    fig = plt.figure()
    rings, lines = [], []
    if np.nanmax(gn) >= level:
        cf = plt.contourf(X, Y, Z, levels=[level, 1.0 + 1e-9], corner_mask=False)
        for coll in cf.collections:
            for p in coll.get_paths():
                rings += [r for r in p.to_polygons(closed_only=True) if len(r) >= 4]
        if np.nanmin(gn) < level:
            cl = plt.contour(X, Y, Z, levels=[level], corner_mask=False)
            for coll in cl.collections:
                for p in coll.get_paths():
                    lines += [l for l in p.to_polygons(closed_only=False) if len(l) >= 2]
    plt.close(fig)
    paths = [Path(r) for r in rings]
    nest = [sum(1 for j, q in enumerate(paths) if j != i and q.contains_point(r[0])) for i, r in enumerate(rings)]
    return list(zip(rings, nest)), lines


def domain_rings(g):
    """The boundary of the domain cells (non-NaN) as closed rings, element coordinates."""
    inside = ~np.isnan(g)
    if inside.all():
        nx, ny = g.shape
        return [np.array([(0, 0), (nx, 0), (nx, ny), (0, ny), (0, 0)], float)]
    nx, ny = g.shape
    pad = np.zeros((nx + 2, ny + 2), bool)
    pad[1:-1, 1:-1] = inside
    nxt = {}                                       # directed unit edges, domain on the left
    for ix, iy in zip(*np.nonzero(inside)):
        if not pad[ix + 1, iy]:
            nxt[(ix, iy)] = (ix + 1, iy)
        if not pad[ix + 2, iy + 1]:
            nxt[(ix + 1, iy)] = (ix + 1, iy + 1)
        if not pad[ix + 1, iy + 2]:
            nxt[(ix + 1, iy + 1)] = (ix, iy + 1)
        if not pad[ix, iy + 1]:
            nxt[(ix, iy + 1)] = (ix, iy)
    rings = []
    while nxt:
        a = next(iter(nxt))
        ring = [a]
        b = nxt.pop(a)
        while b != a:
            ring.append(b)
            b = nxt.pop(b)
        ring.append(a)
        r = np.array(ring, float)
        keep = [0] + [k for k in range(1, len(r) - 1)
                      if np.cross(r[k] - r[k - 1], r[k + 1] - r[k]) != 0] + [len(r) - 1]
        rings.append(r[keep])
    return rings


def rdp(p, eps):
    """Ramer-Douglas-Peucker simplification of a polyline (n, 2)."""
    if len(p) < 3:
        return p
    keep = np.zeros(len(p), bool)
    keep[0] = keep[-1] = True
    stack = [(0, len(p) - 1)]
    while stack:
        i, j = stack.pop()
        if j <= i + 1:
            continue
        a, b = p[i], p[j]
        d = b - a
        L = np.hypot(*d)
        q = p[i + 1:j] - a
        dist = np.abs(d[0]*q[:, 1] - d[1]*q[:, 0])/L if L > 0 else np.hypot(q[:, 0], q[:, 1])
        k = int(np.argmax(dist))
        if dist[k] > eps:
            keep[i + 1 + k] = True
            stack += [(i, i + 1 + k), (i + 1 + k, j)]
    return p[keep]


# ------------------------------------------------------------------ figure
class Figure:
    """A figure of design panels at its printed size; coordinates in Fig units, y down."""

    def __init__(self):
        self.f = Fig(units="Inches", paper="Letter")     # Metric would be scaled by 1200/1143 in fig2dev
        self.f.color(C_VOID, VOID)
        self.f.color(C_SOLID, SOLID)
        self.ymax = 0.0
        self.fibers = False

    def _map(self, x0, y0, s, ny, y_down):
        if y_down:
            return lambda p: np.column_stack([x0 + s*p[:, 0], y0 + s*p[:, 1]])
        return lambda p: np.column_stack([x0 + s*p[:, 0], y0 + s*(ny - p[:, 1])])

    @staticmethod
    def _clean(P, closed):
        P = np.rint(P)
        keep = np.r_[True, np.any(np.diff(P, axis=0) != 0, axis=1)]
        P = P[keep]
        P = rdp(P, 0.8)
        if closed and (P[0] != P[-1]).any():
            P = np.vstack([P, P[:1]])
        return P

    def panel(self, x0, y0, w, g, y_down=True, title=None, title2=None, fibers=()):
        """One design: g (nx, ny) physical density (NaN outside the domain), drawn w Fig units wide with its top-left
        corner at (x0, y0). fibers: [(list of (n, 2) streamlines in element coordinates, family 1|2)]."""
        nx, ny = g.shape
        s = w/nx
        M = self._map(x0, y0, s, ny, y_down)
        f = self.f
        dom = domain_rings(g)
        for r in dom:
            f.polyline(self._clean(M(r), True), sub=3, thickness=0, fill=C_VOID, area_fill=20, depth=900)
        rings, lines = iso(g)
        for r, n in rings:
            P = self._clean(M(r), True)
            if len(P) >= 4:
                f.polyline(P, sub=3, thickness=0, fill=C_SOLID if n % 2 == 0 else C_VOID, area_fill=20,
                           depth=max(500 - n, 101))
        for fam_lines, fam in fibers:
            for l in fam_lines:
                P = self._clean(M(np.asarray(l, float)), False)
                if len(P) >= 2:
                    f.polyline(P, thickness=FIB_T, pen=C_FIB, depth=60,
                               line_style=0 if fam == 1 else 1, style_val=0.0 if fam == 1 else 2.5, cap=1, join=1)
                    self.fibers = True
        for l in lines:
            P = self._clean(M(l), False)
            if len(P) >= 2:
                f.polyline(P, thickness=1, pen=0, line_style=1, style_val=DASH, depth=40, join=1)
        for r in dom:
            f.polyline(self._clean(M(r), True), sub=3, thickness=1, pen=0, depth=30, join=0)
        h = s*ny
        if title:
            f.text(x0 + 0.5*w, y0 - 0.12*CM, title, sub=1, size=TITLE_PT, depth=10)
        if title2:
            f.text(x0 + 0.5*w, y0 - 0.12*CM - 1.25*TITLE_PT/72.0*1200, title2, sub=1, size=TITLE_PT, depth=10)
        self.ymax = max(self.ymax, y0 + h)
        return h

    def export(self, stem, height=None, xfig_dir=XFIG, pdf_dir=FIGS, ps_filter=None, compact=False):
        """figs/xfig/<stem>.fig and figs/pdf/<stem>.pdf (TEXTW wide; an invisible frame fixes the bounding box).
        ps_filter: optional str -> str applied to fig2dev's PostScript (-L pstex) before epstopdf, for what Fig cannot
        express (a line thinner than thickness 1). compact: rewrite epstopdf's content stream with compact_pdf (the
        same drawing in fewer bytes; for figures of many polygons). With fibers, fiber_width is applied first."""
        if self.fibers:
            ps_filter = fiber_width if ps_filter is None else (lambda ps, g=ps_filter: g(fiber_width(ps)))
        H = height if height is not None else self.ymax + 0.05*CM
        self.f.polyline([(0, 0), (TEXTW*CM, 0), (TEXTW*CM, H), (0, H), (0, 0)], sub=2, thickness=0, depth=999)
        os.makedirs(xfig_dir, exist_ok=True)
        os.makedirs(pdf_dir, exist_ok=True)
        fig = self.f.write(os.path.join(xfig_dir, stem + ".fig"))
        with tempfile.TemporaryDirectory() as tmp:
            if ps_filter is None:
                subprocess.run(["fig2dev", "-L", "pdftex", fig, os.path.join(tmp, stem + "-graphic.pdf")], check=True)
            else:
                eps = os.path.join(tmp, stem + "-graphic.eps")
                subprocess.run(["fig2dev", "-L", "pstex", fig, eps], check=True)
                with open(eps) as r:
                    ps = ps_filter(r.read())
                with open(eps, "w") as w:
                    w.write(ps)
                subprocess.run(["epstopdf", eps, "--outfile=" + os.path.join(tmp, stem + "-graphic.pdf")], check=True)
            if compact:
                compact_pdf(os.path.join(tmp, stem + "-graphic.pdf"))
            subprocess.run(["fig2dev", "-L", "pdftex_t", "-p", stem + "-graphic.pdf", fig,
                            os.path.join(tmp, stem + ".pdftex_t")], check=True)
            with open(os.path.join(tmp, "wrap.tex"), "w") as w:
                w.write("\\documentclass[11pt]{standalone}\n\\usepackage{graphicx,color,amsmath}\n"
                        "\\begin{document}\n\\input{%s.pdftex_t}\n\\end{document}\n" % stem)
            subprocess.run(["pdflatex", "-interaction=batchmode", "wrap.tex"], cwd=tmp, check=True,
                           stdout=subprocess.DEVNULL)
            shutil.copy(os.path.join(tmp, "wrap.pdf"), os.path.join(pdf_dir, stem + ".pdf"))
        print("  wrote %s.fig, %s.pdf" % (os.path.join(xfig_dir, stem), os.path.join(pdf_dir, stem)))


def fiber_width(ps):
    """The fibers' line width FIB_PT in fig2dev's PostScript: thickness FIB_T is drawn by fig2dev as 7.5 FIB_T units
    (0.45 FIB_T pt) and no other line of a design figure has it."""
    old = "%.3f slw" % (7.5*FIB_T)
    lines = ps.split("\n")
    assert old in lines, old
    return "\n".join("%.3f slw" % (7.5*FIB_PT/0.45) if l == old else l for l in lines)


def _num(v, nd):
    t = ("%%.%df" % nd) % v
    t = t.rstrip("0").rstrip(".") if "." in t else t
    return "0" if t in ("-0", "") else t


def _compact_content(d):
    """epstopdf's (Ghostscript pdfwrite) content stream of a fig2dev figure -> the same drawing in fewer bytes, or None
    when the stream holds anything else than expected. (1) Each polygon that fig2dev fills and then strokes is written
    by pdfwrite twice, as 'path f*' and 'path h S' with only stroke state between: one 'path b*' (close, fill
    even-odd, stroke) paints the same. (2) The coordinates lie on the Fig lattice (1/1200 inch = 0.6 of pdfwrite's
    0.1 pt unit, plus a fixed offset): with the scale of the one 'cm' set to the lattice they are integers; line widths
    and dashes are rescaled with it. (3) Colours keep three decimals (Fig's are 8-bit), a grey as DeviceGray
    (g, G), which paints as the equal RGB triple (no output intent in these documents)."""
    L = d.split("\n")
    pts = [l.split() for l in L if l.endswith((" m", " l"))]
    if not pts or L[0].split()[-1:] != ["cm"] or sum(1 for l in L if l.endswith(" cm")) != 1:
        return None
    a, b, c, dd, e, f = (float(v) for v in L[0].split()[1:7])
    if b != 0 or c != 0 or a != dd:
        return None
    import numpy as np
    xy = np.array([[float(t[0]), float(t[1])] for t in pts])
    off = []
    for k in range(2):
        r = np.round(np.mod(xy[:, k], 0.6), 3)
        vals, cnt = np.unique(r, return_counts=True)
        o = vals[np.argmax(cnt)]
        q = (xy[:, k] - o)/0.6
        if np.abs(q - np.rint(q)).max() > 0.01:
            return None
        off.append(o)
    for t in (l.split() for l in L if l.endswith(" re")):        # rectangles: corner on the lattice, sides multiples
        for k in range(2):
            for v in ((float(t[k]) - off[k])/0.6, float(t[k + 2])/0.6):
                if abs(v - round(v)) > 0.01:
                    return None
    known = {"m", "l", "h", "re", "S", "f*", "f", "RG", "rg", "w", "j", "J", "d", "Q", "M"}
    out = ["q %s 0 0 %s %s %s cm" % (_num(0.6*a, 6), _num(0.6*a, 6), _num(e + a*off[0], 6), _num(f + a*off[1], 6))]

    def pt(line):
        t = line.split()
        if t[-1] == "re":
            return "%d %d %d %d re" % (round((float(t[0]) - off[0])/0.6), round((float(t[1]) - off[1])/0.6),
                                       round(float(t[2])/0.6), round(float(t[3])/0.6))
        return "%d %d %s" % (round((float(t[0]) - off[0])/0.6), round((float(t[1]) - off[1])/0.6), t[2])

    def state(line):
        t = line.split()
        op = t[-1]
        if op in ("RG", "rg"):
            v = [_num(float(x), 3) for x in t[:-1]]
            if v[0] == v[1] == v[2]:                             # a grey: the DeviceGray operator paints the same
                return v[0] + (" G" if op == "RG" else " g")
            return " ".join(v) + " " + op
        if op == "w":
            return _num(float(t[0])/0.6, 3) + " w"
        if op == "d":
            arr = line[line.index("[") + 1:line.index("]")].split()
            return "[%s] %s d" % (" ".join(_num(float(v)/0.6, 3) for v in arr), _num(float(t[-2])/0.6, 3))
        return line
    i, n = 1, len(L)
    while i < n:
        line = L[i]
        if not line:
            i += 1
            continue
        op = line.split()[-1]
        if op not in known:
            return None
        if op in ("m", "re"):                                   # a path (or a rectangle), maybe closed by h
            j = i + 1
            while op == "m" and j < n and L[j].endswith(" l"):
                j += 1
            path = L[i:j]
            jf = j + 1 if j < n and L[j] == "h" else j
            if jf < n and L[jf] == "f*":
                k = jf + 1
                mid = []
                while k < n and L[k] and L[k].split()[-1] in ("RG", "w", "j", "J", "d", "M"):
                    mid.append(L[k])
                    k += 1
                tail = ["h", "S"] if op == "m" else ["S"]
                if L[k:k + len(path)] == path and L[k + len(path):k + len(path) + len(tail)] == tail:
                    out += [state(x) for x in mid] + [pt(x) for x in path] + ["b*"]
                    i = k + len(path) + len(tail)
                    continue
            out += [pt(x) for x in path]
            i = j
            continue
        out.append(state(line))
        i += 1
    return "\n".join(out) + "\n"


def _local_content(d, reset=64):
    """_compact_content's stream with each filled-and-stroked polygon ('x y m', 'x y l' ..., 'b*') written in
    coordinates local to its first vertex: '1 0 0 1 dx dy cm' moves the origin there from the previous polygon's first
    vertex, then '0 0 m' and small offsets. The drawing is the same (integer translations of the lattice); the numbers
    are short and repeat, which Flate packs about 30 % better than four-digit absolute coordinates. Every `reset`
    polygons the translations are undone by Q/q, so that no rounding accumulates in a viewer with a coarse matrix
    arithmetic; a Q also restores the colours, which are set again after it. Everything else is written as it is,
    at the original matrix. None when the stream is not _compact_content's."""
    L = d.split("\n")
    if not L or not L[0].endswith(" cm"):
        return None
    out = [L[0]]
    col = {}                                                     # the current fill and stroke colour lines
    st = {"open": False, "n": 0, "o": (0, 0)}

    def close():
        if st["open"]:
            out.append("Q")
            out.extend(col[k] for k in sorted(col))
        st.update(open=False, n=0, o=(0, 0))
    i, n = 1, len(L)
    while i < n:
        line = L[i]
        t = line.split()
        op = t[-1] if t else ""
        if op in ("g", "G", "rg", "RG"):
            col[op.lower() + ("s" if op[0].isupper() else "f")] = line
            out.append(line)
            i += 1
            continue
        if op == "m":
            j = i + 1
            while j < n and L[j].endswith(" l"):
                j += 1
            if j < n and L[j] == "b*":
                try:
                    P = [(int(u[0]), int(u[1])) for u in (x.split() for x in L[i:j])]
                except ValueError:
                    return None
                if not st["open"] or st["n"] >= reset:
                    close()
                    out.append("q")
                    st["open"] = True
                x0, y0 = P[0]
                out.append("1 0 0 1 %d %d cm" % (x0 - st["o"][0], y0 - st["o"][1]))
                out.append("0 0 m")
                out.extend("%d %d l" % (x - x0, y - y0) for x, y in P[1:])
                out.append("b*")
                st["o"] = (x0, y0)
                st["n"] += 1
                i = j + 1
                continue
            close()
            out.extend(L[i:j])
            i = j
            continue
        if line:
            close()
            out.append(line)
        i += 1
    close()
    return "\n".join(out) + "\n"


def _deflate(data):
    """A zlib stream of `data`: 7-Zip's Deflate encoder when 7z is installed (about 8 % smaller than zlib level 9 on
    these streams, some 40 s per 16 MB), zlib otherwise. Any Flate decoder reads either."""
    import zlib
    best = zlib.compress(data, 9)
    if shutil.which("7z"):
        with tempfile.TemporaryDirectory() as tmp:
            src, gz = os.path.join(tmp, "s"), os.path.join(tmp, "s.gz")
            with open(src, "wb") as w:
                w.write(data)
            r = subprocess.run(["7z", "a", "-tgzip", "-mx=9", "-mfb=258", "-mpass=15", gz, src],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if r.returncode == 0:
                g = open(gz, "rb").read()
                k = 10                                           # gzip header, then the optional fields
                flg = g[3]
                if flg & 4:
                    k += 2 + int.from_bytes(g[k:k + 2], "little")
                for bit in (8, 16):
                    if flg & bit:
                        k = g.index(b"\0", k) + 1
                if flg & 2:
                    k += 2
                z = b"\x78\xda" + g[k:-8] + zlib.adler32(data).to_bytes(4, "big")
                try:
                    ok = zlib.decompress(z) == data
                except zlib.error:
                    ok = False
                if ok and len(z) < len(best):
                    best = z
    return best


def repack_pdf(path):
    """Shrink a finished figure (export's pdflatex output, PDF 1.5 with a cross-reference stream) in place, without
    redrawing it: the Flate stream of the included graphic (the Form XObject of fig2dev's -graphic.pdf, compacted by
    compact_pdf) is rewritten with _local_content and _deflate, the cross-reference stream is updated, every other
    byte is kept. Returns (old size, new size), or None when the file is not of that kind or nothing is gained."""
    import re
    import zlib
    b = open(path, "rb").read()
    try:
        sx = b.rindex(b"startxref")
        xo = int(b[sx + 9:].split()[0])
        xm = re.compile(rb"(\d+) 0 obj\s*(<<.*?>>)\s*stream\r?\n", re.S).match(b, xo)
    except (ValueError, IndexError):
        return None
    if xm is None or b"/Type /XRef" not in xm.group(2) or b"/DecodeParms" in xm.group(2) or b"/Prev" in xm.group(2):
        return None
    xd = xm.group(2)
    W = [int(v) for v in re.search(rb"/W \[(\d+) (\d+) (\d+)\]", xd).group(1, 2, 3)]
    xl = re.search(rb"/Length (\d+)", xd)
    rows = zlib.decompress(b[xm.end():xm.end() + int(xl.group(1))])
    rw = sum(W)
    ent = [[int.from_bytes(rows[r + sum(W[:c]):r + sum(W[:c + 1])], "big") for c in range(3)]
           for r in range(0, len(rows), rw)]
    forms = []
    for e in ent:
        if e[0] != 1 or e[1] == xo:
            continue
        m = re.compile(rb"\d+ 0 obj\s*(<<.*?>>)\s*stream\r?\n", re.S).match(b, e[1])
        if m and b"/Subtype /Form" in m.group(1) and b"/PTEX.FileName" in m.group(1) and b"/FlateDecode" in m.group(1):
            lm = re.search(rb"/Length (\d+)(?! 0 R)", m.group(1))
            if lm:
                forms.append((e[1], m, lm))
    if len(forms) != 1:
        return None
    fo, m, lm = forms[0]
    ln = int(lm.group(1))
    data = zlib.decompress(b[m.end():m.end() + ln]).decode("latin1")
    new = _local_content(data) if " cm\n0 0 m\n" not in data else data   # already local: only the deflate is tried
    if new is None:
        return None
    z = _deflate(new.encode("latin1"))
    if len(z) >= ln:
        return None
    head = b[fo:m.end()].replace(lm.group(0), b"/Length %d" % len(z), 1)
    body = b[:fo] + head + z + b[m.end() + ln:xo]
    shift = len(body) - xo
    for e in ent:
        if e[0] == 1 and e[1] > fo:
            e[1] += shift
    if max(e[1] for e in ent) >= 256**W[1]:
        return None
    rows = zlib.compress(b"".join(v.to_bytes(w, "big") for e in ent for v, w in zip(e, W)), 9)
    xhead = b[xo:xm.end()].replace(xl.group(0), b"/Length %d" % len(rows), 1)
    out = body + xhead + rows + b"\nendstream\nendobj\nstartxref\n%d\n%%%%EOF\n" % (xo + shift)
    open(path, "wb").write(out)
    return len(b), len(out)


def compact_pdf(path):
    """Rewrite the one content stream of an epstopdf PDF with _compact_content, _local_content and _deflate (left as it
    is when _compact_content declines or the file is not the plain Ghostscript layout: one xref table, a Flate content
    stream with an indirect /Length)."""
    import re
    import zlib
    b = open(path, "rb").read()
    m = re.search(rb"\nxref\n0 (\d+)\n", b)
    if m is None or b.count(b"\nxref\n") != 1:
        return False
    nobj = int(m.group(1))
    offs = {}
    for k, row in enumerate(b[m.end():m.end() + 20*nobj].split(b"\n")[:nobj]):
        if row.endswith(b" n ") or row.endswith(b" n"):
            offs[k] = int(row[:10])
    objs = {}
    for k, o in offs.items():
        e = b.index(b"endobj", o)
        objs[k] = b[o:e + len(b"endobj")]
    cs = [k for k, v in objs.items() if b"/FlateDecode" in v and re.search(rb"/Length (\d+) 0 R", v.split(b"stream", 1)[0])]
    if len(cs) != 1:
        return False
    k = cs[0]
    head, rest = objs[k].split(b"stream\n", 1)
    lk = int(re.search(rb"/Length (\d+) 0 R", head).group(1))
    ln = int(re.search(rb"obj\s*(\d+)\s*endobj", objs[lk]).group(1))
    data = zlib.decompress(rest[:ln]).decode("latin1")
    new = _compact_content(data)
    if new is None:
        return False
    new = _local_content(new) or new
    z = _deflate(new.encode("latin1"))
    objs[k] = head + b"stream\n" + z + b"\nendstream\nendobj"
    objs[lk] = b"%d 0 obj\n%d\nendobj" % (lk, len(z))
    tail = b[b.index(b"trailer", m.end()):]
    tail = tail[:tail.index(b"startxref")]
    out = bytearray(b[:b.index(b"\n", b.index(b"\n") + 1) + 1])          # %PDF-x.y and the binary comment line
    pos = {}
    for kk in sorted(objs):
        pos[kk] = len(out)
        out += objs[kk] + b"\n"
    x = len(out)
    out += b"xref\n0 %d\n0000000000 65535 f \n" % nobj
    for kk in range(1, nobj):
        out += (b"%010d 00000 n \n" % pos[kk]) if kk in pos else b"0000000000 65535 f \n"
    out += tail + b"startxref\n%d\n%%%%EOF\n" % x
    open(path, "wb").write(bytes(out))
    return True


def grid(rows, cols, gap=0.25, title_h=0.42):
    """Column x-positions and width (Fig units) for `cols` equal panels across TEXTW, gap in cm."""
    w = (TEXTW - (cols - 1)*gap)/cols*CM
    xs = [j*(w + gap*CM) for j in range(cols)]
    return xs, w, title_h*CM


def build(rows, stem, gap=0.25, cell_aspect=None, title_lines=1, row_gap=0.12, **export_kw):
    """A grid of design panels across TEXTW.

    rows: list of rows, each a list of panel specs or None (an empty cell); a spec is a dict with g (nx, ny) and
    optional y_down (default True), title, title2 (a line above the title) and fibers. Columns have equal widths;
    with cell_aspect each panel fits a box w wide and cell_aspect*w high (centred), otherwise it fills the width.
    gap, row_gap in cm."""
    cols = max(len(r) for r in rows)
    w = (TEXTW - (cols - 1)*gap)/cols*CM
    line = 1.25*TITLE_PT/72.0*1200.0
    tsp = 0.12*CM + title_lines*line                   # room above a panel for its title lines
    fig = Figure()
    y = tsp
    for row in rows:
        hmax = 0.0
        for j, spec in enumerate(row):
            if spec is None:
                continue
            nx, ny = spec["g"].shape
            hp = w*ny/nx if cell_aspect is None else min(w*ny/nx, cell_aspect*w)
            wp = hp*nx/ny
            x0 = j*(w + gap*CM) + 0.5*(w - wp)
            fig.panel(x0, y, wp, spec["g"], y_down=spec.get("y_down", True), title=spec.get("title"),
                      title2=spec.get("title2"), fibers=spec.get("fibers", ()))
            hmax = max(hmax, hp)
        y += hmax + row_gap*CM + tsp
    fig.export(stem, height=y - tsp + 0.03*CM, **export_kw)


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "repack":            # figxfig.py repack a.pdf b.pdf ...
        for f in sys.argv[2:]:
            r = repack_pdf(f)
            print("  %s: %s" % (f, "left as it is" if r is None else "%d -> %d bytes (%.0f %%)" % (r[0], r[1], 100.0*r[1]/r[0] - 100)))
