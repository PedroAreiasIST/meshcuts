// SimplexRemesher.cs
//
// Copyright (C) 2026 Pedro Miguel de Almeida Areias
//
// This file is part of ManyToMany.
//
// ManyToMany is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// ManyToMany is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ManyToMany. If not, see <https://www.gnu.org/licenses/>.

// SimplexRemesher.cs - Unified mesh operations: generation, I/O, smoothing, cracks, quad conversion
// Consolidates: SimplexRemesher + MeshGeneration + UnifiedMesher + MeshOptimization + QuadConversion + CrackDuplication
// License: GPLv3

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using static Numerical.MeshConstants;
using static Numerical.MeshGeometry;

namespace Numerical;


/// <summary>
///     Unified mesh operations: generation, I/O, smoothing, crack insertion, quad conversion.
///     Consolidates all mesh manipulation into a single class.
/// </summary>
public static class SimplexRemesher
{
    // ═══════════════════════════════════════════════════════════════════════════
    // Mesh Generation - Structured Meshes
    // ═══════════════════════════════════════════════════════════════════════════

    public static (SimplexMesh Mesh, double[,] Coordinates) CreateRectangularMesh(
        int nx, int ny, double xMin, double xMax, double yMin, double yMax)
    {
        if (nx <= 0)
            throw new ArgumentOutOfRangeException(nameof(nx), nx, "nx must be > 0.");
        if (ny <= 0)
            throw new ArgumentOutOfRangeException(nameof(ny), ny, "ny must be > 0.");
        if (xMax <= xMin)
            throw new ArgumentException("xMax must be greater than xMin.", nameof(xMax));
        if (yMax <= yMin)
            throw new ArgumentException("yMax must be greater than yMin.", nameof(yMax));

        var mesh = new SimplexMesh();
        var coords = new double[(nx + 1) * (ny + 1), 3];

        double dx = (xMax - xMin) / nx;
        double dy = (yMax - yMin) / ny;

        mesh.WithBatch(() =>
        {
            for (int j = 0; j <= ny; j++)
            {
                for (int i = 0; i <= nx; i++)
                {
                    int idx = j * (nx + 1) + i;
                    coords[idx, 0] = xMin + i * dx;
                    coords[idx, 1] = yMin + j * dy;
                    coords[idx, 2] = 0.0;
                    mesh.AddNode(idx);
                }
            }

            for (int j = 0; j < ny; j++)
            {
                for (int i = 0; i < nx; i++)
                {
                    int n0 = j * (nx + 1) + i;
                    int n1 = n0 + 1;
                    int n2 = n0 + (nx + 1);
                    int n3 = n2 + 1;

                    mesh.AddTriangle(n0, n1, n2);
                    mesh.AddTriangle(n1, n3, n2);
                }
            }
        });

        return (mesh, coords);
    }

    public static (SimplexMesh Mesh, double[,] Coordinates) CreateRectangularMesh(int nx, int ny)
        => CreateRectangularMesh(nx, ny, 0, 1, 0, 1);

    public static (SimplexMesh Mesh, double[,] Coordinates) CreateRectangularQuadMesh(
        int nx, int ny, double xMin, double xMax, double yMin, double yMax)
    {
        if (nx <= 0)
            throw new ArgumentOutOfRangeException(nameof(nx), nx, "nx must be > 0.");
        if (ny <= 0)
            throw new ArgumentOutOfRangeException(nameof(ny), ny, "ny must be > 0.");
        if (xMax <= xMin)
            throw new ArgumentException("xMax must be greater than xMin.", nameof(xMax));
        if (yMax <= yMin)
            throw new ArgumentException("yMax must be greater than yMin.", nameof(yMax));

        var mesh = new SimplexMesh();
        var coords = new double[(nx + 1) * (ny + 1), 3];

        double dx = (xMax - xMin) / nx;
        double dy = (yMax - yMin) / ny;

        mesh.WithBatch(() =>
        {
            for (int j = 0; j <= ny; j++)
            {
                for (int i = 0; i <= nx; i++)
                {
                    int idx = j * (nx + 1) + i;
                    coords[idx, 0] = xMin + i * dx;
                    coords[idx, 1] = yMin + j * dy;
                    coords[idx, 2] = 0.0;
                    mesh.AddNode(idx);
                }
            }

            for (int j = 0; j < ny; j++)
            {
                for (int i = 0; i < nx; i++)
                {
                    int n0 = j * (nx + 1) + i;
                    int n1 = n0 + 1;
                    int n2 = n0 + (nx + 1);
                    int n3 = n2 + 1;

                    mesh.AddQuad(n0, n1, n3, n2);
                }
            }
        });

        return (mesh, coords);
    }

    public static (SimplexMesh Mesh, double[,] Coordinates) CreateUnitSquareMesh(int n)
        => CreateRectangularMesh(n, n, 0.0, 1.0, 0.0, 1.0);

    public static (SimplexMesh Mesh, double[,] Coordinates) CreateBoxMesh(
        int nx, int ny, int nz,
        double xMin, double xMax, double yMin, double yMax, double zMin, double zMax)
    {
        if (nx <= 0)
            throw new ArgumentOutOfRangeException(nameof(nx), nx, "nx must be > 0.");
        if (ny <= 0)
            throw new ArgumentOutOfRangeException(nameof(ny), ny, "ny must be > 0.");
        if (nz <= 0)
            throw new ArgumentOutOfRangeException(nameof(nz), nz, "nz must be > 0.");
        if (xMax <= xMin)
            throw new ArgumentException("xMax must be greater than xMin.", nameof(xMax));
        if (yMax <= yMin)
            throw new ArgumentException("yMax must be greater than yMin.", nameof(yMax));
        if (zMax <= zMin)
            throw new ArgumentException("zMax must be greater than zMin.", nameof(zMax));

        var mesh = new SimplexMesh();
        int nodeCount = (nx + 1) * (ny + 1) * (nz + 1);
        var coords = new double[nodeCount, 3];

        double dx = (xMax - xMin) / nx;
        double dy = (yMax - yMin) / ny;
        double dz = (zMax - zMin) / nz;

        int NodeIndex(int i, int j, int k) => k * (nx + 1) * (ny + 1) + j * (nx + 1) + i;

        mesh.WithBatch(() =>
        {
            for (int k = 0; k <= nz; k++)
                for (int j = 0; j <= ny; j++)
                    for (int i = 0; i <= nx; i++)
                    {
                        int idx = NodeIndex(i, j, k);
                        coords[idx, 0] = xMin + i * dx;
                        coords[idx, 1] = yMin + j * dy;
                        coords[idx, 2] = zMin + k * dz;
                        mesh.AddNode(idx);
                    }

            for (int k = 0; k < nz; k++)
                for (int j = 0; j < ny; j++)
                    for (int i = 0; i < nx; i++)
                    {
                        int n0 = NodeIndex(i, j, k);
                        int n1 = NodeIndex(i + 1, j, k);
                        int n2 = NodeIndex(i, j + 1, k);
                        int n3 = NodeIndex(i + 1, j + 1, k);
                        int n4 = NodeIndex(i, j, k + 1);
                        int n5 = NodeIndex(i + 1, j, k + 1);
                        int n6 = NodeIndex(i, j + 1, k + 1);
                        int n7 = NodeIndex(i + 1, j + 1, k + 1);

                        mesh.AddTetrahedron(n0, n1, n3, n7);
                        mesh.AddTetrahedron(n0, n3, n2, n7);
                        mesh.AddTetrahedron(n0, n2, n6, n7);
                        mesh.AddTetrahedron(n0, n6, n4, n7);
                        mesh.AddTetrahedron(n0, n4, n5, n7);
                        mesh.AddTetrahedron(n0, n5, n1, n7);
                    }
        });

        FixInvertedTetrahedra(mesh, coords);
        Console.WriteLine($"[CreateBoxMesh] Created {mesh.Count<Node>()} nodes, {mesh.Count<Tet4>()} tetrahedra");

        return (mesh, coords);
    }

    public static (SimplexMesh Mesh, double[,] Coordinates) CreateBoxMesh(int nx, int ny, int nz)
        => CreateBoxMesh(nx, ny, nz, 0, 1, 0, 1, 0, 1);

    public static (SimplexMesh Mesh, double[,] Coordinates) CreateUnitCubeMesh(int n)
        => CreateBoxMesh(n, n, n, 0.0, 1.0, 0.0, 1.0, 0.0, 1.0);

    private static void FixInvertedTetrahedra(SimplexMesh mesh, double[,] coords)
    {
        var tetsToFix = new List<(int index, int[] nodes)>();

        for (int i = 0; i < mesh.Count<Tet4>(); i++)
        {
            var nodes = mesh.NodesOf<Tet4, Node>(i);
            double jac = ComputeTetrahedronJacobian(coords, nodes[0], nodes[1], nodes[2], nodes[3]);

            if (jac <= 0)
                tetsToFix.Add((i, new[] { nodes[1], nodes[0], nodes[2], nodes[3] }));
        }

        // Fix in place: ReplaceElementNodes preserves the element index and OriginalElement mapping.
        // (The previous Remove+Add left the inverted tet marked-but-not-compacted, so without a Compress
        // it lingered as a ghost element; in-place replacement avoids that entirely.)
        foreach (var (index, swappedNodes) in tetsToFix)
            mesh.ReplaceElementNodes<Tet4, Node>(index, swappedNodes[0], swappedNodes[1], swappedNodes[2], swappedNodes[3]);

        if (tetsToFix.Count > 0)
            Console.WriteLine($"[CreateBoxMesh] Fixed {tetsToFix.Count} inverted tetrahedra");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Refinement Wrappers
    // ═══════════════════════════════════════════════════════════════════════════

    public static (SimplexMesh Mesh, int[] NodeRemap) Refine(
        SimplexMesh mesh, List<(int, int)> markedEdges)
        => MeshRefinement.Refine(mesh, markedEdges);

    public static (SimplexMesh Mesh, int[] NodeRemap) Refine(
        SimplexMesh mesh, IEnumerable<(int, int)> markedEdges)
        => MeshRefinement.Refine(mesh, markedEdges.ToList());

    public static double[,] InterpolateCoordinates(SimplexMesh refinedMesh, double[,] originalCoords)
        => MeshRefinement.InterpolateCoordinates(refinedMesh, originalCoords);

    // ═══════════════════════════════════════════════════════════════════════════
    // Edge Discovery
    // ═══════════════════════════════════════════════════════════════════════════

    public static void DiscoverEdges(SimplexMesh m)
    {
        if (m.Count<Edge>() > 0) return;
        if (m.Count<Bar2>() > 0) m.DiscoverSubEntities<Bar2, Edge, Node>(FiniteElementTopologies.Bar2Edge);
        if (m.Count<Tri3>() > 0) m.DiscoverSubEntities<Tri3, Edge, Node>(FiniteElementTopologies.Tri3Edges);
        if (m.Count<Tet4>() > 0) m.DiscoverSubEntities<Tet4, Edge, Node>(FiniteElementTopologies.Tet4Edges);
    }


    // ═══════════════════════════════════════════════════════════════════════════
    // Mesh I/O
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Save mesh to Gmsh .msh (MSH 2.2 ASCII) format.
    /// </summary>
    public static void SaveMSH(SimplexMesh mesh, double[,] coordinates, string path)
    {
        ArgumentNullException.ThrowIfNull(mesh);
        ArgumentNullException.ThrowIfNull(coordinates);
        ArgumentNullException.ThrowIfNull(path);

        int numNodes = mesh.Count<Node>();
        int numPoints = mesh.Count<Point>();
        int numBars = mesh.Count<Bar2>();
        int numTris = mesh.Count<Tri3>();
        int numTets = mesh.Count<Tet4>();
        int numElements = numPoints + numBars + numTris + numTets;

        using var writer = new StreamWriter(path);
        
        // Header
        writer.WriteLine("$MeshFormat");
        writer.WriteLine("2.2 0 8");
        writer.WriteLine("$EndMeshFormat");

        // Nodes
        writer.WriteLine("$Nodes");
        writer.WriteLine(numNodes);
        for (int i = 0; i < numNodes; i++)
            writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                "{0} {1} {2} {3}", i + 1, coordinates[i, 0], coordinates[i, 1], coordinates[i, 2]));
        writer.WriteLine("$EndNodes");

        // Elements
        writer.WriteLine("$Elements");
        writer.WriteLine(numElements);
        
        int elemId = 1;
        // Gmsh element types: 15=point, 1=line, 2=triangle, 4=tetrahedron
        
        for (int i = 0; i < numPoints; i++)
        {
            var n = mesh.NodesOf<Point, Node>(i);
            writer.WriteLine($"{elemId++} 15 2 0 0 {n[0] + 1}");
        }
        for (int i = 0; i < numBars; i++)
        {
            var n = mesh.NodesOf<Bar2, Node>(i);
            writer.WriteLine($"{elemId++} 1 2 0 0 {n[0] + 1} {n[1] + 1}");
        }
        for (int i = 0; i < numTris; i++)
        {
            var n = mesh.NodesOf<Tri3, Node>(i);
            writer.WriteLine($"{elemId++} 2 2 0 0 {n[0] + 1} {n[1] + 1} {n[2] + 1}");
        }
        for (int i = 0; i < numTets; i++)
        {
            var n = mesh.NodesOf<Tet4, Node>(i);
            writer.WriteLine($"{elemId++} 4 2 0 0 {n[0] + 1} {n[1] + 1} {n[2] + 1} {n[3] + 1}");
        }
        
        writer.WriteLine("$EndElements");
    }

    /// <summary>
    /// Saves a SimplexMesh to Gmsh MSH format (v2.2 ASCII) with element tags.
    /// Each element has exactly 2 tags: physical tag and elementary tag.
    /// </summary>
    /// <param name="mesh">Mesh to save</param>
    /// <param name="coordinates">Node coordinates</param>
    /// <param name="path">Output file path</param>
    /// <param name="physicalNames">Optional dictionary mapping physical tag to (dimension, name)</param>
    /// <param name="pointTags">Optional physical tags for Point elements (length must match Point count)</param>
    /// <param name="barTags">Optional physical tags for Bar2 elements (length must match Bar2 count)</param>
    /// <param name="triTags">Optional physical tags for Tri3 elements (length must match Tri3 count)</param>
    /// <param name="tetTags">Optional physical tags for Tet4 elements (length must match Tet4 count)</param>
    public static void SaveMSH(SimplexMesh mesh, double[,] coordinates, string path,
        Dictionary<int, (int Dimension, string Name)>? physicalNames = null,
        int[]? pointTags = null,
        int[]? barTags = null,
        int[]? triTags = null,
        int[]? tetTags = null)
    {
        ArgumentNullException.ThrowIfNull(mesh);
        ArgumentNullException.ThrowIfNull(coordinates);
        ArgumentNullException.ThrowIfNull(path);

        int numNodes = mesh.Count<Node>();
        int numPoints = mesh.Count<Point>();
        int numBars = mesh.Count<Bar2>();
        int numTris = mesh.Count<Tri3>();
        int numTets = mesh.Count<Tet4>();
        int numElements = numPoints + numBars + numTris + numTets;

        // Validate tag array lengths
        if (pointTags != null && pointTags.Length != numPoints)
            throw new ArgumentException($"pointTags length ({pointTags.Length}) must match Point count ({numPoints})");
        if (barTags != null && barTags.Length != numBars)
            throw new ArgumentException($"barTags length ({barTags.Length}) must match Bar2 count ({numBars})");
        if (triTags != null && triTags.Length != numTris)
            throw new ArgumentException($"triTags length ({triTags.Length}) must match Tri3 count ({numTris})");
        if (tetTags != null && tetTags.Length != numTets)
            throw new ArgumentException($"tetTags length ({tetTags.Length}) must match Tet4 count ({numTets})");

        using var writer = new StreamWriter(path);
        
        // Header
        writer.WriteLine("$MeshFormat");
        writer.WriteLine("2.2 0 8");
        writer.WriteLine("$EndMeshFormat");

        // Physical names section
        if (physicalNames != null && physicalNames.Count > 0)
        {
            writer.WriteLine("$PhysicalNames");
            writer.WriteLine(physicalNames.Count);
            foreach (var (id, (dim, name)) in physicalNames.OrderBy(kv => kv.Key))
                writer.WriteLine($"{dim} {id} \"{name}\"");
            writer.WriteLine("$EndPhysicalNames");
        }

        // Nodes
        writer.WriteLine("$Nodes");
        writer.WriteLine(numNodes);
        for (int i = 0; i < numNodes; i++)
            writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                "{0} {1} {2} {3}", i + 1, coordinates[i, 0], coordinates[i, 1], coordinates[i, 2]));
        writer.WriteLine("$EndNodes");

        // Elements with physical tags
        // Format: elem-id type num-tags physical-tag elementary-tag node1 node2 ...
        writer.WriteLine("$Elements");
        writer.WriteLine(numElements);
        
        int elemId = 1;
        // Gmsh element types: 15=point, 1=line, 2=triangle, 4=tetrahedron
        
        for (int i = 0; i < numPoints; i++)
        {
            var n = mesh.NodesOf<Point, Node>(i);
            int physTag = pointTags?[i] ?? 0;
            writer.WriteLine($"{elemId++} 15 2 {physTag} 0 {n[0] + 1}");
        }
        for (int i = 0; i < numBars; i++)
        {
            var n = mesh.NodesOf<Bar2, Node>(i);
            int physTag = barTags?[i] ?? 0;
            writer.WriteLine($"{elemId++} 1 2 {physTag} 0 {n[0] + 1} {n[1] + 1}");
        }
        for (int i = 0; i < numTris; i++)
        {
            var n = mesh.NodesOf<Tri3, Node>(i);
            int physTag = triTags?[i] ?? 0;
            writer.WriteLine($"{elemId++} 2 2 {physTag} 0 {n[0] + 1} {n[1] + 1} {n[2] + 1}");
        }
        for (int i = 0; i < numTets; i++)
        {
            var n = mesh.NodesOf<Tet4, Node>(i);
            int physTag = tetTags?[i] ?? 0;
            writer.WriteLine($"{elemId++} 4 2 {physTag} 0 {n[0] + 1} {n[1] + 1} {n[2] + 1} {n[3] + 1}");
        }
        
        writer.WriteLine("$EndElements");
    }

    /// <summary>
    /// Saves a SimplexMesh to Gmsh MSH format with cracked/non-cracked element classification.
    /// Convenience overload that creates physical groups based on a set of cracked element indices.
    /// </summary>
    /// <param name="mesh">Mesh to save</param>
    /// <param name="coordinates">Node coordinates</param>
    /// <param name="path">Output file path</param>
    /// <param name="crackedTriangles">Set of cracked Tri3 element indices (0-based)</param>
    /// <param name="crackedTetrahedra">Set of cracked Tet4 element indices (0-based)</param>
    /// <param name="intactGroupId">Tag for intact elements (default: 1)</param>
    /// <param name="crackedGroupId">Tag for cracked elements (default: 2)</param>
    public static void SaveMSHWithCrackGroups(SimplexMesh mesh, double[,] coordinates, string path,
        HashSet<int>? crackedTriangles = null,
        HashSet<int>? crackedTetrahedra = null,
        int intactGroupId = 1,
        int crackedGroupId = 2)
    {
        ArgumentNullException.ThrowIfNull(mesh);
        ArgumentNullException.ThrowIfNull(coordinates);
        ArgumentNullException.ThrowIfNull(path);

        int numTris = mesh.Count<Tri3>();
        int numTets = mesh.Count<Tet4>();

        // Build tag arrays
        int[]? triTags = null;
        int[]? tetTags = null;

        if (crackedTriangles != null || numTris > 0)
        {
            triTags = new int[numTris];
            for (int i = 0; i < numTris; i++)
                triTags[i] = (crackedTriangles?.Contains(i) == true) ? crackedGroupId : intactGroupId;
        }

        if (crackedTetrahedra != null || numTets > 0)
        {
            tetTags = new int[numTets];
            for (int i = 0; i < numTets; i++)
                tetTags[i] = (crackedTetrahedra?.Contains(i) == true) ? crackedGroupId : intactGroupId;
        }

        // Determine dimensionality for physical names
        int dim = numTets > 0 ? 3 : 2;
        
        var physicalNames = new Dictionary<int, (int Dimension, string Name)>
        {
            { intactGroupId, (dim, "NonCracked") },
            { crackedGroupId, (dim, "Cracked") }
        };

        SaveMSH(mesh, coordinates, path, physicalNames,
            pointTags: null, barTags: null, triTags: triTags, tetTags: tetTags);
    }

    /// <summary>
    /// Saves mesh to simple ASCII format for debugging.
    /// </summary>
    public static void SaveASCII(SimplexMesh mesh, double[,] coordinates, string path)
    {
        ArgumentNullException.ThrowIfNull(mesh);
        ArgumentNullException.ThrowIfNull(coordinates);
        ArgumentNullException.ThrowIfNull(path);

        int numNodes = mesh.Count<Node>();
        int numTris = mesh.Count<Tri3>();
        int numTets = mesh.Count<Tet4>();

        using var writer = new StreamWriter(path);
        
        writer.WriteLine($"# SimplexMesh ASCII format");
        writer.WriteLine($"# Nodes: {numNodes}");
        writer.WriteLine($"# Tri3: {numTris}");
        writer.WriteLine($"# Tet4: {numTets}");
        writer.WriteLine();

        writer.WriteLine("COORDINATES");
        writer.WriteLine(numNodes);
        for (int i = 0; i < numNodes; i++)
            writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                "{0} {1} {2}", coordinates[i, 0], coordinates[i, 1], coordinates[i, 2]));
        writer.WriteLine();

        if (numTris > 0)
        {
            writer.WriteLine("TRIANGLES");
            writer.WriteLine(numTris);
            for (int i = 0; i < numTris; i++)
            {
                var n = mesh.NodesOf<Tri3, Node>(i);
                writer.WriteLine($"{n[0]} {n[1]} {n[2]}");
            }
            writer.WriteLine();
        }

        if (numTets > 0)
        {
            writer.WriteLine("TETRAHEDRA");
            writer.WriteLine(numTets);
            for (int i = 0; i < numTets; i++)
            {
                var n = mesh.NodesOf<Tet4, Node>(i);
                writer.WriteLine($"{n[0]} {n[1]} {n[2]} {n[3]}");
            }
        }
    }

    /// <summary>
    /// Prints mesh statistics to console for debugging.
    /// </summary>
    public static void PrintStats(SimplexMesh mesh, string label = "Mesh")
    {
        Console.WriteLine($"=== {label} ===");
        Console.WriteLine($"  Nodes: {mesh.Count<Node>()}");
        Console.WriteLine($"  Edges: {mesh.Count<Edge>()}");
        Console.WriteLine($"  Points: {mesh.Count<Point>()}");
        Console.WriteLine($"  Bar2: {mesh.Count<Bar2>()}");
        Console.WriteLine($"  Tri3: {mesh.Count<Tri3>()}");
        Console.WriteLine($"  Tet4: {mesh.Count<Tet4>()}");
    }
    public static (SimplexMesh Mesh, double[,] Coordinates) LoadMSH(string path)
    {
        ArgumentNullException.ThrowIfNull(path);
        if (!File.Exists(path))
            throw new FileNotFoundException($"MSH file not found: {path}");

        using var reader = new StreamReader(path);
        return ParseMSH(reader);
    }

    /// <summary>
    /// Loads a SimplexMesh from a Gmsh MSH file, also returning physical tags per element type.
    /// </summary>
    /// <param name="path">Path to the .msh file</param>
    /// <returns>Loaded mesh, coordinates, and physical tags for each element type</returns>
    public static (SimplexMesh Mesh, double[,] Coordinates, 
        Dictionary<int, (int Dimension, string Name)> PhysicalNames,
        int[] PointTags, int[] BarTags, int[] TriTags, int[] TetTags) LoadMSHWithTags(string path)
    {
        ArgumentNullException.ThrowIfNull(path);
        if (!File.Exists(path))
            throw new FileNotFoundException($"MSH file not found: {path}");

        using var reader = new StreamReader(path);
        return ParseMSHWithTags(reader);
    }

    private static (SimplexMesh Mesh, double[,] Coordinates) ParseMSH(StreamReader reader)
    {
        var (mesh, coords, _, _, _, _, _) = ParseMSHWithTags(reader);
        return (mesh, coords);
    }

    private static (SimplexMesh Mesh, double[,] Coordinates,
        Dictionary<int, (int Dimension, string Name)> PhysicalNames,
        int[] PointTags, int[] BarTags, int[] TriTags, int[] TetTags) ParseMSHWithTags(StreamReader reader)
    {
        var physicalNames = new Dictionary<int, (int Dimension, string Name)>();
        double[,]? coordinates = null;
        var elements = new List<(int ElemType, int PhysTag, int[] Nodes)>();

        string? line;
        while ((line = reader.ReadLine()) != null)
        {
            line = line.Trim();
            
            if (line == "$MeshFormat")
            {
                line = reader.ReadLine()?.Trim();
                if (line != null)
                {
                    var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    double version = double.Parse(parts[0], CultureInfo.InvariantCulture);
                    if (version < 2.0 || version >= 3.0)
                        Console.WriteLine($"Warning: Expected Gmsh 2.x format, got {version}");
                }
                SkipToEndSection(reader, "$EndMeshFormat");
            }
            else if (line == "$PhysicalNames")
            {
                line = reader.ReadLine()?.Trim();
                int numNames = int.Parse(line!, CultureInfo.InvariantCulture);
                for (int i = 0; i < numNames; i++)
                {
                    line = reader.ReadLine()?.Trim();
                    if (line == null) break;
                    var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    int dim = int.Parse(parts[0], CultureInfo.InvariantCulture);
                    int id = int.Parse(parts[1], CultureInfo.InvariantCulture);
                    string name = parts[2].Trim('"');
                    physicalNames[id] = (dim, name);
                }
                SkipToEndSection(reader, "$EndPhysicalNames");
            }
            else if (line == "$Nodes")
            {
                line = reader.ReadLine()?.Trim();
                int nodeCount = int.Parse(line!, CultureInfo.InvariantCulture);
                coordinates = new double[nodeCount, 3];
                
                for (int i = 0; i < nodeCount; i++)
                {
                    line = reader.ReadLine()?.Trim();
                    if (line == null) break;
                    var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    int nodeId = int.Parse(parts[0], CultureInfo.InvariantCulture) - 1; // 0-based
                    coordinates[nodeId, 0] = double.Parse(parts[1], CultureInfo.InvariantCulture);
                    coordinates[nodeId, 1] = double.Parse(parts[2], CultureInfo.InvariantCulture);
                    coordinates[nodeId, 2] = double.Parse(parts[3], CultureInfo.InvariantCulture);
                }
                SkipToEndSection(reader, "$EndNodes");
            }
            else if (line == "$Elements")
            {
                line = reader.ReadLine()?.Trim();
                int numElements = int.Parse(line!, CultureInfo.InvariantCulture);
                
                for (int i = 0; i < numElements; i++)
                {
                    line = reader.ReadLine()?.Trim();
                    if (line == null) break;
                    var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    // Format: elem-id type num-tags [tags...] node1 node2 ...
                    int elemType = int.Parse(parts[1], CultureInfo.InvariantCulture);
                    int numTags = int.Parse(parts[2], CultureInfo.InvariantCulture);
                    int physTag = numTags > 0 ? int.Parse(parts[3], CultureInfo.InvariantCulture) : 0;
                    
                    int nodeStart = 3 + numTags;
                    var nodes = new int[parts.Length - nodeStart];
                    for (int j = 0; j < nodes.Length; j++)
                        nodes[j] = int.Parse(parts[nodeStart + j], CultureInfo.InvariantCulture) - 1; // 0-based
                    
                    elements.Add((elemType, physTag, nodes));
                }
                SkipToEndSection(reader, "$EndElements");
            }
            else if (line.StartsWith("$"))
            {
                // Skip unknown sections
                string endMarker = "$End" + line.Substring(1);
                SkipToEndSection(reader, endMarker);
            }
        }

        if (coordinates == null)
            throw new FormatException("MSH file missing $Nodes section");

        // Build mesh and collect tags by element type
        // Gmsh types: 15=point, 1=line, 2=triangle, 4=tetrahedron
        var pointList = new List<(int PhysTag, int[] Nodes)>();
        var barList = new List<(int PhysTag, int[] Nodes)>();
        var triList = new List<(int PhysTag, int[] Nodes)>();
        var tetList = new List<(int PhysTag, int[] Nodes)>();

        foreach (var (elemType, physTag, nodes) in elements)
        {
            switch (elemType)
            {
                case 15: // Point
                    pointList.Add((physTag, nodes));
                    break;
                case 1: // 2-node line
                case 8: // 3-node line (quadratic) - treat as linear
                    barList.Add((physTag, new[] { nodes[0], nodes[1] }));
                    break;
                case 2: // 3-node triangle
                case 9: // 6-node triangle (quadratic) - treat as linear
                    triList.Add((physTag, new[] { nodes[0], nodes[1], nodes[2] }));
                    break;
                case 4: // 4-node tetrahedron
                case 11: // 10-node tetrahedron (quadratic) - treat as linear
                    tetList.Add((physTag, new[] { nodes[0], nodes[1], nodes[2], nodes[3] }));
                    break;
            }
        }

        var mesh = new SimplexMesh();
        int numNodes = coordinates.GetLength(0);

        mesh.WithBatch(() =>
        {
            for (int i = 0; i < numNodes; i++)
            {
                mesh.Add<Node>();
                mesh.Set<Node, ParentNodes>(i, new ParentNodes(i, i));
            }

            foreach (var (_, nodes) in pointList)
            {
                int pi = mesh.Add<Point, Node>(nodes[0]);
                mesh.Set<Point, OriginalElement>(pi, new OriginalElement(pi));
            }
            foreach (var (_, nodes) in barList)
            {
                int bi = mesh.Add<Bar2, Node>(nodes[0], nodes[1]);
                mesh.Set<Bar2, OriginalElement>(bi, new OriginalElement(bi));
            }
            foreach (var (_, nodes) in triList)
            {
                int ti = mesh.Add<Tri3, Node>(nodes[0], nodes[1], nodes[2]);
                mesh.Set<Tri3, OriginalElement>(ti, new OriginalElement(ti));
            }
            foreach (var (_, nodes) in tetList)
            {
                int ei = mesh.Add<Tet4, Node>(nodes[0], nodes[1], nodes[2], nodes[3]);
                mesh.Set<Tet4, OriginalElement>(ei, new OriginalElement(ei));
            }
        });

        return (mesh, coordinates, physicalNames,
            pointList.Select(x => x.PhysTag).ToArray(),
            barList.Select(x => x.PhysTag).ToArray(),
            triList.Select(x => x.PhysTag).ToArray(),
            tetList.Select(x => x.PhysTag).ToArray());
    }

    private static void SkipToEndSection(StreamReader reader, string endMarker)
    {
        string? line;
        while ((line = reader.ReadLine()) != null)
        {
            if (line.Trim() == endMarker) break;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // GiD/CIMNE Mesh I/O
    // ═══════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Loads a SimplexMesh from a GiD/CIMNE mesh file (.msh).
    /// </summary>
    /// <param name="path">Path to the .msh file</param>
    /// <returns>Loaded mesh and coordinates</returns>
    public static (SimplexMesh Mesh, double[,] Coordinates) LoadGiD(string path)
    {
        ArgumentNullException.ThrowIfNull(path);
        if (!File.Exists(path))
            throw new FileNotFoundException($"GiD mesh file not found: {path}");

        using var reader = new StreamReader(path);
        return ParseGiD(reader);
    }

    /// <summary>
    /// Loads a SimplexMesh from a GiD/CIMNE mesh file, also returning material IDs.
    /// </summary>
    /// <param name="path">Path to the .msh file</param>
    /// <returns>Loaded mesh, coordinates, and material IDs for each element type</returns>
    public static (SimplexMesh Mesh, double[,] Coordinates,
        int[] PointMaterials, int[] BarMaterials, int[] TriMaterials, int[] TetMaterials) LoadGiDWithMaterials(string path)
    {
        ArgumentNullException.ThrowIfNull(path);
        if (!File.Exists(path))
            throw new FileNotFoundException($"GiD mesh file not found: {path}");

        using var reader = new StreamReader(path);
        return ParseGiDWithMaterials(reader);
    }

    private static (SimplexMesh Mesh, double[,] Coordinates) ParseGiD(StreamReader reader)
    {
        var (mesh, coords, _, _, _, _) = ParseGiDWithMaterials(reader);
        return (mesh, coords);
    }

    private static (SimplexMesh Mesh, double[,] Coordinates,
        int[] PointMaterials, int[] BarMaterials, int[] TriMaterials, int[] TetMaterials) ParseGiDWithMaterials(StreamReader reader)
    {
        var nodeCoords = new Dictionary<int, (double X, double Y, double Z)>();
        var pointList = new List<(int Material, int[] Nodes)>();
        var barList = new List<(int Material, int[] Nodes)>();
        var triList = new List<(int Material, int[] Nodes)>();
        var tetList = new List<(int Material, int[] Nodes)>();

        int dimension = 3;
        string currentElemType = "";
        int currentNnode = 0;
        bool inCoordinates = false;
        bool inElements = false;

        string? line;
        while ((line = reader.ReadLine()) != null)
        {
            line = line.Trim();
            if (string.IsNullOrEmpty(line) || line.StartsWith("#")) continue;

            var upperLine = line.ToUpperInvariant();

            // Parse MESH header: MESH dimension D ElemType TypeName Nnode N
            if (upperLine.StartsWith("MESH"))
            {
                var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < parts.Length - 1; i++)
                {
                    var key = parts[i].ToUpperInvariant();
                    if (key == "DIMENSION" && i + 1 < parts.Length)
                        dimension = int.Parse(parts[i + 1], CultureInfo.InvariantCulture);
                    else if (key == "ELEMTYPE" && i + 1 < parts.Length)
                        currentElemType = parts[i + 1].ToUpperInvariant();
                    else if (key == "NNODE" && i + 1 < parts.Length)
                        currentNnode = int.Parse(parts[i + 1], CultureInfo.InvariantCulture);
                }
                continue;
            }

            if (upperLine == "COORDINATES")
            {
                inCoordinates = true;
                inElements = false;
                continue;
            }
            if (upperLine == "END COORDINATES")
            {
                inCoordinates = false;
                continue;
            }
            if (upperLine == "ELEMENTS")
            {
                inElements = true;
                inCoordinates = false;
                continue;
            }
            if (upperLine == "END ELEMENTS")
            {
                inElements = false;
                continue;
            }

            if (inCoordinates)
            {
                var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length >= 3)
                {
                    int nodeId = int.Parse(parts[0], CultureInfo.InvariantCulture);
                    double x = double.Parse(parts[1], CultureInfo.InvariantCulture);
                    double y = double.Parse(parts[2], CultureInfo.InvariantCulture);
                    double z = parts.Length > 3 ? double.Parse(parts[3], CultureInfo.InvariantCulture) : 0.0;
                    nodeCoords[nodeId] = (x, y, z);
                }
            }
            else if (inElements)
            {
                var parts = line.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length < 2) continue;

                // Format: elem-id node1 node2 ... [material]
                // Node count determined by currentNnode or element type
                int nNodes = currentNnode > 0 ? currentNnode : GuessNodeCount(currentElemType);
                if (parts.Length < 1 + nNodes) continue;

                var nodes = new int[nNodes];
                for (int j = 0; j < nNodes; j++)
                    nodes[j] = int.Parse(parts[1 + j], CultureInfo.InvariantCulture);
                
                // Material is the last column (optional)
                int material = parts.Length > 1 + nNodes 
                    ? int.Parse(parts[1 + nNodes], CultureInfo.InvariantCulture) 
                    : 0;

                // Classify by element type
                switch (currentElemType)
                {
                    case "POINT":
                        pointList.Add((material, nodes));
                        break;
                    case "LINEAR":
                    case "LINE":
                        barList.Add((material, new[] { nodes[0], nodes[1] }));
                        break;
                    case "TRIANGLE":
                        triList.Add((material, new[] { nodes[0], nodes[1], nodes[2] }));
                        break;
                    case "TETRAHEDRA":
                    case "TETRAHEDRON":
                        tetList.Add((material, new[] { nodes[0], nodes[1], nodes[2], nodes[3] }));
                        break;
                    default:
                        // Guess from node count
                        if (nNodes == 1) pointList.Add((material, nodes));
                        else if (nNodes == 2) barList.Add((material, nodes));
                        else if (nNodes == 3) triList.Add((material, nodes));
                        else if (nNodes == 4) tetList.Add((material, nodes));
                        break;
                }
            }
        }

        if (nodeCoords.Count == 0)
            throw new FormatException("GiD mesh file has no coordinates");

        // Build node array (GiD uses 1-based, need to map to 0-based)
        int maxNodeId = nodeCoords.Keys.Max();
        int minNodeId = nodeCoords.Keys.Min();
        int numNodes = nodeCoords.Count;
        var coordinates = new double[numNodes, 3];
        var nodeIdMap = new Dictionary<int, int>(); // old id -> new 0-based id

        int idx = 0;
        foreach (var nodeId in nodeCoords.Keys.OrderBy(x => x))
        {
            var (x, y, z) = nodeCoords[nodeId];
            coordinates[idx, 0] = x;
            coordinates[idx, 1] = y;
            coordinates[idx, 2] = z;
            nodeIdMap[nodeId] = idx;
            idx++;
        }

        // Remap element node IDs
        void RemapNodes(int[] nodes)
        {
            for (int i = 0; i < nodes.Length; i++)
                nodes[i] = nodeIdMap[nodes[i]];
        }

        foreach (var (_, nodes) in pointList) RemapNodes(nodes);
        foreach (var (_, nodes) in barList) RemapNodes(nodes);
        foreach (var (_, nodes) in triList) RemapNodes(nodes);
        foreach (var (_, nodes) in tetList) RemapNodes(nodes);

        // Build mesh
        var mesh = new SimplexMesh();
        mesh.WithBatch(() =>
        {
            for (int i = 0; i < numNodes; i++)
            {
                mesh.Add<Node>();
                mesh.Set<Node, ParentNodes>(i, new ParentNodes(i, i));
            }

            foreach (var (_, nodes) in pointList)
            {
                int pi = mesh.Add<Point, Node>(nodes[0]);
                mesh.Set<Point, OriginalElement>(pi, new OriginalElement(pi));
            }
            foreach (var (_, nodes) in barList)
            {
                int bi = mesh.Add<Bar2, Node>(nodes[0], nodes[1]);
                mesh.Set<Bar2, OriginalElement>(bi, new OriginalElement(bi));
            }
            foreach (var (_, nodes) in triList)
            {
                int ti = mesh.Add<Tri3, Node>(nodes[0], nodes[1], nodes[2]);
                mesh.Set<Tri3, OriginalElement>(ti, new OriginalElement(ti));
            }
            foreach (var (_, nodes) in tetList)
            {
                int ei = mesh.Add<Tet4, Node>(nodes[0], nodes[1], nodes[2], nodes[3]);
                mesh.Set<Tet4, OriginalElement>(ei, new OriginalElement(ei));
            }
        });

        return (mesh, coordinates,
            pointList.Select(x => x.Material).ToArray(),
            barList.Select(x => x.Material).ToArray(),
            triList.Select(x => x.Material).ToArray(),
            tetList.Select(x => x.Material).ToArray());
    }

    private static int GuessNodeCount(string elemType) => elemType switch
    {
        "POINT" => 1,
        "LINEAR" or "LINE" => 2,
        "TRIANGLE" => 3,
        "QUADRILATERAL" => 4,
        "TETRAHEDRA" or "TETRAHEDRON" => 4,
        "HEXAHEDRA" or "HEXAHEDRON" => 8,
        "PRISM" => 6,
        "PYRAMID" => 5,
        _ => 0
    };

    /// <summary>
    /// Saves a SimplexMesh to GiD/CIMNE mesh format (.msh).
    /// </summary>
    /// <param name="mesh">Mesh to save</param>
    /// <param name="coordinates">Node coordinates</param>
    /// <param name="path">Output file path</param>
    public static void SaveGiD(SimplexMesh mesh, double[,] coordinates, string path)
    {
        SaveGiD(mesh, coordinates, path, null, null, null, null, null);
    }

    /// <summary>
    /// Saves a SimplexMesh to GiD/CIMNE mesh format (.msh) with material IDs.
    /// GUARANTEES continuous node and element numbering with no gaps.
    /// </summary>
    /// <param name="mesh">Mesh to save</param>
    /// <param name="coordinates">Node coordinates</param>
    /// <param name="path">Output file path</param>
    /// <param name="pointMaterials">Optional material IDs for Point elements</param>
    /// <param name="barMaterials">Optional material IDs for Bar2 elements</param>
    /// <param name="triMaterials">Optional material IDs for Tri3 elements</param>
    /// <param name="tetMaterials">Optional material IDs for Tet4 elements</param>
    /// <param name="meshName">Optional mesh name for GiD header</param>
    public static void SaveGiD(SimplexMesh mesh, double[,] coordinates, string path,
        int[]? pointMaterials,
        int[]? barMaterials,
        int[]? triMaterials,
        int[]? quadMaterials,
        int[]? tetMaterials,
        string? meshName = null)
    {
        ArgumentNullException.ThrowIfNull(mesh);
        ArgumentNullException.ThrowIfNull(coordinates);
        ArgumentNullException.ThrowIfNull(path);

        int numPoints = mesh.Count<Point>();
        int numBars = mesh.Count<Bar2>();
        int numTris = mesh.Count<Tri3>();
        int numQuads = mesh.Count<Quad4>();
        int numTets = mesh.Count<Tet4>();
        int numElements = numPoints + numBars + numTris + numQuads + numTets;

        // Validate material array lengths
        if (pointMaterials != null && pointMaterials.Length != numPoints)
            throw new ArgumentException($"pointMaterials length ({pointMaterials.Length}) must match Point count ({numPoints})");
        if (barMaterials != null && barMaterials.Length != numBars)
            throw new ArgumentException($"barMaterials length ({barMaterials.Length}) must match Bar2 count ({numBars})");
        if (triMaterials != null && triMaterials.Length != numTris)
            throw new ArgumentException($"triMaterials length ({triMaterials.Length}) must match Tri3 count ({numTris})");
        if (quadMaterials != null && quadMaterials.Length != numQuads)
            throw new ArgumentException($"quadMaterials length ({quadMaterials.Length}) must match Quad4 count ({numQuads})");
        if (tetMaterials != null && tetMaterials.Length != numTets)
            throw new ArgumentException($"tetMaterials length ({tetMaterials.Length}) must match Tet4 count ({numTets})");

        // STEP 1: Collect all active nodes (nodes referenced by elements)
        var activeNodes = new HashSet<int>();
        
        for (int i = 0; i < numPoints; i++)
        {
            var n = mesh.NodesOf<Point, Node>(i);
            activeNodes.Add(n[0]);
        }
        
        for (int i = 0; i < numBars; i++)
        {
            var n = mesh.NodesOf<Bar2, Node>(i);
            activeNodes.Add(n[0]);
            activeNodes.Add(n[1]);
        }
        
        for (int i = 0; i < numTris; i++)
        {
            var n = mesh.NodesOf<Tri3, Node>(i);
            activeNodes.Add(n[0]);
            activeNodes.Add(n[1]);
            activeNodes.Add(n[2]);
        }
        
        for (int i = 0; i < numQuads; i++)
        {
            var n = mesh.NodesOf<Quad4, Node>(i);
            activeNodes.Add(n[0]);
            activeNodes.Add(n[1]);
            activeNodes.Add(n[2]);
            activeNodes.Add(n[3]);
        }
        
        for (int i = 0; i < numTets; i++)
        {
            var n = mesh.NodesOf<Tet4, Node>(i);
            activeNodes.Add(n[0]);
            activeNodes.Add(n[1]);
            activeNodes.Add(n[2]);
            activeNodes.Add(n[3]);
        }
        
        // STEP 2: Create continuous node numbering: oldID -> newID (1, 2, 3, ...)
        var nodeMap = new Dictionary<int, int>();
        var sortedNodes = activeNodes.OrderBy(n => n).ToArray();
        
        for (int i = 0; i < sortedNodes.Length; i++)
        {
            nodeMap[sortedNodes[i]] = i + 1;  // GiD uses 1-based indexing
        }
        
        int numActiveNodes = sortedNodes.Length;
        
        Console.WriteLine($"[SaveGiD] Mesh has {mesh.Count<Node>()} node IDs, {numActiveNodes} active nodes");
        if (numActiveNodes < mesh.Count<Node>())
        {
            Console.WriteLine($"[SaveGiD] Removed {mesh.Count<Node>() - numActiveNodes} unused nodes (gaps eliminated)");
        }

        // Determine mesh dimension
        int dimension = numTets > 0 ? 3 : (numTris > 0 ? 2 : 1);

        // Ensure path has .msh extension
        if (!path.EndsWith(".msh", StringComparison.OrdinalIgnoreCase))
        {
            path = path + ".msh";
        }

        using var writer = new StreamWriter(path);
        
        // Write mesh information header
        writer.WriteLine("# GiD/CIMNE Mesh File");
        writer.WriteLine($"# Generated by SimplexRemesher with continuous numbering");
        if (!string.IsNullOrEmpty(meshName))
            writer.WriteLine($"# Mesh name: {meshName}");
        writer.WriteLine($"# Dimension: {dimension}");
        writer.WriteLine($"# Nodes: {numActiveNodes} (continuous 1-based)");
        writer.WriteLine($"# Elements: {numElements} total");
        writer.WriteLine("#   Tets: {0}, Quads: {1}, Tris: {2}, Bars: {3}, Points: {4}",
            numTets, numQuads, numTris, numBars, numPoints);
        writer.WriteLine();
        
        int currentElementId = 1; // Track continuous element numbering across types

        // Write bulk elements first (highest dimension), then lower-dimensional
        // GiD groups elements by type in separate MESH blocks
        // Each MESH block MUST have its own Coordinates section

        // Tetrahedra
        if (numTets > 0)
        {
            writer.WriteLine($"MESH dimension {dimension} ElemType Tetrahedra Nnode 4");
            WriteGiDCoordinatesWithMapping(writer, coordinates, sortedNodes, dimension);
            writer.WriteLine("Elements");
            for (int i = 0; i < numTets; i++)
            {
                var n = mesh.NodesOf<Tet4, Node>(i);
                int mat = tetMaterials?[i] ?? 0;
                writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                    "  {0}  {1}  {2}  {3}  {4}  {5}", 
                    currentElementId++,  // Continuous numbering
                    nodeMap[n[0]], nodeMap[n[1]], nodeMap[n[2]], nodeMap[n[3]], 
                    mat));
            }
            writer.WriteLine("End Elements");
            writer.WriteLine();
        }

        // Quadrilaterals
        if (numQuads > 0)
        {
            writer.WriteLine($"MESH dimension {dimension} ElemType Quadrilateral Nnode 4");
            WriteGiDCoordinatesWithMapping(writer, coordinates, sortedNodes, dimension);
            writer.WriteLine("Elements");
            for (int i = 0; i < numQuads; i++)
            {
                var n = mesh.NodesOf<Quad4, Node>(i);
                int mat = quadMaterials?[i] ?? 0;
                writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                    "  {0}  {1}  {2}  {3}  {4}  {5}", 
                    currentElementId++,  // Continuous numbering
                    nodeMap[n[0]], nodeMap[n[1]], nodeMap[n[2]], nodeMap[n[3]], 
                    mat));
            }
            writer.WriteLine("End Elements");
            writer.WriteLine();
        }

        // Triangles
        if (numTris > 0)
        {
            writer.WriteLine($"MESH dimension {dimension} ElemType Triangle Nnode 3");
            WriteGiDCoordinatesWithMapping(writer, coordinates, sortedNodes, dimension);
            writer.WriteLine("Elements");
            for (int i = 0; i < numTris; i++)
            {
                var n = mesh.NodesOf<Tri3, Node>(i);
                int mat = triMaterials?[i] ?? 0;
                writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                    "  {0}  {1}  {2}  {3}  {4}", 
                    currentElementId++,  // Continuous numbering
                    nodeMap[n[0]], nodeMap[n[1]], nodeMap[n[2]], 
                    mat));
            }
            writer.WriteLine("End Elements");
            writer.WriteLine();
        }

        // Lines/Bars
        if (numBars > 0)
        {
            writer.WriteLine($"MESH dimension {dimension} ElemType Linear Nnode 2");
            WriteGiDCoordinatesWithMapping(writer, coordinates, sortedNodes, dimension);
            writer.WriteLine("Elements");
            for (int i = 0; i < numBars; i++)
            {
                var n = mesh.NodesOf<Bar2, Node>(i);
                int mat = barMaterials?[i] ?? 0;
                writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                    "  {0}  {1}  {2}  {3}", 
                    currentElementId++,  // Continuous numbering
                    nodeMap[n[0]], nodeMap[n[1]], 
                    mat));
            }
            writer.WriteLine("End Elements");
            writer.WriteLine();
        }

        // Points
        if (numPoints > 0)
        {
            writer.WriteLine($"MESH dimension {dimension} ElemType Point Nnode 1");
            WriteGiDCoordinatesWithMapping(writer, coordinates, sortedNodes, dimension);
            writer.WriteLine("Elements");
            for (int i = 0; i < numPoints; i++)
            {
                var n = mesh.NodesOf<Point, Node>(i);
                int mat = pointMaterials?[i] ?? 0;
                writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                    "  {0}  {1}  {2}", 
                    currentElementId++,  // Continuous numbering
                    nodeMap[n[0]], 
                    mat));
            }
            writer.WriteLine("End Elements");
            writer.WriteLine();
        }
        
        Console.WriteLine($"[SaveGiD] ✓ Saved to {path} with continuous numbering (no gaps)");
    }

    private static void WriteGiDCoordinatesWithMapping(StreamWriter writer, double[,] coordinates, int[] sortedNodes, int dimension)
    {
        writer.WriteLine("Coordinates");
        for (int i = 0; i < sortedNodes.Length; i++)
        {
            int oldNodeId = sortedNodes[i];
            int newNodeId = i + 1;  // GiD uses 1-based indexing
            
            if (dimension == 2)
                writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                    "  {0}  {1}  {2}", newNodeId, coordinates[oldNodeId, 0], coordinates[oldNodeId, 1]));
            else
                writer.WriteLine(string.Format(CultureInfo.InvariantCulture,
                    "  {0}  {1}  {2}  {3}", newNodeId, coordinates[oldNodeId, 0], coordinates[oldNodeId, 1], coordinates[oldNodeId, 2]));
        }
        writer.WriteLine("End Coordinates");
        writer.WriteLine();
    }
    
    // ========================================================================
    // SIGNED FIELD CRACK INSERTION
    // ========================================================================
    
    /// <summary>
    /// Signed field function delegate for level set crack insertion.
    /// Returns: positive on one side, negative on other side, zero on crack.
    /// </summary>
    /// <example>
    /// SINGLE LEVEL SET EXAMPLES:
    /// Horizontal crack at y=0.5: (x,y,z) => y - 0.5
    /// Circular crack: (x,y,z) => Math.Sqrt((x-cx)^2 + (y-cy)^2) - radius
    /// Planar 3D crack: (x,y,z) => z - 0.5
    /// 
    /// TWO LEVEL SET EXAMPLES:
    /// Level set 1 defines crack surface, level set 2 defines active region.
    /// Crack forms where surface crosses zero AND region is ≤ 0.
    /// 
    /// 2D horizontal crack from x=0.2 to x=1.5:
    ///   crackSurface = (x,y,z) => y - 0.5
    ///   activeRegion = (x,y,z) => (x < 0.2) ? (x - 0.2) : (x > 1.5) ? (x - 1.5) : -0.1
    /// 
    /// 3D circular crack (plane z=0.5, radius 0.3 at center):
    ///   crackSurface = (x,y,z) => z - 0.5
    ///   activeRegion = (x,y,z) => Math.Sqrt((x-0.5)^2 + (y-0.5)^2) - 0.3
    /// </example>
    public delegate double SignedFieldFunction(double x, double y, double z);
    
    /// <summary>
    /// Create crack in mesh using signed field (level set method).
    /// 
    /// Algorithm:
    /// 1. Find edges where field changes sign
    /// 2. Refine those edges, positioning new nodes at exact zero-crossing
    /// 3. Classify original nodes by field sign (positive/negative)
    /// 4. Duplicate all crack nodes except tips
    /// 5. Elements with all positive original nodes use duplicates
    /// 
    /// Works for all crack types:
    /// - Boundary-to-boundary
    /// - Edge-to-interior (with singular tip)
    /// - Closed loops
    /// - Any shape defined by implicit function
    /// </summary>
    /// <param name="mesh">Input mesh</param>
    /// <param name="coordinates">Node coordinates</param>
    /// <param name="signedField">Signed distance/level set function (defines crack surface)</param>
    /// <param name="regionField">Optional second level set to define crack active region (crack exists where regionField ≤ 0). If null, crack extends along entire zero level set.</param>
    /// <param name="enableSmoothing">Enable CVT smoothing after refinement (disable for multi-crack patterns)</param>
    /// <returns>Cracked mesh and coordinates</returns>
    
    /// <summary>
    /// Helper to safely get z-coordinate from 2D or 3D coordinate array
    /// </summary>
    private static double GetZ(double[,] coords, int nodeId)
    {
        return coords.GetLength(1) == 3 ? coords[nodeId, 2] : 0.0;
    }
    
    public static (SimplexMesh, double[,]) CreateCrackFromSignedField(
        SimplexMesh mesh,
        double[,] coordinates,
        SignedFieldFunction signedField,
        SignedFieldFunction? regionField = null,
        bool enableMeshPerturbation = false,
        bool enableSmoothing = false,
        double visualizationOffset = 0.0)
    {
        int originalNodeCount = mesh.Count<Node>();
        int coordDim = coordinates.GetLength(1);  // 2 for 2D, 3 for 3D
        
        // Clone coordinates to avoid modifying input
        coordinates = (double[,])coordinates.Clone();
        
        // OPTIONAL: MESH PERTURBATION to avoid exact zeros in signed field
        if (enableMeshPerturbation)
        {
            Console.WriteLine($"  → Applying mesh perturbation...");
            
            // Calculate average edge length
            DiscoverEdges(mesh);
            double avgEdgeLength = 0.0;
            int numEdges = 0;
            for (int i = 0; i < mesh.Count<Edge>(); i++)
            {
                var nodes = mesh.NodesOf<Edge, Node>(i);
                int n1 = nodes[0], n2 = nodes[1];
                double dx = coordinates[n2, 0] - coordinates[n1, 0];
                double dy = coordinates[n2, 1] - coordinates[n1, 1];
                double dz = coordDim == 3 ? coordinates[n2, 2] - coordinates[n1, 2] : 0.0;
                avgEdgeLength += Math.Sqrt(dx * dx + dy * dy + dz * dz);
                numEdges++;
            }
            avgEdgeLength /= numEdges;
            
            // Perturb each node by a tiny random amount (1e-6 * avgEdgeLength)
            double perturbationScale = 1e-6 * avgEdgeLength;
            var random = new Random(12345);  // Fixed seed for reproducibility
            
            for (int i = 0; i < mesh.Count<Node>(); i++)
            {
                coordinates[i, 0] += (random.NextDouble() * 2.0 - 1.0) * perturbationScale;
                coordinates[i, 1] += (random.NextDouble() * 2.0 - 1.0) * perturbationScale;
                if (coordDim == 3)
                    coordinates[i, 2] += (random.NextDouble() * 2.0 - 1.0) * perturbationScale;
            }
            
            Console.WriteLine($"  → Mesh perturbed by ±{perturbationScale:E3}");
        }
        else
        {
            DiscoverEdges(mesh);
        }
        
        // Step 1: Find ALL edges that cross the signed field
        var edgesToRefine = new List<(int, int)>();
        
        Console.WriteLine($"  → Total edges in mesh: {mesh.Count<Edge>()}");
        
        int crossingEdges = 0;
        int regionFiltered = 0;
        
        for (int i = 0; i < mesh.Count<Edge>(); i++)
        {
            var nodes = mesh.NodesOf<Edge, Node>(i);
            int n1 = nodes[0], n2 = nodes[1];
            
            double f1 = signedField(coordinates[n1, 0], coordinates[n1, 1], GetZ(coordinates, n1));
            double f2 = signedField(coordinates[n2, 0], coordinates[n2, 1], GetZ(coordinates, n2));
            
            // Check if crack surface crosses this edge (sign change). Sign-based so an endpoint
            // exactly on the surface (f==0, e.g. a crack plane aligned with a node layer) still
            // counts as a crossing; f1*f2<0 missed those and produced "0 crack nodes".
            bool crossesCrack = Math.Sign(f1) != Math.Sign(f2);
            
            if (crossesCrack)
            {
                crossingEdges++;
                
                // If region field is provided, check if edge is in active region
                if (regionField != null)
                {
                    double r1 = regionField(coordinates[n1, 0], coordinates[n1, 1], GetZ(coordinates, n1));
                    double r2 = regionField(coordinates[n2, 0], coordinates[n2, 1], GetZ(coordinates, n2));
                    
                    // Check if crossing point is in active region
                    // Approximate crossing point using linear interpolation
                    double t = Math.Abs(f2 - f1) > 1e-14 ? -f1 / (f2 - f1) : 0.5;
                    t = Math.Max(0.0, Math.Min(1.0, t));
                    
                    double xCross = coordinates[n1, 0] + t * (coordinates[n2, 0] - coordinates[n1, 0]);
                    double yCross = coordinates[n1, 1] + t * (coordinates[n2, 1] - coordinates[n1, 1]);
                    double zCross = GetZ(coordinates, n1) + t * (GetZ(coordinates, n2) - GetZ(coordinates, n1));
                    double rCross = regionField(xCross, yCross, zCross);
                    
                    // Only refine edge if crossing point is in active region (r ≤ 0)
                    if (rCross <= 0)
                    {
                        edgesToRefine.Add((n1, n2));
                    }
                    else
                    {
                        regionFiltered++;
                    }
                }
                else
                {
                    // No region constraint - refine all crossing edges
                    edgesToRefine.Add((n1, n2));
                }
            }
        }
        
        Console.WriteLine($"  → Edges with sign change: {crossingEdges}");
        Console.WriteLine($"  → Filtered by region: {regionFiltered}");
        Console.WriteLine($"  → Edges to refine: {edgesToRefine.Count}");
        
        if (edgesToRefine.Count == 0)
        {
            Console.WriteLine($"  ⚠️  No edges cross the crack surface in active region");
            return (mesh, coordinates);
        }
        
        Console.WriteLine($"  → Refining {edgesToRefine.Count} edges that cross crack");
        
        // Step 2: Refine those edges once
        var refinedMesh = mesh;
        var refinedCoords = coordinates;
        
        {
            // Cache signed field values for all nodes (avoid recomputation)
            var cachedFieldValues = new double[refinedMesh.Count<Node>()];
            var cachedRegionValues = new double[refinedMesh.Count<Node>()];

            for (int i = 0; i < refinedMesh.Count<Node>(); i++)
            {
                cachedFieldValues[i] = signedField(refinedCoords[i, 0], refinedCoords[i, 1], GetZ(refinedCoords, i));
                if (regionField != null)
                    cachedRegionValues[i] = regionField(refinedCoords[i, 0], refinedCoords[i, 1], GetZ(refinedCoords, i));
            }

            // Find edges to refine in current mesh
            var currentEdgesToRefine = new HashSet<(int, int)>();

            for (int i = 0; i < refinedMesh.Count<Tri3>(); i++)
            {
                var n = refinedMesh.NodesOf<Tri3, Node>(i);
                int n1 = n[0], n2 = n[1], n3 = n[2];

                double f1 = cachedFieldValues[n1];
                double f2 = cachedFieldValues[n2];
                double f3 = cachedFieldValues[n3];

                // Check region constraint
                bool checkRegion = (regionField != null);
                bool refineEdge12 = false, refineEdge23 = false, refineEdge31 = false;

                if (Math.Sign(f1) != Math.Sign(f2))
                {
                    if (checkRegion)
                    {
                        double r1 = cachedRegionValues[n1];
                        double r2 = cachedRegionValues[n2];
                        refineEdge12 = (r1 <= 0 || r2 <= 0);
                    }
                    else refineEdge12 = true;
                }

                if (f2 * f3 <= 0)
                {
                    if (checkRegion)
                    {
                        double r2 = cachedRegionValues[n2];
                        double r3 = cachedRegionValues[n3];
                        refineEdge23 = (r2 <= 0 || r3 <= 0);
                    }
                    else refineEdge23 = true;
                }

                if (f3 * f1 <= 0)
                {
                    if (checkRegion)
                    {
                        double r3 = cachedRegionValues[n3];
                        double r1 = cachedRegionValues[n1];
                        refineEdge31 = (r3 <= 0 || r1 <= 0);
                    }
                    else refineEdge31 = true;
                }

                if (refineEdge12) currentEdgesToRefine.Add(n1 < n2 ? (n1, n2) : (n2, n1));
                if (refineEdge23) currentEdgesToRefine.Add(n2 < n3 ? (n2, n3) : (n3, n2));
                if (refineEdge31) currentEdgesToRefine.Add(n1 < n3 ? (n1, n3) : (n3, n1));
            }

            if (currentEdgesToRefine.Count > 0)
            {
                Console.WriteLine($"  → Refining {currentEdgesToRefine.Count} edges");
                (refinedMesh, _) = MeshRefinement.Refine(refinedMesh, currentEdgesToRefine.ToList());
                refinedCoords = MeshRefinement.InterpolateCoordinates(refinedMesh, refinedCoords);
            }
        }
        
        // Step 3: Snap new crack nodes to EXACT zero-crossing (surface = 0)
        int snappedCount = 0;
        double maxSnapError = 0.0;
        int skippedTooClose = 0;
        int skippedOutsideRegion = 0;

        for (int i = originalNodeCount; i < refinedMesh.Count<Node>(); i++)
        {
            var parents = refinedMesh.Get<Node, ParentNodes>(i);
            
            if (parents.Parent1 != parents.Parent2)
            {
                int p1 = parents.Parent1, p2 = parents.Parent2;
                
                double x1 = refinedCoords[p1, 0], y1 = refinedCoords[p1, 1], z1 = GetZ(refinedCoords, p1);
                double x2 = refinedCoords[p2, 0], y2 = refinedCoords[p2, 1], z2 = GetZ(refinedCoords, p2);
                
                double f1 = signedField(x1, y1, z1);
                double f2 = signedField(x2, y2, z2);
                
                                // Snap to zero-crossing if edge crosses crack

                // Robust edge–surface intersection (curved implicit surfaces may intersect with same-sign endpoints)
                if (TryFindEdgeRootOnSegment(signedField,
                        x1, y1, z1,
                        x2, y2, z2,
                        out double tRoot,
                        out double xRoot, out double yRoot, out double zRoot,
                        out double phiRoot))
                {
                    // Current interpolated position
                    double xCurr = refinedCoords[i, 0];
                    double yCurr = refinedCoords[i, 1];
                    double zCurr = refinedCoords[i, 2];
                    double fCurr = signedField(xCurr, yCurr, zCurr);

                    // Don't snap if already very close to surface
                    double edgeLength = Math.Sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1) + (z2-z1)*(z2-z1));
                    double snapTolerance = Math.Max(CrackSnapAbsoluteTolerance, CrackSnapRelativeTolerance * edgeLength);

                    if (Math.Abs(fCurr) < snapTolerance)
                    {
                        skippedTooClose++;
                        continue;
                    }

                    // CRITICAL: Only snap if the new position is INSIDE the crack region
                    if (regionField != null)
                    {
                        double regionValue = regionField(xRoot, yRoot, zRoot);
                        if (regionValue > 0)
                        {
                            skippedOutsideRegion++;
                            continue;
                        }
                    }

                    double snapDist = Math.Sqrt((xRoot-xCurr)*(xRoot-xCurr) + (yRoot-yCurr)*(yRoot-yCurr) + (zRoot-zCurr)*(zRoot-zCurr));

                    if (snapDist > snapTolerance)
                    {
                        // Inversion is corrected post-snapping by FixNegativeJacobians,
                        // so no per-snap inversion check is performed here.
                        refinedCoords[i, 0] = xRoot;
                        refinedCoords[i, 1] = yRoot;
                        refinedCoords[i, 2] = zRoot;

                        double finalError = Math.Abs(signedField(refinedCoords[i, 0], refinedCoords[i, 1], refinedCoords[i, 2]));
                        maxSnapError = Math.Max(maxSnapError, finalError);
                        snappedCount++;
                    }
                    else
                    {
                        skippedTooClose++;
                    }
                }

            }
        }
        
        Console.WriteLine($"  → Snapped {snappedCount} nodes to surface=0 (max error: {maxSnapError:E3})");
        
        // Step 4: RECALCULATE nodal values of surface and region on refined mesh
        Console.WriteLine($"  → Recalculating surface and region values on ALL refined nodes...");
        
        var surfaceValues = new double[refinedMesh.Count<Node>()];
        var regionValues = new double[refinedMesh.Count<Node>()];
        
        for (int i = 0; i < refinedMesh.Count<Node>(); i++)
        {
            surfaceValues[i] = signedField(refinedCoords[i, 0], refinedCoords[i, 1], GetZ(refinedCoords, i));
            
            if (regionField != null)
            {
                regionValues[i] = regionField(refinedCoords[i, 0], refinedCoords[i, 1], GetZ(refinedCoords, i));
            }
            else
            {
                regionValues[i] = -1.0; // All nodes in active region if no region field
            }
        }
        
        // Discover edges before computing average length
        DiscoverEdges(refinedMesh);
        
        // Compute average edge length for tolerance
        double avgEdgeLen = 0;
        int numEdges2 = 0;
        for (int i = 0; i < refinedMesh.Count<Edge>(); i++)
        {
            var n = refinedMesh.NodesOf<Edge, Node>(i);
            double dx = refinedCoords[n[1],0] - refinedCoords[n[0],0];
            double dy = refinedCoords[n[1],1] - refinedCoords[n[0],1];
            double dz = coordDim == 3 ? refinedCoords[n[1],2] - refinedCoords[n[0],2] : 0;
            avgEdgeLen += Math.Sqrt(dx*dx + dy*dy + dz*dz);
            numEdges2++;
        }
        avgEdgeLen /= numEdges2;
        
        // Step 5: Identify crack nodes (nodes where |surface| ≈ 0 AND region < -tol)
        const double zeroTolerance = CrackSurfaceZeroTolerance;
        double regionTolerance = CrackRegionRelativeTolerance * avgEdgeLen;
        var crackNodes = new HashSet<int>();
        int rejectedByRegion = 0;
        
        for (int i = 0; i < refinedMesh.Count<Node>(); i++)
        {
            if (Math.Abs(surfaceValues[i]) < zeroTolerance)
            {
                if (regionValues[i] < -regionTolerance)
                {
                    crackNodes.Add(i);
                }
                else
                {
                    rejectedByRegion++;
                }
            }
        }
        
        if (rejectedByRegion > 0)
        {
            Console.WriteLine($"  → Rejected {rejectedByRegion} nodes at crack tip (r ≥ {-regionTolerance:E2})");
        }
        
        Console.WriteLine($"  → Found {crackNodes.Count} crack nodes (|surface| < {zeroTolerance:E1}, region < {-regionTolerance:E2})");
        
        if (crackNodes.Count == 0)
        {
            Console.WriteLine($"  ⚠️  No crack nodes found!");
            return (mesh, coordinates);
        }
        
        // Step 6: Identify ORIGINAL mesh boundary (before refinement)
        Console.WriteLine($"  → Identifying original mesh boundary...");
        var originalBoundaryNodes = FindBoundaryNodes(mesh);
        Console.WriteLine($"  → Found {originalBoundaryNodes.Count} boundary nodes in original mesh");
        
        // Map refined nodes back to original boundary
        // A refined node is on original boundary if its parents are both on original boundary
        var refinedBoundaryNodes = new HashSet<int>();
        for (int i = 0; i < refinedMesh.Count<Node>(); i++)
        {
            var parents = refinedMesh.Get<Node, ParentNodes>(i);
            if (parents.Parent1 == parents.Parent2)
            {
                // Original node (not created by refinement)
                if (originalBoundaryNodes.Contains(parents.Parent1))
                    refinedBoundaryNodes.Add(i);
            }
            else
            {
                // Refined node (created on edge between Parent1 and Parent2)
                if (originalBoundaryNodes.Contains(parents.Parent1) && 
                    originalBoundaryNodes.Contains(parents.Parent2))
                    refinedBoundaryNodes.Add(i);
            }
        }
        
        Console.WriteLine($"  → Mapped to {refinedBoundaryNodes.Count} boundary nodes in refined mesh");
        
        // Step 7: Identify tip nodes (crack nodes at crack boundary/termination)
        // A tip node is a crack node that has neighbors OUTSIDE the crack region
        var tipNodes = new HashSet<int>();
        
        if (regionField != null)
        {
            // Build node-to-node connectivity
            var nodeNeighbors = BuildNodeNeighbors(refinedMesh, refinedMesh.Count<Node>(), tetrahedra: false);
            
            // Check each crack node for neighbors outside active region
            // Interior tips (crack terminates inside mesh): DON'T duplicate
            // Boundary tips (crack reaches mesh edge): DO duplicate
            foreach (int crackNode in crackNodes)
            {
                // Check if any neighbor is outside the crack region (r > 0)
                bool hasFarNeighbor = false;
                foreach (int neighbor in nodeNeighbors[crackNode])
                {
                    if (regionValues[neighbor] > 0)
                    {
                        hasFarNeighbor = true;
                        break;
                    }
                }
                
                // If this is a tip AND not on mesh boundary, don't duplicate it
                if (hasFarNeighbor && !refinedBoundaryNodes.Contains(crackNode))
                {
                    tipNodes.Add(crackNode);
                }
            }
        }
        
        Console.WriteLine($"  → Found {tipNodes.Count} tip nodes (will NOT be duplicated)");
        
        // Step 8: Nodes to duplicate = crack nodes - tip nodes
        var nodesToDuplicate = new HashSet<int>(crackNodes);
        nodesToDuplicate.ExceptWith(tipNodes);
        
        Console.WriteLine($"  → Will duplicate {nodesToDuplicate.Count} nodes");
        
        if (nodesToDuplicate.Count == 0)
        {
            Console.WriteLine($"  → No nodes to duplicate - returning refined mesh");
            return (refinedMesh, refinedCoords);
        }
        
        // Step 9: Duplicate nodes CAREFULLY
        return DuplicateNodesCarefully(
            refinedMesh,
            refinedCoords,
            nodesToDuplicate,
            surfaceValues,
            visualizationOffset,
            enableSmoothing);
    }
    
    /// <summary>
    /// Duplicate crack nodes to create discontinuity.
    /// Element-based approach: for each element, determine which side based on non-crack nodes.
    /// </summary>
    private static (SimplexMesh, double[,]) DuplicateNodesCarefully(
        SimplexMesh mesh,
        double[,] coords,
        HashSet<int> nodesToDuplicate,
        double[] surfaceValues,
        double visualizationOffset = 0.0,
        bool enableSmoothing = false)
    {
        Console.WriteLine($"  → Starting element-based crack duplication...");
        
        int totalNodes = mesh.Count<Node>();
        int coordDim = coords.GetLength(1);
        
        // CREATE ALL NODES (originals + duplicates)
        var crackedMesh = new SimplexMesh();
        int finalNodeCount = totalNodes + nodesToDuplicate.Count;
        var crackedCoords = new double[finalNodeCount, coordDim];
        
        var originalMap = new Dictionary<int, int>();
        var duplicateMap = new Dictionary<int, int>();
        
        // Copy all original nodes
        for (int i = 0; i < totalNodes; i++)
        {
            int newId = crackedMesh.Add<Node>();
            originalMap[i] = newId;
            
            for (int d = 0; d < coordDim; d++)
                crackedCoords[newId, d] = coords[i, d];
            
            var parents = mesh.Get<Node, ParentNodes>(i);
            crackedMesh.Set<Node, ParentNodes>(newId, parents);
        }
        
        // Create duplicates
        foreach (int nodeId in nodesToDuplicate)
        {
            int dupId = crackedMesh.Add<Node>();
            duplicateMap[nodeId] = dupId;
            
            for (int d = 0; d < coordDim; d++)
                crackedCoords[dupId, d] = coords[nodeId, d];
            
            var parents = mesh.Get<Node, ParentNodes>(nodeId);
            crackedMesh.Set<Node, ParentNodes>(dupId, parents);
        }
        
        Console.WriteLine($"  → Created {totalNodes} original + {nodesToDuplicate.Count} duplicate nodes");
        
        // RECREATE ELEMENTS - determine side based on non-crack nodes
        int elementsCreated = 0;
        int positiveSideElements = 0;
        int negativeSideElements = 0;
        int duplicatesUsed = 0;
        
        for (int i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            var newNodes = new int[3];
            
            // VOTING-BASED ELEMENT ASSIGNMENT (matches the 3D path). A triangle straddling the crack
            // can have non-crack nodes on opposite sides, so classify by majority vote rather than by
            // the first non-crack node (which mis-assigned such elements and left the crack
            // non-conforming / could weld a face).
            int positiveVotes = 0, negativeVotes = 0;
            for (int j = 0; j < 3; j++)
            {
                if (!nodesToDuplicate.Contains(nodes[j]))
                {
                    if (surfaceValues[nodes[j]] > 0) positiveVotes++;
                    else negativeVotes++;
                }
            }

            bool usePositiveSide;
            if (positiveVotes != negativeVotes)
            {
                usePositiveSide = positiveVotes > negativeVotes;
            }
            else
            {
                // Tie (or all-crack-node) element: lean to the side of the summed signed field
                // (crack nodes contribute 0).
                double sum = 0.0;
                for (int j = 0; j < 3; j++) sum += surfaceValues[nodes[j]];
                usePositiveSide = sum > 0;
            }
            
            if (usePositiveSide)
                positiveSideElements++;
            else
                negativeSideElements++;
            
            // Assign nodes
            for (int j = 0; j < 3; j++)
            {
                if (!nodesToDuplicate.Contains(nodes[j]))
                {
                    // Non-crack node
                    newNodes[j] = originalMap[nodes[j]];
                }
                else
                {
                    // Crack node - use duplicate for positive, original for negative
                    if (usePositiveSide)
                    {
                        newNodes[j] = duplicateMap[nodes[j]];
                        duplicatesUsed++;
                    }
                    else
                    {
                        newNodes[j] = originalMap[nodes[j]];
                    }
                }
            }
            
            crackedMesh.Add<Tri3, Node>(newNodes[0], newNodes[1], newNodes[2]);
            elementsCreated++;
        }
        
        Console.WriteLine($"  → Created {elementsCreated} elements");
        Console.WriteLine($"  → Positive side: {positiveSideElements} elements, Negative side: {negativeSideElements} elements");
        Console.WriteLine($"  → Duplicate nodes used {duplicatesUsed} times in elements");
        Console.WriteLine($"  → Final mesh: {crackedMesh.Count<Node>()} nodes, {crackedMesh.Count<Tri3>()} triangles");
        
        // OPTIONAL: VISUALIZATION OFFSET (separate crack surfaces)
        if (visualizationOffset > 0)
        {
            Console.WriteLine($"  → Applying visualization offset: {visualizationOffset}mm");
            
            // Simple approach: offset along surface normal approximation
            foreach (var crackNode in nodesToDuplicate)
            {
                int origId = originalMap[crackNode];
                int dupId = duplicateMap[crackNode];
                
                // Approximate normal from surface gradient (simplified)
                double nx = 0, ny = 0;
                
                // Use surface values to estimate gradient direction
                double surfVal = surfaceValues[crackNode];
                if (Math.Abs(surfVal) < 1e-6)
                {
                    // On crack - use simple approximation
                    nx = 0;
                    ny = 1.0;  // Default to y-direction
                }
                
                // Normalize
                double len = Math.Sqrt(nx * nx + ny * ny + 1e-10);
                nx /= len;
                ny /= len;
                
                // Offset nodes in opposite directions
                crackedCoords[origId, 0] -= (visualizationOffset / 2.0) * nx;
                crackedCoords[origId, 1] -= (visualizationOffset / 2.0) * ny;
                
                crackedCoords[dupId, 0] += (visualizationOffset / 2.0) * nx;
                crackedCoords[dupId, 1] += (visualizationOffset / 2.0) * ny;
            }
        }
        
        // OPTIONAL: SMOOTHING (with crack nodes fixed as boundaries)
        if (enableSmoothing)
        {
            Console.WriteLine($"  → Smoothing mesh (all boundaries fixed)...");
            
            var boundaryNodes = new HashSet<int>();
            
            // Fix ALL boundary nodes in the cracked mesh (includes crack surfaces).
            // The edges are discovered here, before the orientation correction below, so
            // that the returned mesh carries them in the order a further crack step reads.
            DiscoverEdges(crackedMesh);
            var crackedBoundary = FindBoundaryNodes(crackedMesh);
            foreach (var node in crackedBoundary)
                boundaryNodes.Add(node);
            
            Console.WriteLine($"  → Fixed {boundaryNodes.Count} boundary nodes (mesh edges + crack surfaces)");
            
            // Fast conservative Laplacian smoothing
            var smoothedCoords = (double[,])crackedCoords.Clone();
            int iterations = DefaultCrackSmoothingIterations;
            double relaxation = DefaultCrackSmoothingRelaxation;
            
            // Build neighbor map once (FAST)
            var nodeNeighbors = BuildNodeNeighbors(crackedMesh, crackedMesh.Count<Node>(), tetrahedra: false);
            
            for (int iter = 0; iter < iterations; iter++)
            {
                var newCoords = (double[,])smoothedCoords.Clone();
                int rejected = 0;
                
                for (int nodeId = 0; nodeId < crackedMesh.Count<Node>(); nodeId++)
                {
                    if (boundaryNodes.Contains(nodeId)) continue;
                    
                    var neighbors = nodeNeighbors[nodeId];
                    if (neighbors.Count == 0) continue;
                    
                    // Compute centroid
                    double[] centroid = new double[coordDim];
                    foreach (var nbr in neighbors)
                        for (int d = 0; d < coordDim; d++)
                            centroid[d] += smoothedCoords[nbr, d];
                    
                    for (int d = 0; d < coordDim; d++)
                        centroid[d] /= neighbors.Count;
                    
                    // Conservative move
                    double[] newPos = new double[coordDim];
                    for (int d = 0; d < coordDim; d++)
                        newPos[d] = smoothedCoords[nodeId, d] + relaxation * (centroid[d] - smoothedCoords[nodeId, d]);
                    
                    // Quality check: reject if move inverts any adjacent triangle
                    bool valid = true;
                    var incidentTris = crackedMesh.ElementsAt<Tri3, Node>(nodeId);
                    foreach (var elemId in incidentTris)
                    {
                        var n = crackedMesh.NodesOf<Tri3, Node>(elemId);

                        // Compute area with newPos substituted for nodeId (avoids full array clone)
                        double x0 = n[0] == nodeId ? newPos[0] : smoothedCoords[n[0], 0];
                        double y0 = n[0] == nodeId ? newPos[1] : smoothedCoords[n[0], 1];
                        double x1 = n[1] == nodeId ? newPos[0] : smoothedCoords[n[1], 0];
                        double y1 = n[1] == nodeId ? newPos[1] : smoothedCoords[n[1], 1];
                        double x2 = n[2] == nodeId ? newPos[0] : smoothedCoords[n[2], 0];
                        double y2 = n[2] == nodeId ? newPos[1] : smoothedCoords[n[2], 1];

                        double area2 = (x1 - x0) * (y2 - y0) - (y1 - y0) * (x2 - x0);

                        if (area2 <= 0)
                        {
                            valid = false;
                            rejected++;
                            break;
                        }
                    }
                    
                    if (valid)
                    {
                        for (int d = 0; d < coordDim; d++)
                            newCoords[nodeId, d] = newPos[d];
                    }
                }
                
                smoothedCoords = newCoords;
            }
            
            CorrectTriangleOrientations(crackedMesh, smoothedCoords);
            return (crackedMesh, smoothedCoords);
        }
        
        CorrectTriangleOrientations(crackedMesh, crackedCoords);
        return (crackedMesh, crackedCoords);
    }
    
    /// <summary>
    /// Find boundary nodes of the triangles: the nodes of edges used by exactly one triangle.
    /// </summary>
    public static HashSet<int> FindBoundaryNodes(SimplexMesh mesh)
        => mesh.FindBoundaryNodes<Tri3, Node>(2);
    
    #region Crack Insertion - 3D (Tetrahedral Meshes)
    
    /// <summary>
/// Robustly finds an intersection (root) of an implicit signed field on a line segment.
/// This is needed for curved fields (e.g. cylinders) where the segment may intersect even if
/// both endpoints have the same sign (two roots are possible in general).
/// </summary>
private static bool TryFindEdgeRootOnSegment(
    SignedFieldFunction phi,
    double x1, double y1, double z1,
    double x2, double y2, double z2,
    out double tRoot,
    out double xRoot, out double yRoot, out double zRoot,
    out double phiAtRoot)
{
    // Conservative sampling to detect sign changes / near-zero points.
    // Keep this small for performance; 9 points catches most curved intersections.
    const int S = 9; // includes endpoints
    const double nearZero = 1e-12;

    double bestAbs = double.PositiveInfinity;
    double bestT = 0.5;
    double bestPhi = double.PositiveInfinity;

    double prevT = 0.0;
    double prevPhi = phi(x1, y1, z1);

    bestAbs = Math.Abs(prevPhi);
    bestT = 0.0;
    bestPhi = prevPhi;

    // Track best bracketing interval (closest to mid-segment)
    bool haveBracket = false;
    double aT = 0.0, bT = 1.0;
    double aPhi = prevPhi, bPhi = double.NaN;
    double bestBracketScore = double.PositiveInfinity;

    for (int k = 1; k < S; k++)
    {
        double t = (double)k / (S - 1);
        double x = x1 + t * (x2 - x1);
        double y = y1 + t * (y2 - y1);
        double z = z1 + t * (z2 - z1);
        double v = phi(x, y, z);

        double av = Math.Abs(v);
        if (av < bestAbs)
        {
            bestAbs = av;
            bestT = t;
            bestPhi = v;
        }

        // Bracket if sign changes or either endpoint is near zero
        if ((prevPhi == 0.0) || (v == 0.0) || (prevPhi * v < 0.0) || (Math.Abs(prevPhi) < nearZero) || (Math.Abs(v) < nearZero))
        {
            double mid = 0.5 * (prevT + t);
            double score = Math.Abs(mid - 0.5); // prefer closest to midpoint (stable, symmetric)
            if (score < bestBracketScore)
            {
                bestBracketScore = score;
                haveBracket = true;
                aT = prevT; bT = t;
                aPhi = prevPhi; bPhi = v;
            }
        }

        prevT = t;
        prevPhi = v;
    }

    // If we didn't find a bracket but we got extremely close somewhere, treat it as an intersection.
    if (!haveBracket)
    {
        if (bestAbs > 1e-9) // not close enough -> no reliable intersection
        {
            tRoot = 0; xRoot = yRoot = zRoot = 0; phiAtRoot = 0;
            return false;
        }

        tRoot = bestT;
        xRoot = x1 + tRoot * (x2 - x1);
        yRoot = y1 + tRoot * (y2 - y1);
        zRoot = z1 + tRoot * (z2 - z1);
        phiAtRoot = bestPhi;
        return true;
    }

    // Bisection on the selected bracket (works even if phi is nonlinear, as long as continuous)
    double loT = aT, hiT = bT;
    double loPhi = aPhi, hiPhi = bPhi;

    // If the bracket is degenerate (exact zero at one endpoint), return that
    if (Math.Abs(loPhi) < nearZero)
    {
        tRoot = loT;
        xRoot = x1 + tRoot * (x2 - x1);
        yRoot = y1 + tRoot * (y2 - y1);
        zRoot = z1 + tRoot * (z2 - z1);
        phiAtRoot = loPhi;
        return true;
    }
    if (Math.Abs(hiPhi) < nearZero)
    {
        tRoot = hiT;
        xRoot = x1 + tRoot * (x2 - x1);
        yRoot = y1 + tRoot * (y2 - y1);
        zRoot = z1 + tRoot * (z2 - z1);
        phiAtRoot = hiPhi;
        return true;
    }

    // Ensure opposite signs; if not, still bisect toward minimum |phi|
    bool opposite = loPhi * hiPhi < 0.0;

    double tMid = 0.5 * (loT + hiT);
    double phiMid = 0.0;

    for (int iter = 0; iter < RootFindingMaxIterations; iter++)
    {
        tMid = 0.5 * (loT + hiT);
        double xm = x1 + tMid * (x2 - x1);
        double ym = y1 + tMid * (y2 - y1);
        double zm = z1 + tMid * (z2 - z1);
        phiMid = phi(xm, ym, zm);

        if (Math.Abs(phiMid) < 1e-12) break;

        if (opposite)
        {
            // standard sign bisection
            if (loPhi * phiMid < 0.0)
            {
                hiT = tMid; hiPhi = phiMid;
            }
            else
            {
                loT = tMid; loPhi = phiMid;
            }
        }
        else
        {
            // fallback: shrink interval toward smaller |phi|
            if (Math.Abs(loPhi) < Math.Abs(hiPhi))
            {
                hiT = tMid; hiPhi = phiMid;
            }
            else
            {
                loT = tMid; loPhi = phiMid;
            }
        }
    }

    tRoot = tMid;
    xRoot = x1 + tRoot * (x2 - x1);
    yRoot = y1 + tRoot * (y2 - y1);
    zRoot = z1 + tRoot * (z2 - z1);
    phiAtRoot = phiMid;
    return true;
}

public static (SimplexMesh, double[,]) CreateCrackFromSignedField3D(
        SimplexMesh mesh,
        double[,] coordinates,
        SignedFieldFunction signedField,
        SignedFieldFunction? regionField = null,
        bool enableMeshPerturbation = false,
        bool enableSmoothing = false)
    {
        Console.WriteLine($"  → Creating 3D crack with mesh refinement and node duplication...");
        Console.WriteLine($"  → Initial mesh: {mesh.Count<Node>()} nodes, {mesh.Count<Tet4>()} tetrahedra");
        
        // Find edges that cross the crack surface
        DiscoverEdges(mesh);
        var edgesToRefine = new List<(int, int)>();
        
        int totalCrossingEdges = 0;
        int regionFilteredEdges = 0;
        
        for (int i = 0; i < mesh.Count<Edge>(); i++)
        {
            var nodes = mesh.NodesOf<Edge, Node>(i);
            int n1 = nodes[0], n2 = nodes[1];
            
            // Robust edge–surface intersection (curved implicit surfaces may intersect with same-sign endpoints)
if (TryFindEdgeRootOnSegment(signedField,
        coordinates[n1, 0], coordinates[n1, 1], coordinates[n1, 2],
        coordinates[n2, 0], coordinates[n2, 1], coordinates[n2, 2],
        out double tRoot,
        out double xRoot, out double yRoot, out double zRoot,
        out double phiRoot))
{
    totalCrossingEdges++;

    if (regionField != null)
    {
        // Filter based on the intersection point (NOT only endpoints)
        double r = regionField(xRoot, yRoot, zRoot);
        if (r <= 0)
            edgesToRefine.Add((n1, n2));
        else
            regionFilteredEdges++;
    }
    else
    {
        edgesToRefine.Add((n1, n2));
    }
}
        }
        
        Console.WriteLine($"  → Edges crossing crack surface: {totalCrossingEdges}");
        if (regionField != null)
            Console.WriteLine($"  → Filtered by region: {regionFilteredEdges}");
        Console.WriteLine($"  → Edges to refine: {edgesToRefine.Count}");
        
        if (edgesToRefine.Count == 0)
        {
            Console.WriteLine($"  ⚠️  No edges to refine - returning original mesh");
            return (mesh, coordinates);
        }
        
        // CHECK INITIAL MESH JACOBIANS (before refinement)
        Console.WriteLine($"  → Checking initial mesh quality...");
        int initialNegative = 0;
        for (int i = 0; i < mesh.Count<Tet4>(); i++)
        {
            var nodes = mesh.NodesOf<Tet4, Node>(i);
            double jac = ComputeTetrahedronJacobian(coordinates, nodes[0], nodes[1], nodes[2], nodes[3]);
            if (jac <= 0) initialNegative++;
        }
        if (initialNegative > 0)
            Console.WriteLine($"  ⚠️  Initial mesh has {initialNegative}/{mesh.Count<Tet4>()} elements with non-positive Jacobian!");
        else
            Console.WriteLine($"  ✓ Initial mesh: all elements have positive Jacobians");
        
        // Store original node count before refinement
        int originalNodeCount = mesh.Count<Node>();
        
        // Use MeshRefinement.Refine to split edges AND subdivide tetrahedra
        Console.WriteLine($"  → Calling MeshRefinement.Refine with closure enforcement...");
        var (refinedMesh, _) = MeshRefinement.Refine(mesh, edgesToRefine, 
            enforceClosureForTets: false,
            validateTopology: true,
            inputCoordinates: coordinates);
        
        Console.WriteLine($"  → Refined mesh: {refinedMesh.Count<Node>()} nodes, {refinedMesh.Count<Tet4>()} tetrahedra");
        
        // Use MeshRefinement's own coordinate interpolation
        Console.WriteLine($"  → Using MeshRefinement.InterpolateCoordinates...");
        var refinedCoords = MeshRefinement.InterpolateCoordinates(refinedMesh, coordinates);
        
        // Snap new nodes to exact crack surface (surface = 0) ONLY IF INSIDE REGION
        Console.WriteLine($"  → Snapping crack nodes to exact zero crossing...");
        int snappedCount = 0;
        int skippedTooClose = 0;
        int skippedOutsideRegion = 0;
        double maxSnapError = 0.0;

        for (int i = originalNodeCount; i < refinedMesh.Count<Node>(); i++)
        {
            var parents = refinedMesh.Get<Node, ParentNodes>(i);

            if (parents.Parent1 != parents.Parent2)
            {
                int p1 = parents.Parent1, p2 = parents.Parent2;

                double x1 = refinedCoords[p1, 0], y1 = refinedCoords[p1, 1], z1 = refinedCoords[p1, 2];
                double x2 = refinedCoords[p2, 0], y2 = refinedCoords[p2, 1], z2 = refinedCoords[p2, 2];
                
                double f1 = signedField(x1, y1, z1);
                double f2 = signedField(x2, y2, z2);
                
                // Snap to zero-crossing if edge crosses crack
                if (Math.Abs(f2 - f1) > 1e-10 && Math.Sign(f1) != Math.Sign(f2))
                {
                    // Current interpolated position
                    double xCurr = refinedCoords[i, 0];
                    double yCurr = refinedCoords[i, 1];
                    double zCurr = refinedCoords[i, 2];
                    double fCurr = signedField(xCurr, yCurr, zCurr);
                    
                    // Don't snap if already very close to surface
                    double edgeLength = Math.Sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1) + (z2-z1)*(z2-z1));
                    double snapTolerance = Math.Max(CrackSnapAbsoluteTolerance, CrackSnapRelativeTolerance * edgeLength);
                    
                    if (Math.Abs(fCurr) < snapTolerance)
                    {
                        skippedTooClose++;
                        continue;
                    }
                    
                    // Use bisection for nonlinear fields
                    double tMin = 0.0, tMax = 1.0;
                    double t = 0.5;
                    
                    for (int iter = 0; iter < BisectionMaxIterations; iter++)  // bisection on edge for curved surfaces
                    {
                        t = (tMin + tMax) / 2.0;
                        double xm = x1 + t * (x2 - x1);
                        double ym = y1 + t * (y2 - y1);
                        double zm = z1 + t * (z2 - z1);
                        double fm = signedField(xm, ym, zm);
                        
                        if (Math.Abs(fm) < 1e-12) break;  // Tighter convergence
                        
                        if (fm * f1 < 0)
                        {
                            tMax = t;
                            f2 = fm;
                        }
                        else
                        {
                            tMin = t;
                            f1 = fm;
                        }
                    }
                    
                    // Check if snap distance is significant
                    double xNew = x1 + t * (x2 - x1);
                    double yNew = y1 + t * (y2 - y1);
                    double zNew = z1 + t * (z2 - z1);
                    
                    // CRITICAL FIX: Only snap if the new position is INSIDE the crack region
                    if (regionField != null)
                    {
                        double regionValue = regionField(xNew, yNew, zNew);
                        if (regionValue > 0)
                        {
                            // Outside the crack region (e.g., outside the ellipse)
                            // Do NOT snap - leave the node at its interpolated position
                            skippedOutsideRegion++;
                            continue;
                        }
                    }
                    
                    double snapDist = Math.Sqrt((xNew-xCurr)*(xNew-xCurr) + (yNew-yCurr)*(yNew-yCurr) + (zNew-zCurr)*(zNew-zCurr));
                    
                    if (snapDist > snapTolerance)
                    {
                        // Snap node to surface. Inversion is corrected post-snapping by
                        // FixNegativeJacobians below, so no per-snap inversion check is performed.
                        refinedCoords[i, 0] = xNew;
                        refinedCoords[i, 1] = yNew;
                        refinedCoords[i, 2] = zNew;

                        double finalError = Math.Abs(signedField(refinedCoords[i, 0], refinedCoords[i, 1], refinedCoords[i, 2]));
                        maxSnapError = Math.Max(maxSnapError, finalError);
                        snappedCount++;
                    }
                    else
                    {
                        skippedTooClose++;
                    }
                }
            }
        }
        
        Console.WriteLine($"  → Snapped {snappedCount} nodes to surface=0 (max error: {maxSnapError:E3})");
        if (skippedTooClose > 0)
            Console.WriteLine($"  → Skipped {skippedTooClose} nodes already close enough to surface");
        if (skippedOutsideRegion > 0)
            Console.WriteLine($"  → Skipped {skippedOutsideRegion} nodes outside crack region (tip area)");

        MeshRefinement.CheckJacobians(refinedMesh, refinedCoords, "After snapping");
        MeshRefinement.FixNegativeJacobians(refinedMesh, refinedCoords);
        MeshRefinement.CheckJacobians(refinedMesh, refinedCoords, "Final mesh");

        // ============================================================
        // NODE DUPLICATION - Element-based approach (matching 2D)
        // ============================================================
        Console.WriteLine($"  → Starting element-based crack node duplication...");
        
        // Step 1: Pre-compute signed field values for ALL nodes
        var surfaceValues = new double[refinedMesh.Count<Node>()];
        var regionValues = new double[refinedMesh.Count<Node>()];
        
        for (int i = 0; i < refinedMesh.Count<Node>(); i++)
        {
            surfaceValues[i] = signedField(refinedCoords[i, 0], refinedCoords[i, 1], refinedCoords[i, 2]);
            regionValues[i] = regionField != null 
                ? regionField(refinedCoords[i, 0], refinedCoords[i, 1], refinedCoords[i, 2]) 
                : -1.0; // Default: all nodes in active region
        }
        
        // Compute average edge length for adaptive tolerances
        double avgEdgeLen = 0;
        int numEdgesCount = 0;
        for (int t = 0; t < refinedMesh.Count<Tet4>(); t++)
        {
            var n = refinedMesh.NodesOf<Tet4, Node>(t);
            for (int i = 0; i < 4; i++)
            {
                for (int j = i + 1; j < 4; j++)
                {
                    double dx = refinedCoords[n[j], 0] - refinedCoords[n[i], 0];
                    double dy = refinedCoords[n[j], 1] - refinedCoords[n[i], 1];
                    double dz = refinedCoords[n[j], 2] - refinedCoords[n[i], 2];
                    avgEdgeLen += Math.Sqrt(dx*dx + dy*dy + dz*dz);
                    numEdgesCount++;
                }
            }
        }
        avgEdgeLen /= Math.Max(1, numEdgesCount);
        Console.WriteLine($"  → Average edge length: {avgEdgeLen:F4}");
        
        // Step 2: Identify crack nodes by SIGN CHANGE (not tolerance)
        // A node is a crack node if it was created by edge refinement (Parent1 != Parent2)
        // AND both parents have opposite signs
        
        var crackNodes = new HashSet<int>();
        
        for (int i = originalNodeCount; i < refinedMesh.Count<Node>(); i++)
        {
            var parents = refinedMesh.Get<Node, ParentNodes>(i);
            
            if (parents.Parent1 != parents.Parent2)
            {
                int p1 = parents.Parent1, p2 = parents.Parent2;
                
                double f1 = signedField(coordinates[p1, 0], coordinates[p1, 1], coordinates[p1, 2]);
                double f2 = signedField(coordinates[p2, 0], coordinates[p2, 1], coordinates[p2, 2]);
                
                // Sign change = edge crosses surface (sign-based: also catches an endpoint on the surface)
                if (Math.Sign(f1) != Math.Sign(f2))
                {
                    // Check if inside region
                    if (regionField == null || regionField(refinedCoords[i, 0], refinedCoords[i, 1], refinedCoords[i, 2]) <= 0)
                    {
                        crackNodes.Add(i);
                    }
                }
            }
        }
        
        Console.WriteLine($"  → Found {crackNodes.Count} crack nodes (by sign change)");
        
        if (crackNodes.Count == 0)
        {
            Console.WriteLine($"  ⚠️  No crack nodes found - returning refined mesh");
            return (refinedMesh, refinedCoords);
        }
        
        // Step 3: Identify boundary nodes (to exclude from tip detection)
        var boundaryNodes3D = FindBoundaryNodes3D(refinedMesh);
        Console.WriteLine($"  → Found {boundaryNodes3D.Count} boundary nodes");
        
        // Step 4: Identify tip nodes (crack nodes with neighbors outside crack region)
        var tipNodes = new HashSet<int>();
        
        if (regionField != null)
        {
            // Build node-to-node connectivity from tets
            var nodeNeighbors = BuildNodeNeighbors(refinedMesh, refinedMesh.Count<Node>(), triangles: false);
            
            // Threshold for "near region boundary" - should be wider than regionTolerance
            double regionBoundaryThreshold = CrackRegionBoundaryRelativeThreshold * avgEdgeLen;
            
            // Check each crack node for:
            // 1. Neighbors outside active region (classic tip detection)
            // 2. The node itself being near the region boundary
            int tipByNeighbor = 0;
            int tipByBoundary = 0;
            
            foreach (int crackNode in crackNodes)
            {
                // Check 1: Is this node itself near the region boundary?
                if (regionValues[crackNode] > -regionBoundaryThreshold)
                {
                    // Node is near the crack front (boundary of ellipse, etc.)
                    if (!boundaryNodes3D.Contains(crackNode))
                    {
                        tipNodes.Add(crackNode);
                        tipByBoundary++;
                        continue;
                    }
                }
                
                // Check 2: Does this node have neighbors outside the region?
                bool hasFarNeighbor = false;
                foreach (int neighbor in nodeNeighbors[crackNode])
                {
                    if (regionValues[neighbor] > 0)
                    {
                        hasFarNeighbor = true;
                        break;
                    }
                }
                
                // If tip AND not on mesh boundary, don't duplicate
                if (hasFarNeighbor && !boundaryNodes3D.Contains(crackNode))
                {
                    tipNodes.Add(crackNode);
                    tipByNeighbor++;
                }
            }
            
            Console.WriteLine($"  → Tip detection: {tipByBoundary} by region boundary, {tipByNeighbor} by neighbor check");
        }
        
        Console.WriteLine($"  → Found {tipNodes.Count} tip nodes (will NOT be duplicated)");
        
        // Step 5: Nodes to duplicate = crack nodes - tip nodes
        var nodesToDuplicate = new HashSet<int>(crackNodes);
        nodesToDuplicate.ExceptWith(tipNodes);
        
        Console.WriteLine($"  → Will duplicate {nodesToDuplicate.Count} nodes");
        
        // DIAGNOSTIC: Print bounding box of crack nodes and nodes to duplicate
        if (nodesToDuplicate.Count > 0)
        {
            double minX = double.MaxValue, maxX = double.MinValue;
            double minY = double.MaxValue, maxY = double.MinValue;
            double minZ = double.MaxValue, maxZ = double.MinValue;
            double minRegion = double.MaxValue, maxRegion = double.MinValue;
            
            foreach (int nodeId in nodesToDuplicate)
            {
                minX = Math.Min(minX, refinedCoords[nodeId, 0]);
                maxX = Math.Max(maxX, refinedCoords[nodeId, 0]);
                minY = Math.Min(minY, refinedCoords[nodeId, 1]);
                maxY = Math.Max(maxY, refinedCoords[nodeId, 1]);
                minZ = Math.Min(minZ, refinedCoords[nodeId, 2]);
                maxZ = Math.Max(maxZ, refinedCoords[nodeId, 2]);
                minRegion = Math.Min(minRegion, regionValues[nodeId]);
                maxRegion = Math.Max(maxRegion, regionValues[nodeId]);
            }
            
            Console.WriteLine($"  → Crack bbox: X=[{minX:F2},{maxX:F2}], Y=[{minY:F2},{maxY:F2}], Z=[{minZ:F2},{maxZ:F2}]");
            Console.WriteLine($"  → Region values of crack nodes: [{minRegion:F3},{maxRegion:F3}]");
        }
        
        if (nodesToDuplicate.Count == 0)
        {
            Console.WriteLine($"  → No nodes to duplicate - returning refined mesh");
            return (refinedMesh, refinedCoords);
        }
        
        // Step 6: Create new mesh with duplicated nodes
        int totalNodes = refinedMesh.Count<Node>();
        int finalNodeCount = totalNodes + nodesToDuplicate.Count;
        var crackedMesh = new SimplexMesh();
        var crackedCoords = new double[finalNodeCount, 3];
        
        var originalMap = new Dictionary<int, int>();
        var duplicateMap = new Dictionary<int, int>();
        
        // Copy all original nodes
        for (int i = 0; i < totalNodes; i++)
        {
            int newId = crackedMesh.Add<Node>();
            originalMap[i] = newId;
            
            crackedCoords[newId, 0] = refinedCoords[i, 0];
            crackedCoords[newId, 1] = refinedCoords[i, 1];
            crackedCoords[newId, 2] = refinedCoords[i, 2];
            
            var parents = refinedMesh.Get<Node, ParentNodes>(i);
            crackedMesh.Set<Node, ParentNodes>(newId, parents);
        }

        // Create duplicates
        foreach (int nodeId in nodesToDuplicate)
        {
            int dupId = crackedMesh.Add<Node>();
            duplicateMap[nodeId] = dupId;

            crackedCoords[dupId, 0] = refinedCoords[nodeId, 0];
            crackedCoords[dupId, 1] = refinedCoords[nodeId, 1];
            crackedCoords[dupId, 2] = refinedCoords[nodeId, 2];

            var parents = refinedMesh.Get<Node, ParentNodes>(nodeId);
            crackedMesh.Set<Node, ParentNodes>(dupId, parents);
        }
        
        Console.WriteLine($"  → Created {totalNodes} original + {nodesToDuplicate.Count} duplicate nodes");
        
        // Step 7: Recreate elements - determine side based on nodes CLEARLY off the crack surface
        // CRITICAL: Avoid using nodes near the crack plane for side classification
        int elementsCreated = 0;
        int positiveSideElements = 0;
        int negativeSideElements = 0;
        int duplicatesUsed = 0;
        int classifiedByClearNode = 0;
        int classifiedByCentroid = 0;
        
        // Threshold for "clearly off the crack surface" — fraction of average edge length
        double clearThreshold = CrackRegionBoundaryRelativeThreshold * avgEdgeLen;
        
        for (int t = 0; t < refinedMesh.Count<Tet4>(); t++)
        {
            var nodes = refinedMesh.NodesOf<Tet4, Node>(t);
            var newNodes = new int[4];
            
            // Count how many nodes are crack nodes to be duplicated
            int crackNodeCount = 0;
            for (int j = 0; j < 4; j++)
            {
                if (nodesToDuplicate.Contains(nodes[j]))
                    crackNodeCount++;
            }
            
            // If element has NO crack nodes, just use originals for all
            if (crackNodeCount == 0)
            {
                for (int j = 0; j < 4; j++)
                    newNodes[j] = originalMap[nodes[j]];
                crackedMesh.Add<Tet4, Node>(newNodes[0], newNodes[1], newNodes[2], newNodes[3]);
                elementsCreated++;
                continue;
            }
            
            // VOTING-BASED ELEMENT ASSIGNMENT
            // Count positive vs negative non-crack nodes
            int positiveVotes = 0;
            int negativeVotes = 0;
            
            for (int j = 0; j < 4; j++)
            {
                int nodeId = nodes[j];
                if (!nodesToDuplicate.Contains(nodeId))
                {
                    // Non-crack node - check which side
                    if (surfaceValues[nodeId] > 0)
                        positiveVotes++;
                    else
                        negativeVotes++;
                }
            }
            
            // Assign element to majority side
            bool usePositiveSide;
            if (positiveVotes != negativeVotes)
            {
                usePositiveSide = positiveVotes > negativeVotes;
                classifiedByClearNode++;
            }
            else
            {
                // Tie or all nodes are crack nodes - use centroid
                double cx = 0, cy = 0, cz = 0;
                for (int j = 0; j < 4; j++)
                {
                    cx += refinedCoords[nodes[j], 0];
                    cy += refinedCoords[nodes[j], 1];
                    cz += refinedCoords[nodes[j], 2];
                }
                cx /= 4; cy /= 4; cz /= 4;
                usePositiveSide = signedField(cx, cy, cz) > 0;
                classifiedByCentroid++;
            }
            
            if (usePositiveSide)
                positiveSideElements++;
            else
                negativeSideElements++;
            
            // Assign nodes
            for (int j = 0; j < 4; j++)
            {
                if (!nodesToDuplicate.Contains(nodes[j]))
                {
                    // Non-crack node - use original
                    newNodes[j] = originalMap[nodes[j]];
                }
                else
                {
                    // Crack node - use duplicate for positive, original for negative
                    if (usePositiveSide)
                    {
                        newNodes[j] = duplicateMap[nodes[j]];
                        duplicatesUsed++;
                    }
                    else
                    {
                        newNodes[j] = originalMap[nodes[j]];
                    }
                }
            }
            
            crackedMesh.Add<Tet4, Node>(newNodes[0], newNodes[1], newNodes[2], newNodes[3]);
            elementsCreated++;
        }
        
        Console.WriteLine($"  → Created {elementsCreated} tetrahedra");
        Console.WriteLine($"  → Positive side: {positiveSideElements}, Negative side: {negativeSideElements}");
        Console.WriteLine($"  → Classification: {classifiedByClearNode} by clear node, {classifiedByCentroid} by centroid");
        Console.WriteLine($"  → Duplicate nodes used {duplicatesUsed} times");
        
        refinedMesh = crackedMesh;
        refinedCoords = crackedCoords;
        
        // Step 8: Validate mesh quality and fix any inverted tetrahedra in place.
        // Node duplication/reassignment for crack opening does not preserve signed volume, so the
        // cracked mesh can contain negative-Jacobian tets even though FixNegativeJacobians ran before
        // duplication. Repair them here by node permutation (this previously only warned, shipping
        // inverted elements to downstream FE assembly).
        Console.WriteLine($"  → Validating cracked mesh...");
        MeshRefinement.FixNegativeJacobians(refinedMesh, refinedCoords);
        int negativeCount = 0;
        for (int i = 0; i < refinedMesh.Count<Tet4>(); i++)
        {
            var nodes = refinedMesh.NodesOf<Tet4, Node>(i);
            double jac = ComputeTetrahedronJacobian(refinedCoords, nodes[0], nodes[1], nodes[2], nodes[3]);
            if (jac <= 0) negativeCount++;
        }

        if (negativeCount > 0)
            Console.WriteLine($"  ⚠️  WARNING: {negativeCount} elements still have non-positive Jacobian (degenerate geometry)");
        else
            Console.WriteLine($"  ✓ All elements have positive Jacobians");
        
        // OPTIONAL: 3D SMOOTHING (with boundary and crack nodes fixed)
        if (enableSmoothing)
        {
            Console.WriteLine($"  → Applying 3D smoothing (all boundaries fixed)...");
            
            var boundaryNodes = FindBoundaryNodes3D(refinedMesh);
            Console.WriteLine($"  → Fixed {boundaryNodes.Count} boundary nodes");
            
            // Build neighbor map from tetrahedra
            var nodeNeighbors = BuildNodeNeighbors(refinedMesh, refinedMesh.Count<Node>(), triangles: false);
            
            // Conservative Laplacian smoothing
            var smoothedCoords = (double[,])refinedCoords.Clone();
            int iterations = DefaultCrackSmoothingIterations;
            double relaxation = DefaultCrackSmoothingRelaxation;
            
            for (int iter = 0; iter < iterations; iter++)
            {
                var newCoords = (double[,])smoothedCoords.Clone();
                int smoothedCount = 0;
                int rejectedCount = 0;
                
                for (int nodeId = 0; nodeId < refinedMesh.Count<Node>(); nodeId++)
                {
                    if (boundaryNodes.Contains(nodeId)) continue;
                    
                    var neighbors = nodeNeighbors[nodeId];
                    if (neighbors.Count == 0) continue;
                    
                    // Compute centroid
                    double cx = 0, cy = 0, cz = 0;
                    foreach (var nbr in neighbors)
                    {
                        cx += smoothedCoords[nbr, 0];
                        cy += smoothedCoords[nbr, 1];
                        cz += smoothedCoords[nbr, 2];
                    }
                    cx /= neighbors.Count;
                    cy /= neighbors.Count;
                    cz /= neighbors.Count;
                    
                    // Conservative move
                    double newX = smoothedCoords[nodeId, 0] + relaxation * (cx - smoothedCoords[nodeId, 0]);
                    double newY = smoothedCoords[nodeId, 1] + relaxation * (cy - smoothedCoords[nodeId, 1]);
                    double newZ = smoothedCoords[nodeId, 2] + relaxation * (cz - smoothedCoords[nodeId, 2]);
                    
                    // Quality check: reject if move inverts any adjacent tet
                    bool valid = true;
                    foreach (var tetId in refinedMesh.ElementsAt<Tet4, Node>(nodeId))
                    {
                        var tn = refinedMesh.NodesOf<Tet4, Node>(tetId);
                        
                        // Temporarily update coords for this node
                        double oldX = smoothedCoords[nodeId, 0];
                        double oldY = smoothedCoords[nodeId, 1];
                        double oldZ = smoothedCoords[nodeId, 2];
                        
                        smoothedCoords[nodeId, 0] = newX;
                        smoothedCoords[nodeId, 1] = newY;
                        smoothedCoords[nodeId, 2] = newZ;
                        
                        double jac = ComputeTetrahedronJacobian(smoothedCoords, tn[0], tn[1], tn[2], tn[3]);
                        
                        // Restore
                        smoothedCoords[nodeId, 0] = oldX;
                        smoothedCoords[nodeId, 1] = oldY;
                        smoothedCoords[nodeId, 2] = oldZ;
                        
                        if (jac <= 0)
                        {
                            valid = false;
                            rejectedCount++;
                            break;
                        }
                    }
                    
                    if (valid)
                    {
                        newCoords[nodeId, 0] = newX;
                        newCoords[nodeId, 1] = newY;
                        newCoords[nodeId, 2] = newZ;
                        smoothedCount++;
                    }
                }
                
                smoothedCoords = newCoords;
                Console.WriteLine($"     Iteration {iter + 1}/{iterations}: smoothed {smoothedCount} nodes, rejected {rejectedCount}");
            }
            
            refinedCoords = smoothedCoords;
            Console.WriteLine($"  ✓ 3D smoothing complete");
        }
        
        return (refinedMesh, refinedCoords);
    }
    /// <summary>
    /// Find boundary nodes of the tetrahedra: the nodes of faces used by exactly one tetrahedron.
    /// </summary>
    public static HashSet<int> FindBoundaryNodes3D(SimplexMesh mesh)
        => mesh.FindBoundaryNodes<Tet4, Node>(3);
    
    #endregion
    
    #region Node Connectivity Helpers
    
    /// <summary>
    /// Node-to-node connectivity: for each of the <paramref name="nNodes"/> nodes, the set of
    /// nodes sharing a triangle and/or a tetrahedron with it. Each set is filled element by
    /// element in row order, so its enumeration order (which fixes the summation order of
    /// the smoothers) depends only on the mesh.
    /// </summary>
    private static List<HashSet<int>> BuildNodeNeighbors(SimplexMesh mesh, int nNodes,
        bool triangles = true, bool tetrahedra = true)
    {
        var neighbors = new List<HashSet<int>>(nNodes);
        for (var i = 0; i < nNodes; i++) neighbors.Add(new HashSet<int>());

        if (triangles)
            for (var i = 0; i < mesh.Count<Tri3>(); i++)
            {
                var nodes = mesh.NodesOf<Tri3, Node>(i);
                neighbors[nodes[0]].Add(nodes[1]);
                neighbors[nodes[0]].Add(nodes[2]);
                neighbors[nodes[1]].Add(nodes[0]);
                neighbors[nodes[1]].Add(nodes[2]);
                neighbors[nodes[2]].Add(nodes[0]);
                neighbors[nodes[2]].Add(nodes[1]);
            }

        if (tetrahedra)
            for (var i = 0; i < mesh.Count<Tet4>(); i++)
            {
                var nodes = mesh.NodesOf<Tet4, Node>(i);
                for (var j = 0; j < 4; j++)
                    for (var k = 0; k < 4; k++)
                        if (j != k) neighbors[nodes[j]].Add(nodes[k]);
            }

        return neighbors;
    }
    
    #endregion

    #region Orientation Correction

    /// <summary>Correct triangle orientations in-place to ensure CCW (positive signed area)</summary>
    private static void CorrectTriangleOrientations(SimplexMesh mesh, double[,] coords)
    {
        int flipped = 0;
        
        for (int i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var n = mesh.NodesOf<Tri3, Node>(i);
            double area2 = (coords[n[1],0] - coords[n[0],0]) * (coords[n[2],1] - coords[n[0],1]) -
                          (coords[n[1],1] - coords[n[0],1]) * (coords[n[2],0] - coords[n[0],0]);

            if (area2 < -DegenerateAreaTolerance)
            {
                // CW → CCW: swap nodes 1 and 2 (in-place)
                mesh.ReplaceElementNodes<Tri3, Node>(i, n[0], n[2], n[1]);
                flipped++;
            }
        }
        
        if (flipped > 0)
            Console.WriteLine($"  → Corrected {flipped} CW→CCW triangles");
    }

    #endregion

    // ═══════════════════════════════════════════════════════════════════════════
    // Delaunay Triangulation (was MeshGeneration)
    // ═══════════════════════════════════════════════════════════════════════════

    public static (List<(double x, double y)> points, List<(int v0, int v1, int v2)> triangles)
        DelaunayTriangulate(
            double[,] outerBoundary,
            List<double[,]>? holes = null,
            double[,]? interiorPoints = null,
            double targetEdgeLength = 0.0)
    {
        Console.WriteLine("[DelaunayTriangulation] Starting...");
        Console.WriteLine($"  Outer boundary: {outerBoundary.GetLength(0)} points");

        var outerPts = ExtractCurve2D(outerBoundary);
        var holePts = new List<List<(double x, double y)>>();

        if (holes != null)
        {
            foreach (var hole in holes) holePts.Add(ExtractCurve2D(hole));
            Console.WriteLine($"  Holes: {holePts.Count}");
        }

        var points = new List<(double x, double y)>();
        points.AddRange(outerPts);

        foreach (var hole in holePts)
            points.AddRange(hole);

        if (interiorPoints == null && targetEdgeLength > 0)
        {
            var interiorList = GenerateInteriorGrid(outerBoundary, holes, targetEdgeLength);
            points.AddRange(interiorList);
            Console.WriteLine($"  Generated {interiorList.Count} interior points");
        }
        else if (interiorPoints != null)
        {
            for (var i = 0; i < interiorPoints.GetLength(0); i++)
                points.Add((interiorPoints[i, 0], interiorPoints[i, 1]));
        }
        else
        {
            var avgEdgeLength = ComputeAverageEdgeLength(outerPts);
            var autoSpacing = avgEdgeLength * 1.5;
            var interiorList = GenerateInteriorGrid(outerBoundary, holes, autoSpacing);
            points.AddRange(interiorList);
            Console.WriteLine($"  Generated {interiorList.Count} interior points");
        }

        var totalPoints = points.Count;

        var (xMin, xMax, yMin, yMax) = ComputeBoundingBox2D(points);
        var margin = Math.Max(xMax - xMin, yMax - yMin) * 0.1;

        var superTriangle = CreateSuperTriangle(xMin - margin, xMax + margin, yMin - margin, yMax + margin);

        var st0 = points.Count;
        var st1 = st0 + 1;
        var st2 = st0 + 2;
        points.Add(superTriangle.v0);
        points.Add(superTriangle.v1);
        points.Add(superTriangle.v2);

        var triangles = new List<(int v0, int v1, int v2)> { (st0, st1, st2) };
        var circumcenters = new List<(double x, double y, double rSq)>();
        circumcenters.Add(ComputeCircumcircle(superTriangle.v0, superTriangle.v1, superTriangle.v2));

        Console.WriteLine($"  Inserting {totalPoints} points via Bowyer-Watson...");

        for (var i = 0; i < totalPoints; i++)
            AddPointBW(i, points, triangles, circumcenters);

        Console.WriteLine($"  → Triangulation complete: {triangles.Count} triangles");

        var validTriangles = triangles
            .Where(t => t.v0 < totalPoints && t.v1 < totalPoints && t.v2 < totalPoints)
            .ToList();

        validTriangles = FilterTriangles(validTriangles, points, outerPts, holePts);

        Console.WriteLine($"  → After filtering: {validTriangles.Count} triangles");

        points.RemoveRange(totalPoints, 3);

        return (points, validTriangles);
    }

    public static (SimplexMesh mesh, double[,] coords) DelaunayToSimplexMesh(
        List<(double x, double y)> points, List<(int v0, int v1, int v2)> triangles)
    {
        var mesh = new SimplexMesh();
        var coords = new double[points.Count, 3];

        mesh.WithBatch(() =>
        {
            for (int i = 0; i < points.Count; i++)
            {
                coords[i, 0] = points[i].x;
                coords[i, 1] = points[i].y;
                coords[i, 2] = 0;
                mesh.AddNode(i);
            }

            foreach (var (v0, v1, v2) in triangles)
                mesh.AddTriangle(v0, v1, v2);
        });

        return (mesh, coords);
    }

    #region Bowyer-Watson Implementation

    private static ((double x, double y) v0, (double x, double y) v1, (double x, double y) v2)
        CreateSuperTriangle(double xMin, double xMax, double yMin, double yMax)
    {
        var dx = xMax - xMin;
        var dy = yMax - yMin;
        var dMax = Math.Max(dx, dy);

        var cx = (xMin + xMax) / 2;
        var cy = (yMin + yMax) / 2;

        var scale = 3.0;
        return (
            (cx - scale * dMax, cy - scale * dMax),
            (cx + scale * dMax, cy - scale * dMax),
            (cx, cy + scale * dMax)
        );
    }

    private static (double x, double y, double rSq) ComputeCircumcircle(
        (double x, double y) p0, (double x, double y) p1, (double x, double y) p2)
    {
        var ax = p1.x - p0.x;
        var ay = p1.y - p0.y;
        var bx = p2.x - p0.x;
        var by = p2.y - p0.y;

        var d = 2 * (ax * by - ay * bx);

        if (Math.Abs(d) < Epsilon)
            return (0, 0, double.MaxValue);

        var aSq = ax * ax + ay * ay;
        var bSq = bx * bx + by * by;

        var ux = (by * aSq - ay * bSq) / d;
        var uy = (ax * bSq - bx * aSq) / d;

        return (p0.x + ux, p0.y + uy, ux * ux + uy * uy);
    }

    private static void AddPointBW(
        int pointIdx,
        List<(double x, double y)> points,
        List<(int v0, int v1, int v2)> triangles,
        List<(double x, double y, double rSq)> circumcenters)
    {
        var point = points[pointIdx];
        var badTriangles = new List<int>();

        for (var i = 0; i < triangles.Count; i++)
        {
            var (cx, cy, rSq) = circumcenters[i];
            var dx = point.x - cx;
            var dy = point.y - cy;
            var distSq = dx * dx + dy * dy;

            if (distSq < rSq - Epsilon) badTriangles.Add(i);
        }

        if (badTriangles.Count == 0) return;

        var polygon = new List<(int v0, int v1)>();

        foreach (var ti in badTriangles)
        {
            var (v0, v1, v2) = triangles[ti];
            var edges = new[] { (v0, v1), (v1, v2), (v2, v0) };

            foreach (var edge in edges)
            {
                var isShared = false;

                foreach (var tj in badTriangles)
                {
                    if (ti == tj) continue;

                    var (u0, u1, u2) = triangles[tj];

                    if (SharesEdge(edge, (u0, u1)) ||
                        SharesEdge(edge, (u1, u2)) ||
                        SharesEdge(edge, (u2, u0)))
                    {
                        isShared = true;
                        break;
                    }
                }

                if (!isShared) polygon.Add(edge);
            }
        }

        badTriangles.Sort();
        for (var i = badTriangles.Count - 1; i >= 0; i--)
        {
            var idx = badTriangles[i];
            triangles.RemoveAt(idx);
            circumcenters.RemoveAt(idx);
        }

        foreach (var (v0, v1) in polygon)
        {
            triangles.Add((pointIdx, v0, v1));
            circumcenters.Add(ComputeCircumcircle(points[pointIdx], points[v0], points[v1]));
        }
    }

    private static bool SharesEdge((int a, int b) edge1, (int a, int b) edge2)
        => (edge1.a == edge2.a && edge1.b == edge2.b) || (edge1.a == edge2.b && edge1.b == edge2.a);

    private static List<(int v0, int v1, int v2)> FilterTriangles(
        List<(int v0, int v1, int v2)> triangles,
        List<(double x, double y)> points,
        List<(double x, double y)> outerBoundary,
        List<List<(double x, double y)>> holes)
    {
        var filtered = new List<(int v0, int v1, int v2)>();

        var outerArray = ConvertToArray(outerBoundary);
        var holeArrays = holes.Select(h => ConvertToArray(h)).ToList();

        foreach (var tri in triangles)
        {
            var p0 = points[tri.v0];
            var p1 = points[tri.v1];
            var p2 = points[tri.v2];

            var centroid = ((p0.x + p1.x + p2.x) / 3.0, (p0.y + p1.y + p2.y) / 3.0);

            if (!IsPointInPolygon(centroid, outerArray))
                continue;

            var inHole = holeArrays.Any(hole => IsPointInPolygon(centroid, hole));
            if (inHole) continue;

            filtered.Add(tri);
        }

        return filtered;
    }

    public static List<(double x, double y)> GenerateInteriorGrid(
        double[,] outerBoundary, List<double[,]>? holes, double spacing)
    {
        var interiorPoints = new List<(double x, double y)>();

        var n = outerBoundary.GetLength(0);
        double minX = double.MaxValue, maxX = double.MinValue;
        double minY = double.MaxValue, maxY = double.MinValue;

        for (var i = 0; i < n; i++)
        {
            var x = outerBoundary[i, 0];
            var y = outerBoundary[i, 1];
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
        }

        var random = new Random(12345);
        var perturbation = spacing * GridPerturbationFactor;

        var rowIndex = 0;
        for (var y2 = minY + spacing; y2 < maxY; y2 += spacing * HexRowSpacing)
        {
            var xOffset = rowIndex % 2 == 1 ? spacing * 0.5 : 0.0;
            for (var x2 = minX + spacing + xOffset; x2 < maxX; x2 += spacing)
            {
                var px = x2 + (random.NextDouble() - 0.5) * 2 * perturbation;
                var py = y2 + (random.NextDouble() - 0.5) * 2 * perturbation;

                var point = (px, py);
                if (!IsPointInPolygon(point, outerBoundary))
                    continue;

                var inHole = false;
                if (holes != null)
                {
                    foreach (var hole in holes)
                    {
                        if (IsPointInPolygon(point, hole))
                        {
                            inHole = true;
                            break;
                        }
                    }
                }

                if (!inHole)
                    interiorPoints.Add(point);
            }

            rowIndex++;
        }

        return interiorPoints;
    }

    #endregion

    // ═══════════════════════════════════════════════════════════════════════════
    // Unified Mesher - High-Level Triangulation API (was UnifiedMesher)
    // ═══════════════════════════════════════════════════════════════════════════

    public static (SimplexMesh mesh, double[,] coords) Triangulate(
        double[,] boundaryCoords,
        double[,]? interiorCoords = null,
        bool refine = true,
        double maxArea = 0.0,
        double sizeGradation = 1.3,
        bool convertToQuads = true,
        bool enableSmoothing = true)
    {
        return TriangulateWithHoles(boundaryCoords, null, interiorCoords, refine, maxArea, sizeGradation,
            convertToQuads, enableSmoothing);
    }

    public static (SimplexMesh mesh, double[,] coords) TriangulateWithHoles(
        double[,] outerBoundary,
        List<double[,]>? holes = null,
        double[,]? interiorCoords = null,
        bool refine = true,
        double maxArea = 0.0,
        double sizeGradation = 1.3,
        bool convertToQuads = true,
        bool enableSmoothing = true)
    {
        Console.WriteLine("\n=== TRIANGULATION START ===");
        Console.WriteLine($"Input: {outerBoundary.GetLength(0)} boundary points");
        Console.WriteLine($"Refine: {refine}, SizeGradation: {sizeGradation}");

        if (!IsBoundaryCCW(outerBoundary))
        {
            Console.WriteLine("  Outer boundary is CW, reversing to CCW");
            outerBoundary = ReverseBoundary(outerBoundary);
        }

        var avgEdgeLength = ComputeAverageEdgeLength(outerBoundary);
        double targetEdgeLength;

        if (sizeGradation > 0)
        {
            targetEdgeLength = avgEdgeLength * sizeGradation;
            Console.WriteLine($"  Adaptive sizing: target edge = {targetEdgeLength:F4}");
        }
        else if (maxArea > 0)
        {
            targetEdgeLength = Math.Sqrt(maxArea * 2.0);
            Console.WriteLine($"  Fixed sizing: target edge = {targetEdgeLength:F4}");
        }
        else
        {
            targetEdgeLength = avgEdgeLength * 1.5;
            Console.WriteLine($"  Auto sizing: target edge = {targetEdgeLength:F4}");
        }

        var (points, triangles) = DelaunayTriangulate(outerBoundary, holes, interiorCoords, targetEdgeLength);
        var (mesh, coords) = DelaunayToSimplexMesh(points, triangles);

        Console.WriteLine($"  Initial mesh: {mesh.Count<Tri3>()} triangles");

        if (enableSmoothing && mesh.Count<Tri3>() > 0)
        {
            Console.WriteLine("  Applying CVT smoothing...");
            coords = CVTSmoothing(mesh, coords, iterations: 5);
        }

        if (convertToQuads && mesh.Count<Tri3>() > 0)
        {
            Console.WriteLine("  Converting to quad-dominant mesh...");
            (mesh, coords) = ConvertToQuads(mesh, coords, passes: 2);
        }

        var stats = ComputeQualityStatistics(mesh, coords);
        Console.WriteLine("\n=== MESH COMPLETE ===");
        Console.WriteLine(stats);

        return (mesh, coords);
    }

    public static (SimplexMesh mesh, double[,] coords) CreateRectangle(
        double xMin, double yMin, double xMax, double yMax,
        double targetEdgeLength = 0.0,
        bool convertToQuads = true)
    {
        var boundary = new double[4, 3]
        {
            { xMin, yMin, 0 },
            { xMax, yMin, 0 },
            { xMax, yMax, 0 },
            { xMin, yMax, 0 }
        };

        if (targetEdgeLength > 0)
        {
            var maxArea = 0.5 * targetEdgeLength * targetEdgeLength;
            return Triangulate(boundary, null, true, maxArea, 0, convertToQuads);
        }

        return Triangulate(boundary, null, true, 0, 1.3, convertToQuads);
    }

    public static (SimplexMesh mesh, double[,] coords) CreateFromPolygon(
        List<(double x, double y)> polygon,
        bool convertToQuads = true,
        double sizeGradation = 1.3)
    {
        var boundary = ConvertToArray(polygon, 3);
        return Triangulate(boundary, null, true, 0, sizeGradation, convertToQuads);
    }

    public static (SimplexMesh mesh, double[,] coords) CreateWithHole(
        List<(double x, double y)> outerPolygon,
        List<(double x, double y)> holePolygon,
        bool convertToQuads = true,
        double sizeGradation = 1.3)
    {
        var outer = ConvertToArray(outerPolygon, 3);
        var hole = ConvertToArray(holePolygon, 3);
        var holes = new List<double[,]> { hole };

        return TriangulateWithHoles(outer, holes, null, true, 0, sizeGradation, convertToQuads);
    }

    public static void PrintQualityReport(SimplexMesh mesh, double[,] coords, string title = "Mesh Quality Report")
    {
        Console.WriteLine($"\n=== {title} ===");

        var stats = ComputeQualityStatistics(mesh, coords);
        Console.WriteLine(stats);

        var inverted = ValidateMeshOrientation(mesh, coords, out int invertedTris, out int invertedTets);
        if (inverted > 0)
            Console.WriteLine($"WARNING: {invertedTris} inverted triangles, {invertedTets} inverted tetrahedra");
        else
            Console.WriteLine("All elements have correct orientation");

        var (degTris, degTets) = FindDegenerateElements(mesh, coords);
        if (degTris.Length > 0 || degTets.Length > 0)
            Console.WriteLine($"WARNING: {degTris.Length} degenerate triangles, {degTets.Length} degenerate tetrahedra");
        else
            Console.WriteLine("No degenerate elements");
    }

    public static (double minAngle, double maxAspectRatio, double avgAspectRatio) GetQualityMetrics(
        SimplexMesh mesh, double[,] coords)
    {
        var stats = ComputeQualityStatistics(mesh, coords);

        if (stats.TriangleCount > 0)
            return (stats.MinTriangleAngleDegrees, stats.MaxTriangleAspectRatio, stats.AvgTriangleAspectRatio);
        else if (stats.TetrahedronCount > 0)
            return (0, stats.MaxTetrahedronAspectRatio, stats.AvgTetrahedronAspectRatio);

        return (0, 0, 0);
    }

    public static void ExportToConsole(SimplexMesh mesh, double[,] coords)
    {
        Console.WriteLine("\n--- Mesh Export ---");
        Console.WriteLine($"Nodes: {mesh.Count<Node>()}");

        for (int i = 0; i < Math.Min(mesh.Count<Node>(), 10); i++)
            Console.WriteLine($"  Node {i}: ({coords[i, 0]:F4}, {coords[i, 1]:F4}, {coords[i, 2]:F4})");

        if (mesh.Count<Node>() > 10)
            Console.WriteLine($"  ... and {mesh.Count<Node>() - 10} more nodes");

        Console.WriteLine($"Triangles: {mesh.Count<Tri3>()}");
        for (int i = 0; i < Math.Min(mesh.Count<Tri3>(), 5); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            Console.WriteLine($"  Tri {i}: ({nodes[0]}, {nodes[1]}, {nodes[2]})");
        }

        Console.WriteLine($"Quads: {mesh.Count<Quad4>()}");
        Console.WriteLine($"Tetrahedra: {mesh.Count<Tet4>()}");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Mesh Smoothing (was MeshOptimization)
    // ═══════════════════════════════════════════════════════════════════════════

    // 6x the signed volume of tet (a,b,c,d) = (b-a)·((c-a)×(d-a)). If subNode is one of the four
    // node ids, its coordinates are replaced by (sx,sy,sz) (used to test a candidate smoothing move).
    private static double SignedTetVolume6(double[,] coords, int a, int b, int c, int d,
        int subNode, double sx, double sy, double sz)
    {
        double ax = a == subNode ? sx : coords[a, 0], ay = a == subNode ? sy : coords[a, 1], az = a == subNode ? sz : coords[a, 2];
        double bx = b == subNode ? sx : coords[b, 0], by = b == subNode ? sy : coords[b, 1], bz = b == subNode ? sz : coords[b, 2];
        double cx = c == subNode ? sx : coords[c, 0], cy = c == subNode ? sy : coords[c, 1], cz = c == subNode ? sz : coords[c, 2];
        double dx = d == subNode ? sx : coords[d, 0], dy = d == subNode ? sy : coords[d, 1], dz = d == subNode ? sz : coords[d, 2];
        double bax = bx - ax, bay = by - ay, baz = bz - az;
        double cax = cx - ax, cay = cy - ay, caz = cz - az;
        double dax = dx - ax, day = dy - ay, daz = dz - az;
        double crx = cay * daz - caz * day, cry = caz * dax - cax * daz, crz = cax * day - cay * dax;
        return bax * crx + bay * cry + baz * crz;
    }

    public static double[,] LaplacianSmoothing(
        SimplexMesh mesh, double[,] coords,
        int iterations = 5, HashSet<int>? fixedNodes = null,
        double relaxation = 1.0, bool keepBoundaryFixed = true)
    {
        var nNodes = coords.GetLength(0);
        var newCoords = (double[,])coords.Clone();

        var boundaryNodes = keepBoundaryFixed ? IdentifyBoundaryNodes(mesh) : new HashSet<int>();
        var allFixedNodes = new HashSet<int>(boundaryNodes);
        if (fixedNodes != null) allFixedNodes.UnionWith(fixedNodes);

        Console.WriteLine($"[LaplacianSmoothing] Starting {iterations} iterations...");
        Console.WriteLine($"[LaplacianSmoothing] Fixed nodes: {allFixedNodes.Count}/{nNodes}");

        var neighbors = BuildNodeNeighbors(mesh, nNodes);
        for (var iter = 0; iter < iterations; iter++)
        {
            var smoothedCount = 0;

            for (var nodeId = 0; nodeId < nNodes; nodeId++)
            {
                if (allFixedNodes.Contains(nodeId)) continue;

                var nodeNeighbors = neighbors[nodeId];
                if (nodeNeighbors.Count == 0) continue;

                double avgX = 0, avgY = 0, avgZ = 0;
                foreach (var neighborId in nodeNeighbors)
                {
                    avgX += newCoords[neighborId, 0];
                    avgY += newCoords[neighborId, 1];
                    avgZ += newCoords[neighborId, 2];
                }

                var count = nodeNeighbors.Count;
                avgX /= count;
                avgY /= count;
                avgZ /= count;

                var candX = newCoords[nodeId, 0] + relaxation * (avgX - newCoords[nodeId, 0]);
                var candY = newCoords[nodeId, 1] + relaxation * (avgY - newCoords[nodeId, 1]);
                var candZ = newCoords[nodeId, 2] + relaxation * (avgZ - newCoords[nodeId, 2]);

                // Reject the move if it would invert (flip the signed-volume sign of) any incident
                // tetrahedron. No-op for non-tet meshes (ElementsAt<Tet4> is then empty).
                var safe = true;
                foreach (var tetId in mesh.ElementsAt<Tet4, Node>(nodeId))
                {
                    var nd = mesh.NodesOf<Tet4, Node>(tetId);
                    var oldV = SignedTetVolume6(newCoords, nd[0], nd[1], nd[2], nd[3], -1, 0, 0, 0);
                    var newV = SignedTetVolume6(newCoords, nd[0], nd[1], nd[2], nd[3], nodeId, candX, candY, candZ);
                    if (newV == 0.0 || Math.Sign(oldV) != Math.Sign(newV)) { safe = false; break; }
                }

                if (safe)
                {
                    newCoords[nodeId, 0] = candX;
                    newCoords[nodeId, 1] = candY;
                    newCoords[nodeId, 2] = candZ;
                    smoothedCount++;
                }
            }

            if ((iter + 1) % Math.Max(1, iterations / 5) == 0 || iter == iterations - 1)
                Console.WriteLine($"[LaplacianSmoothing] Iteration {iter + 1}/{iterations}: smoothed {smoothedCount} nodes");
        }

        Console.WriteLine("[LaplacianSmoothing] Complete");
        return newCoords;
    }

    public static double[,] CVTSmoothing(
        SimplexMesh mesh, double[,] coords,
        int iterations = 5, HashSet<int>? fixedNodes = null, double relaxation = 1.0)
    {
        var nNodes = coords.GetLength(0);
        var newCoords = (double[,])coords.Clone();

        var boundaryNodes = IdentifyBoundaryNodes(mesh);
        var allFixedNodes = new HashSet<int>(boundaryNodes);
        if (fixedNodes != null) allFixedNodes.UnionWith(fixedNodes);

        Console.WriteLine($"[CVTSmoothing] Starting {iterations} iterations...");

        var nodeTris = BuildNodeToTriangles(mesh, nNodes);
        for (var iter = 0; iter < iterations; iter++)
        {
            var smoothedCount = 0;

            for (var nodeId = 0; nodeId < nNodes; nodeId++)
            {
                if (allFixedNodes.Contains(nodeId)) continue;

                var nodeTriangles = nodeTris[nodeId];
                if (nodeTriangles.Count == 0) continue;

                double totalArea = 0;
                double centroidX = 0, centroidY = 0;

                foreach (var triId in nodeTriangles)
                {
                    var nodes = mesh.NodesOf<Tri3, Node>(triId);

                    var cx = (newCoords[nodes[0], 0] + newCoords[nodes[1], 0] + newCoords[nodes[2], 0]) / 3.0;
                    var cy = (newCoords[nodes[0], 1] + newCoords[nodes[1], 1] + newCoords[nodes[2], 1]) / 3.0;

                    var area = ComputeTriangleArea(newCoords, nodes[0], nodes[1], nodes[2]);

                    totalArea += area;
                    centroidX += area * cx;
                    centroidY += area * cy;
                }

                if (totalArea > Epsilon)
                {
                    centroidX /= totalArea;
                    centroidY /= totalArea;

                    var candX = newCoords[nodeId, 0] + relaxation * (centroidX - newCoords[nodeId, 0]);
                    var candY = newCoords[nodeId, 1] + relaxation * (centroidY - newCoords[nodeId, 1]);

                    // Reject the move if it would invert (flip the signed-area sign of) any incident
                    // triangle. Sign-flip (not area<=0) so the guard is correct for CW or CCW meshes.
                    var safe = true;
                    foreach (var triId in nodeTriangles)
                    {
                        var nd = mesh.NodesOf<Tri3, Node>(triId);
                        double ox0 = newCoords[nd[0], 0], oy0 = newCoords[nd[0], 1];
                        double ox1 = newCoords[nd[1], 0], oy1 = newCoords[nd[1], 1];
                        double ox2 = newCoords[nd[2], 0], oy2 = newCoords[nd[2], 1];
                        var oldA = (ox1 - ox0) * (oy2 - oy0) - (oy1 - oy0) * (ox2 - ox0);
                        double nx0 = nd[0] == nodeId ? candX : ox0, ny0 = nd[0] == nodeId ? candY : oy0;
                        double nx1 = nd[1] == nodeId ? candX : ox1, ny1 = nd[1] == nodeId ? candY : oy1;
                        double nx2 = nd[2] == nodeId ? candX : ox2, ny2 = nd[2] == nodeId ? candY : oy2;
                        var newA = (nx1 - nx0) * (ny2 - ny0) - (ny1 - ny0) * (nx2 - nx0);
                        if (newA == 0.0 || Math.Sign(oldA) != Math.Sign(newA)) { safe = false; break; }
                    }

                    if (safe)
                    {
                        newCoords[nodeId, 0] = candX;
                        newCoords[nodeId, 1] = candY;
                        smoothedCount++;
                    }
                }
            }

            if ((iter + 1) % Math.Max(1, iterations / 5) == 0 || iter == iterations - 1)
                Console.WriteLine($"[CVTSmoothing] Iteration {iter + 1}/{iterations}: smoothed {smoothedCount} nodes");
        }

        Console.WriteLine("[CVTSmoothing] Complete");
        return newCoords;
    }

    public static (SimplexMesh mesh, double[,] coords) RemoveDegenerateTriangles(
        SimplexMesh mesh, double[,] coords, double tolerance = Epsilon)
    {
        Console.WriteLine($"[RemoveDegenerateTriangles] Checking {mesh.Count<Tri3>()} triangles...");

        var degenerateTris = new HashSet<int>();

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            if (IsTriangleDegenerate(coords, nodes[0], nodes[1], nodes[2], tolerance))
                degenerateTris.Add(i);
        }

        Console.WriteLine($"[RemoveDegenerateTriangles] Found {degenerateTris.Count} degenerate triangles");

        if (degenerateTris.Count == 0)
            return (mesh, coords);

        return RebuildMeshWithoutElements(mesh, coords, degenerateTris, new HashSet<int>());
    }

    public static (SimplexMesh mesh, double[,] coords) RemoveDegenerateTetrahedra(
        SimplexMesh mesh, double[,] coords, double tolerance = Epsilon)
    {
        Console.WriteLine($"[RemoveDegenerateTetrahedra] Checking {mesh.Count<Tet4>()} tetrahedra...");

        var degenerateTets = new HashSet<int>();

        for (var i = 0; i < mesh.Count<Tet4>(); i++)
        {
            var nodes = mesh.NodesOf<Tet4, Node>(i);
            if (IsTetrahedronDegenerate(coords, nodes[0], nodes[1], nodes[2], nodes[3], tolerance))
                degenerateTets.Add(i);
        }

        Console.WriteLine($"[RemoveDegenerateTetrahedra] Found {degenerateTets.Count} degenerate tetrahedra");

        if (degenerateTets.Count == 0)
            return (mesh, coords);

        return RebuildMeshWithoutElements(mesh, coords, new HashSet<int>(), degenerateTets);
    }

    /// <summary>
    /// Boundary nodes of a mixed mesh: the union of <see cref="FindBoundaryNodes"/> (triangles)
    /// and <see cref="FindBoundaryNodes3D"/> (tetrahedra).
    /// </summary>
    public static HashSet<int> IdentifyBoundaryNodes(SimplexMesh mesh)
    {
        var boundaryNodes = new HashSet<int>();
        if (mesh.Count<Tri3>() > 0) boundaryNodes.UnionWith(FindBoundaryNodes(mesh));
        if (mesh.Count<Tet4>() > 0) boundaryNodes.UnionWith(FindBoundaryNodes3D(mesh));
        return boundaryNodes;
    }

    private static List<HashSet<int>> BuildNodeToTriangles(SimplexMesh mesh, int nNodes)
    {
        var nodeTris = new List<HashSet<int>>(nNodes);
        for (var i = 0; i < nNodes; i++) nodeTris.Add(new HashSet<int>());

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            nodeTris[nodes[0]].Add(i);
            nodeTris[nodes[1]].Add(i);
            nodeTris[nodes[2]].Add(i);
        }

        return nodeTris;
    }

    private static (SimplexMesh mesh, double[,] coords) RebuildMeshWithoutElements(
        SimplexMesh mesh, double[,] coords,
        HashSet<int> excludeTriangles, HashSet<int> excludeTetrahedra)
    {
        var usedNodes = new HashSet<int>();

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            if (excludeTriangles.Contains(i)) continue;
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            usedNodes.Add(nodes[0]); usedNodes.Add(nodes[1]); usedNodes.Add(nodes[2]);
        }

        for (var i = 0; i < mesh.Count<Tet4>(); i++)
        {
            if (excludeTetrahedra.Contains(i)) continue;
            var nodes = mesh.NodesOf<Tet4, Node>(i);
            usedNodes.Add(nodes[0]); usedNodes.Add(nodes[1]); usedNodes.Add(nodes[2]); usedNodes.Add(nodes[3]);
        }

        for (var i = 0; i < mesh.Count<Bar2>(); i++)
        {
            var nodes = mesh.NodesOf<Bar2, Node>(i);
            usedNodes.Add(nodes[0]); usedNodes.Add(nodes[1]);
        }

        for (var i = 0; i < mesh.Count<Point>(); i++)
        {
            var nodes = mesh.NodesOf<Point, Node>(i);
            usedNodes.Add(nodes[0]);
        }

        var nodeMap = new Dictionary<int, int>();
        var newCoordsList = new List<double[]>();

        foreach (var oldId in usedNodes.OrderBy(x => x))
        {
            nodeMap[oldId] = newCoordsList.Count;
            newCoordsList.Add(new[] { coords[oldId, 0], coords[oldId, 1], coords[oldId, 2] });
        }

        var newCoords = new double[newCoordsList.Count, 3];
        for (var i = 0; i < newCoordsList.Count; i++)
        {
            newCoords[i, 0] = newCoordsList[i][0];
            newCoords[i, 1] = newCoordsList[i][1];
            newCoords[i, 2] = newCoordsList[i][2];
        }

        var newMesh = new SimplexMesh();

        newMesh.WithBatch(() =>
        {
            for (var i = 0; i < newCoordsList.Count; i++) newMesh.AddNode(i);

            for (var i = 0; i < mesh.Count<Tri3>(); i++)
            {
                if (excludeTriangles.Contains(i)) continue;
                var nodes = mesh.NodesOf<Tri3, Node>(i);
                var idx = newMesh.AddTriangle(nodeMap[nodes[0]], nodeMap[nodes[1]], nodeMap[nodes[2]]);
                var orig = mesh.Get<Tri3, OriginalElement>(i);
                newMesh.Set<Tri3, OriginalElement>(idx, orig);
            }

            for (var i = 0; i < mesh.Count<Tet4>(); i++)
            {
                if (excludeTetrahedra.Contains(i)) continue;
                var nodes = mesh.NodesOf<Tet4, Node>(i);
                var idx = newMesh.AddTetrahedron(nodeMap[nodes[0]], nodeMap[nodes[1]], nodeMap[nodes[2]], nodeMap[nodes[3]]);
                var orig = mesh.Get<Tet4, OriginalElement>(i);
                newMesh.Set<Tet4, OriginalElement>(idx, orig);
            }

            for (var i = 0; i < mesh.Count<Bar2>(); i++)
            {
                var nodes = mesh.NodesOf<Bar2, Node>(i);
                var idx = newMesh.AddBar(nodeMap[nodes[0]], nodeMap[nodes[1]]);
                var orig = mesh.Get<Bar2, OriginalElement>(i);
                newMesh.Set<Bar2, OriginalElement>(idx, orig);
            }

            for (var i = 0; i < mesh.Count<Point>(); i++)
            {
                var nodes = mesh.NodesOf<Point, Node>(i);
                var idx = newMesh.AddPoint(nodeMap[nodes[0]]);
                var orig = mesh.Get<Point, OriginalElement>(i);
                newMesh.Set<Point, OriginalElement>(idx, orig);
            }
        });

        var removedCount = excludeTriangles.Count + excludeTetrahedra.Count;
        Console.WriteLine($"[RebuildMesh] Removed {removedCount} degenerate elements");

        return (newMesh, newCoords);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Quad Conversion (was QuadConversion)
    // ═══════════════════════════════════════════════════════════════════════════

    public static (SimplexMesh mesh, double[,] coords) ConvertToQuads(
        SimplexMesh mesh, double[,] coords,
        int passes = 2, double minQualityThreshold = 0.3)
    {
        Console.WriteLine("[QuadConversion] Starting triangle-to-quad conversion...");
        Console.WriteLine($"  Input: {mesh.Count<Tri3>()} triangles");

        var adjacency = BuildTriangleAdjacency(mesh);
        var converted = new HashSet<int>();
        var quads = new List<(int n0, int n1, int n2, int n3)>();

        for (var pass = 0; pass < passes; pass++)
        {
            Console.WriteLine($"  Pass {pass + 1}/{passes}...");
            var quadsThisPass = 0;

            quadsThisPass += PairByQuality(mesh, coords, adjacency, converted, quads, minQualityThreshold);
            quadsThisPass += PairByValence(mesh, coords, adjacency, converted, quads, minQualityThreshold);
            quadsThisPass += PairByGeometry(mesh, coords, adjacency, converted, quads, minQualityThreshold);

            Console.WriteLine($"    Created {quadsThisPass} quads in pass {pass + 1}");
            if (quadsThisPass == 0) break;
        }

        Console.WriteLine($"  Total quads created: {quads.Count}");

        var newMesh = BuildQuadMesh(mesh, quads, converted);
        return (newMesh, coords);
    }

    private static Dictionary<int, List<int>> BuildTriangleAdjacency(SimplexMesh mesh)
    {
        var edgeToTriangles = new Dictionary<(int, int), List<int>>();

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            var edges = new[]
            {
                MakeEdge(nodes[0], nodes[1]),
                MakeEdge(nodes[1], nodes[2]),
                MakeEdge(nodes[2], nodes[0])
            };

            foreach (var edge in edges)
            {
                if (!edgeToTriangles.ContainsKey(edge))
                    edgeToTriangles[edge] = new List<int>();
                edgeToTriangles[edge].Add(i);
            }
        }

        var adjacency = new Dictionary<int, List<int>>();

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            adjacency[i] = new List<int>();
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            var edges = new[]
            {
                MakeEdge(nodes[0], nodes[1]),
                MakeEdge(nodes[1], nodes[2]),
                MakeEdge(nodes[2], nodes[0])
            };

            foreach (var edge in edges)
                foreach (var neighbor in edgeToTriangles[edge])
                    if (neighbor != i && !adjacency[i].Contains(neighbor))
                        adjacency[i].Add(neighbor);
        }

        return adjacency;
    }

    private static (int, int) MakeEdge(int v0, int v1) => v0 < v1 ? (v0, v1) : (v1, v0);

    private static int PairByQuality(SimplexMesh mesh, double[,] coords,
        Dictionary<int, List<int>> adjacency, HashSet<int> converted,
        List<(int, int, int, int)> quads, double minQuality)
    {
        var count = 0;
        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            if (converted.Contains(i)) continue;
            var nodesI = mesh.NodesOf<Tri3, Node>(i);
            var bestQuality = minQuality;
            var bestNeighbor = -1;
            var bestQuad = (0, 0, 0, 0);
            foreach (var j in adjacency[i])
            {
                if (converted.Contains(j)) continue;
                var nodesJ = mesh.NodesOf<Tri3, Node>(j);
                var quadNodes = TryFormQuad(nodesI, nodesJ);
                if (!quadNodes.HasValue) continue;
                var quality = ComputeQuadQuality(coords, quadNodes.Value.n0, quadNodes.Value.n1, quadNodes.Value.n2, quadNodes.Value.n3);
                if (quality > bestQuality) { bestQuality = quality; bestNeighbor = j; bestQuad = quadNodes.Value; }
            }
            if (bestNeighbor >= 0) { quads.Add(bestQuad); converted.Add(i); converted.Add(bestNeighbor); count++; }
        }
        return count;
    }

    private static int PairByValence(SimplexMesh mesh, double[,] coords,
        Dictionary<int, List<int>> adjacency, HashSet<int> converted,
        List<(int, int, int, int)> quads, double minQuality)
    {
        var valence = ComputeNodeValence(mesh, converted);
        var count = 0;
        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            if (converted.Contains(i)) continue;
            var nodesI = mesh.NodesOf<Tri3, Node>(i);
            var bestNeighbor = -1;
            var bestScore = double.MinValue;
            var bestQuad = (0, 0, 0, 0);
            foreach (var j in adjacency[i])
            {
                if (converted.Contains(j)) continue;
                var nodesJ = mesh.NodesOf<Tri3, Node>(j);
                var quadNodes = TryFormQuad(nodesI, nodesJ);
                if (!quadNodes.HasValue) continue;
                var quality = ComputeQuadQuality(coords, quadNodes.Value.n0, quadNodes.Value.n1, quadNodes.Value.n2, quadNodes.Value.n3);
                if (quality < minQuality) continue;
                double valenceScore = 0;
                var qn = new[] { quadNodes.Value.n0, quadNodes.Value.n1, quadNodes.Value.n2, quadNodes.Value.n3 };
                foreach (var node in qn) { var v = valence.GetValueOrDefault(node, 0); if (v == 3 || v == 5) valenceScore += 1.0; }
                var score = quality + 0.2 * valenceScore;
                if (score > bestScore) { bestScore = score; bestNeighbor = j; bestQuad = quadNodes.Value; }
            }
            if (bestNeighbor >= 0) { quads.Add(bestQuad); converted.Add(i); converted.Add(bestNeighbor); count++; }
        }
        return count;
    }

    private static int PairByGeometry(SimplexMesh mesh, double[,] coords,
        Dictionary<int, List<int>> adjacency, HashSet<int> converted,
        List<(int, int, int, int)> quads, double minQuality)
    {
        var count = 0;
        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            if (converted.Contains(i)) continue;
            var nodesI = mesh.NodesOf<Tri3, Node>(i);
            foreach (var j in adjacency[i])
            {
                if (converted.Contains(j)) continue;
                var nodesJ = mesh.NodesOf<Tri3, Node>(j);
                var quadNodes = TryFormQuad(nodesI, nodesJ);
                if (!quadNodes.HasValue) continue;
                var quality = ComputeQuadQuality(coords, quadNodes.Value.n0, quadNodes.Value.n1, quadNodes.Value.n2, quadNodes.Value.n3);
                if (quality >= minQuality) { quads.Add(quadNodes.Value); converted.Add(i); converted.Add(j); count++; break; }
            }
        }
        return count;
    }

    private static (int n0, int n1, int n2, int n3)? TryFormQuad(IReadOnlyList<int> tri1, IReadOnlyList<int> tri2)
    {
        var shared = FindSharedEdge(tri1, tri2);
        if (!shared.HasValue) return null;
        var (s0, s1) = shared.Value;
        int unique1 = -1, unique2 = -1;
        foreach (var v in tri1) if (v != s0 && v != s1) { unique1 = v; break; }
        foreach (var v in tri2) if (v != s0 && v != s1) { unique2 = v; break; }
        if (unique1 < 0 || unique2 < 0) return null;
        return (s0, unique1, s1, unique2);
    }

    private static (int, int)? FindSharedEdge(IReadOnlyList<int> tri1, IReadOnlyList<int> tri2)
    {
        var edges1 = new[] { MakeEdge(tri1[0], tri1[1]), MakeEdge(tri1[1], tri1[2]), MakeEdge(tri1[2], tri1[0]) };
        var edges2 = new[] { MakeEdge(tri2[0], tri2[1]), MakeEdge(tri2[1], tri2[2]), MakeEdge(tri2[2], tri2[0]) };
        foreach (var e1 in edges1) foreach (var e2 in edges2) if (e1 == e2) return e1;
        return null;
    }

    private static double ComputeQuadQuality(double[,] coords, int n0, int n1, int n2, int n3)
    {
        if (!IsQuadConvex(coords, n0, n1, n2, n3)) return 0.0;
        var e0 = EdgeLength2D(coords, n0, n1);
        var e1 = EdgeLength2D(coords, n1, n2);
        var e2 = EdgeLength2D(coords, n2, n3);
        var e3 = EdgeLength2D(coords, n3, n0);
        var minEdge = Math.Min(Math.Min(e0, e1), Math.Min(e2, e3));
        var maxEdge = Math.Max(Math.Max(e0, e1), Math.Max(e2, e3));
        if (maxEdge < Epsilon) return 0.0;
        var aspectRatio = minEdge / maxEdge;
        var angles = new[] { ComputeAngle(coords, n3, n0, n1), ComputeAngle(coords, n0, n1, n2), ComputeAngle(coords, n1, n2, n3), ComputeAngle(coords, n2, n3, n0) };
        double angleQuality = 0;
        foreach (var angle in angles) angleQuality += Math.Max(0, 1.0 - Math.Abs(angle - 90.0) / 90.0);
        angleQuality /= 4.0;
        return 0.5 * aspectRatio + 0.5 * angleQuality;
    }

    private static double ComputeAngle(double[,] coords, int a, int center, int b)
    {
        var ax = coords[a, 0] - coords[center, 0]; var ay = coords[a, 1] - coords[center, 1];
        var bx = coords[b, 0] - coords[center, 0]; var by = coords[b, 1] - coords[center, 1];
        var dot = ax * bx + ay * by;
        var lenA = Math.Sqrt(ax * ax + ay * ay); var lenB = Math.Sqrt(bx * bx + by * by);
        if (lenA < Epsilon || lenB < Epsilon) return 90.0;
        var cosAngle = Math.Clamp(dot / (lenA * lenB), -1.0, 1.0);
        return Math.Acos(cosAngle) * 180.0 / Math.PI;
    }

    private static Dictionary<int, int> ComputeNodeValence(SimplexMesh mesh, HashSet<int> excludeTriangles)
    {
        var valence = new Dictionary<int, int>();
        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            if (excludeTriangles.Contains(i)) continue;
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            foreach (var node in nodes) valence[node] = valence.GetValueOrDefault(node, 0) + 1;
        }
        return valence;
    }

    private static SimplexMesh BuildQuadMesh(SimplexMesh oldMesh, List<(int n0, int n1, int n2, int n3)> quads, HashSet<int> convertedTriangles)
    {
        var newMesh = new SimplexMesh();
        newMesh.WithBatch(() =>
        {
            for (var i = 0; i < oldMesh.Count<Node>(); i++) newMesh.AddNode(i);
            foreach (var (n0, n1, n2, n3) in quads) newMesh.AddQuad(n0, n1, n2, n3);
            for (var i = 0; i < oldMesh.Count<Tri3>(); i++)
            {
                if (convertedTriangles.Contains(i)) continue;
                var nodes = oldMesh.NodesOf<Tri3, Node>(i);
                newMesh.AddTriangle(nodes[0], nodes[1], nodes[2]);
            }
        });
        Console.WriteLine($"[QuadConversion] Built mesh: {newMesh.Count<Quad4>()} quads, {newMesh.Count<Tri3>()} triangles");
        return newMesh;
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Crack Duplication (was CrackDuplication)
    // ═══════════════════════════════════════════════════════════════════════════

    public static (SimplexMesh mesh, double[,] coords) CreateCrack(
        SimplexMesh mesh, double[,] coords,
        List<(int, int)> crackEdges,
        Func<double, double, double> levelSetFunction,
        int smoothingIterations = 5)
    {
        var originalNodeCount = mesh.Count<Node>();

        Console.WriteLine($"[CreateCrack] Refining {crackEdges.Count} crack edges...");
        var (refinedMesh, _) = Refine(mesh, crackEdges);
        var refinedCoords = InterpolateCoordinates(refinedMesh, coords);

        Console.WriteLine($"[CreateCrack] After refinement: {refinedMesh.Count<Node>()} nodes");

        var newNodes = IdentifyCrackMidpointNodes(refinedMesh, originalNodeCount);
        Console.WriteLine($"[CreateCrack] Found {newNodes.Count} new midpoint nodes");

        if (smoothingIterations > 0)
        {
            Console.WriteLine($"[CreateCrack] Smoothing mesh ({smoothingIterations} iterations)...");
            refinedCoords = LaplacianSmoothing(refinedMesh, refinedCoords, smoothingIterations, newNodes);
        }

        var tipNodes = IdentifyCrackTipNodes(refinedMesh, newNodes, crackEdges);
        Console.WriteLine($"[CreateCrack] Identified {tipNodes.Count} tip nodes (will NOT be duplicated)");

        var nodesToDuplicate = new HashSet<int>(newNodes);
        nodesToDuplicate.ExceptWith(tipNodes);

        Console.WriteLine($"[CreateCrack] Duplicating {nodesToDuplicate.Count} interior crack nodes...");

        var (crackedMesh, crackedCoords) = DuplicateCrackNodesAndAssignSides(
            refinedMesh, refinedCoords, nodesToDuplicate, newNodes, levelSetFunction);

        return RenumberCrackedMesh(crackedMesh, crackedCoords);
    }

    public static (SimplexMesh mesh, double[,] coords) CreateCrackFromRefinedMesh(
        SimplexMesh refinedMesh, double[,] refinedCoords,
        int originalNodeCount,
        List<(int, int)> crackEdges,
        Func<double, double, double> levelSetFunction,
        int smoothingIterations = 5)
    {
        Console.WriteLine("[CreateCrackFromRefinedMesh] Using pre-refined mesh with exact geometry");

        var newNodes = IdentifyCrackMidpointNodes(refinedMesh, originalNodeCount);
        Console.WriteLine($"[CreateCrackFromRefinedMesh] Found {newNodes.Count} crack nodes");

        DiagnoseCrackZeroAreaTriangles(refinedMesh, refinedCoords);

        var nodeMapping = new Dictionary<int, int>();
        (refinedMesh, refinedCoords, nodeMapping) = MergeCrackDuplicateNodes(refinedMesh, refinedCoords, newNodes);

        if (nodeMapping.Count > 0)
        {
            var updatedNewNodes = new HashSet<int>();
            foreach (var node in newNodes)
            {
                var canonical = node;
                while (nodeMapping.ContainsKey(canonical)) canonical = nodeMapping[canonical];
                updatedNewNodes.Add(canonical);
            }
            newNodes = updatedNewNodes;
        }

        (refinedMesh, refinedCoords) = RemoveDegenerateTriangles(refinedMesh, refinedCoords);

        if (smoothingIterations > 0)
        {
            refinedCoords = LaplacianSmoothing(refinedMesh, refinedCoords, smoothingIterations, newNodes);
        }

        var tipNodes = IdentifyCrackTipNodes(refinedMesh, newNodes, crackEdges);

        var nodesToDuplicate = new HashSet<int>(newNodes);
        nodesToDuplicate.ExceptWith(tipNodes);

        var (crackedMesh, crackedCoords) = DuplicateCrackNodesAndAssignSides(
            refinedMesh, refinedCoords, nodesToDuplicate, newNodes, levelSetFunction);

        return RenumberCrackedMesh(crackedMesh, crackedCoords);
    }

    private static HashSet<int> IdentifyCrackMidpointNodes(SimplexMesh mesh, int originalNodeCount)
    {
        var midpointNodes = new HashSet<int>();
        for (var i = originalNodeCount; i < mesh.Count<Node>(); i++)
        {
            var parents = mesh.Get<Node, ParentNodes>(i);
            if (parents.Parent1 != parents.Parent2) midpointNodes.Add(i);
        }
        return midpointNodes;
    }

    private static HashSet<int> IdentifyCrackTipNodes(
        SimplexMesh mesh, HashSet<int> newNodes, List<(int, int)> originalCrackEdges)
    {
        var tipNodes = new HashSet<int>();
        var refinedCrackEdges = new HashSet<(int, int)>();

        foreach (var (n0, n1) in originalCrackEdges)
        {
            var nodesOnEdge = new List<int>();
            foreach (var nodeId in newNodes)
            {
                var parents = mesh.Get<Node, ParentNodes>(nodeId);
                if ((parents.Parent1 == n0 && parents.Parent2 == n1) ||
                    (parents.Parent1 == n1 && parents.Parent2 == n0))
                    nodesOnEdge.Add(nodeId);
            }

            if (nodesOnEdge.Count > 0)
            {
                nodesOnEdge.Sort();
                for (var i = 0; i < nodesOnEdge.Count - 1; i++)
                {
                    var edge = (Math.Min(nodesOnEdge[i], nodesOnEdge[i + 1]),
                        Math.Max(nodesOnEdge[i], nodesOnEdge[i + 1]));
                    refinedCrackEdges.Add(edge);
                }
            }
        }

        var edgeCount = new Dictionary<int, int>();
        foreach (var (n0, n1) in refinedCrackEdges)
        {
            if (newNodes.Contains(n0)) edgeCount[n0] = edgeCount.GetValueOrDefault(n0, 0) + 1;
            if (newNodes.Contains(n1)) edgeCount[n1] = edgeCount.GetValueOrDefault(n1, 0) + 1;
        }

        foreach (var (nodeId, count) in edgeCount)
            if (count == 1) tipNodes.Add(nodeId);

        return tipNodes;
    }

    private static (SimplexMesh mesh, double[,] coords) DuplicateCrackNodesAndAssignSides(
        SimplexMesh mesh, double[,] coords,
        HashSet<int> nodesToDuplicate, HashSet<int> allCrackNodes,
        Func<double, double, double> levelSetFunction)
    {
        var nNodes = mesh.Count<Node>();
        var nNewNodes = nNodes + nodesToDuplicate.Count;
        var newCoords = new double[nNewNodes, 3];

        for (var i = 0; i < nNodes; i++)
        {
            newCoords[i, 0] = coords[i, 0]; newCoords[i, 1] = coords[i, 1]; newCoords[i, 2] = coords[i, 2];
        }

        var nodeDuplicates = new Dictionary<int, int>();
        var nextId = nNodes;

        foreach (var nodeId in nodesToDuplicate)
        {
            var dupId = nextId++;
            nodeDuplicates[nodeId] = dupId;
            newCoords[dupId, 0] = coords[nodeId, 0]; newCoords[dupId, 1] = coords[nodeId, 1]; newCoords[dupId, 2] = coords[nodeId, 2];
        }

        Console.WriteLine($"[DuplicateNodes] Created {nodeDuplicates.Count} duplicate nodes, total: {nNodes} -> {nNewNodes}");

        var newMesh = new SimplexMesh();
        newMesh.WithBatch(() =>
        {
            for (var i = 0; i < nNewNodes; i++) newMesh.AddNode(i);
            CopyCrackElementsWithSideAssignment(mesh, newMesh, allCrackNodes, nodeDuplicates, newCoords, levelSetFunction);
        });

        return (newMesh, newCoords);
    }

    private static void CopyCrackElementsWithSideAssignment(
        SimplexMesh mesh, SimplexMesh newMesh,
        HashSet<int> crackNodes, Dictionary<int, int> nodeDuplicates,
        double[,] coords, Func<double, double, double> levelSet)
    {
        int RemapNode(int nodeId, bool useDup)
        {
            if (useDup && nodeDuplicates.ContainsKey(nodeId)) return nodeDuplicates[nodeId];
            return nodeId;
        }

        bool ShouldUseDuplicates(IReadOnlyList<int> nodes)
        {
            for (var i = 0; i < nodes.Count; i++)
            {
                var nodeId = nodes[i];
                if (!crackNodes.Contains(nodeId))
                {
                    var phi = levelSet(coords[nodeId, 0], coords[nodeId, 1]);
                    if (phi <= 0) return false;
                }
            }
            return true;
        }

        for (var i = 0; i < mesh.Count<Point>(); i++)
        {
            var nodes = mesh.NodesOf<Point, Node>(i);
            var idx = newMesh.AddPoint(nodes[0]);
            newMesh.Set<Point, OriginalElement>(idx, mesh.Get<Point, OriginalElement>(i));
        }

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            var useDup = ShouldUseDuplicates(nodes);
            var idx = newMesh.AddTriangle(RemapNode(nodes[0], useDup), RemapNode(nodes[1], useDup), RemapNode(nodes[2], useDup));
            newMesh.Set<Tri3, OriginalElement>(idx, mesh.Get<Tri3, OriginalElement>(i));
        }

        for (var i = 0; i < mesh.Count<Tet4>(); i++)
        {
            var nodes = mesh.NodesOf<Tet4, Node>(i);
            var useDup = ShouldUseDuplicates(nodes);
            var idx = newMesh.AddTetrahedron(RemapNode(nodes[0], useDup), RemapNode(nodes[1], useDup),
                RemapNode(nodes[2], useDup), RemapNode(nodes[3], useDup));
            newMesh.Set<Tet4, OriginalElement>(idx, mesh.Get<Tet4, OriginalElement>(i));
        }
    }

    private static (SimplexMesh mesh, double[,] coords) RenumberCrackedMesh(SimplexMesh mesh, double[,] coords)
    {
        var nNodes = mesh.Count<Node>();
        var usedNodes = new HashSet<int>();

        for (var i = 0; i < mesh.Count<Tri3>(); i++) foreach (var n in mesh.NodesOf<Tri3, Node>(i)) usedNodes.Add(n);
        for (var i = 0; i < mesh.Count<Tet4>(); i++) foreach (var n in mesh.NodesOf<Tet4, Node>(i)) usedNodes.Add(n);
        for (var i = 0; i < mesh.Count<Bar2>(); i++) foreach (var n in mesh.NodesOf<Bar2, Node>(i)) usedNodes.Add(n);
        for (var i = 0; i < mesh.Count<Point>(); i++) foreach (var n in mesh.NodesOf<Point, Node>(i)) usedNodes.Add(n);

        var sortedNodes = usedNodes.OrderBy(x => x).ToList();
        var needsRenumbering = sortedNodes.Count != nNodes;

        if (!needsRenumbering)
        {
            for (int i = 0; i < sortedNodes.Count; i++)
                if (sortedNodes[i] != i) { needsRenumbering = true; break; }
        }

        if (!needsRenumbering) return (mesh, coords);

        for (int i = mesh.Count<Edge>() - 1; i >= 0; i--) mesh.Remove<Edge>(i);
        for (int i = 0; i < nNodes; i++) if (!usedNodes.Contains(i)) mesh.Remove<Node>(i);
        mesh.Compress();

        var newCoords = new double[sortedNodes.Count, 3];
        for (int i = 0; i < sortedNodes.Count; i++)
        {
            var oldId = sortedNodes[i];
            newCoords[i, 0] = coords[oldId, 0]; newCoords[i, 1] = coords[oldId, 1]; newCoords[i, 2] = coords[oldId, 2];
        }

        Console.WriteLine($"[RenumberMesh] Renumbered: {nNodes} -> {sortedNodes.Count} nodes");
        return (mesh, newCoords);
    }

    private static (SimplexMesh mesh, double[,] coords, Dictionary<int, int> mapping)
        MergeCrackDuplicateNodes(SimplexMesh mesh, double[,] coords, HashSet<int> crackNodes, double tolerance = 1e-12)
    {
        var nNodes = mesh.Count<Node>();
        var nodeMapping = new Dictionary<int, int>();
        var spatialBuckets = new Dictionary<(int, int, int), List<int>>();
        var bucketSize = Math.Max(tolerance * 100, 1e-6);

        for (var i = 0; i < nNodes; i++)
        {
            var key = ((int)Math.Floor(coords[i, 0] / bucketSize),
                       (int)Math.Floor(coords[i, 1] / bucketSize),
                       (int)Math.Floor(coords[i, 2] / bucketSize));
            if (!spatialBuckets.ContainsKey(key)) spatialBuckets[key] = new List<int>();
            spatialBuckets[key].Add(i);
        }

        var merged = new HashSet<int>();
        var mergeCount = 0;
        var tol2 = tolerance * tolerance;

        // For each node, scan its own bucket AND the 26 neighbouring buckets, so two coincident
        // nodes that straddle a bucket boundary are still compared (the previous same-bucket-only
        // scan silently missed those, leaving an unintended slit / duplicated coordinate).
        for (var id1 = 0; id1 < nNodes; id1++)
        {
            if (merged.Contains(id1)) continue;
            var bx = (int)Math.Floor(coords[id1, 0] / bucketSize);
            var by = (int)Math.Floor(coords[id1, 1] / bucketSize);
            var bz = (int)Math.Floor(coords[id1, 2] / bucketSize);
            for (var ox = -1; ox <= 1; ox++)
            for (var oy = -1; oy <= 1; oy++)
            for (var oz = -1; oz <= 1; oz++)
            {
                if (!spatialBuckets.TryGetValue((bx + ox, by + oy, bz + oz), out var bucket)) continue;
                foreach (var id2 in bucket)
                {
                    if (id2 <= id1 || merged.Contains(id2)) continue;
                    var dx = coords[id1, 0] - coords[id2, 0];
                    var dy = coords[id1, 1] - coords[id2, 1];
                    var dz = coords[id1, 2] - coords[id2, 2];
                    if (dx * dx + dy * dy + dz * dz < tol2 &&
                        !(crackNodes.Contains(id1) && crackNodes.Contains(id2)))
                    {
                        nodeMapping[id2] = id1; // id1 < id2, so id1 is canonical
                        merged.Add(id2);
                        mergeCount++;
                    }
                }
            }
        }

        if (mergeCount == 0) return (mesh, coords, nodeMapping);

        var GetCanonicalNode = (int nodeId) =>
        {
            while (nodeMapping.ContainsKey(nodeId)) nodeId = nodeMapping[nodeId];
            return nodeId;
        };

        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            var c0 = GetCanonicalNode(nodes[0]); var c1 = GetCanonicalNode(nodes[1]); var c2 = GetCanonicalNode(nodes[2]);
            if (c0 != nodes[0] || c1 != nodes[1] || c2 != nodes[2])
                mesh.ReplaceElementNodes<Tri3, Node>(i, c0, c1, c2);
        }

        for (var i = 0; i < mesh.Count<Tet4>(); i++)
        {
            var nodes = mesh.NodesOf<Tet4, Node>(i);
            var c0 = GetCanonicalNode(nodes[0]); var c1 = GetCanonicalNode(nodes[1]);
            var c2 = GetCanonicalNode(nodes[2]); var c3 = GetCanonicalNode(nodes[3]);
            if (c0 != nodes[0] || c1 != nodes[1] || c2 != nodes[2] || c3 != nodes[3])
                mesh.ReplaceElementNodes<Tet4, Node>(i, c0, c1, c2, c3);
        }

        var usedNodes = new HashSet<int>();
        for (var i = 0; i < mesh.Count<Tri3>(); i++) foreach (var n in mesh.NodesOf<Tri3, Node>(i)) usedNodes.Add(n);
        for (var i = 0; i < mesh.Count<Tet4>(); i++) foreach (var n in mesh.NodesOf<Tet4, Node>(i)) usedNodes.Add(n);

        for (int i = mesh.Count<Edge>() - 1; i >= 0; i--) mesh.Remove<Edge>(i);
        for (int i = 0; i < nNodes; i++) if (!usedNodes.Contains(i)) mesh.Remove<Node>(i);

        var sortedUsed = usedNodes.OrderBy(x => x).ToList();
        mesh.Compress();

        var newCoords = new double[sortedUsed.Count, 3];
        for (int i = 0; i < sortedUsed.Count; i++)
        {
            var oldId = sortedUsed[i];
            newCoords[i, 0] = coords[oldId, 0]; newCoords[i, 1] = coords[oldId, 1]; newCoords[i, 2] = coords[oldId, 2];
        }

        var compactMapping = new Dictionary<int, int>();
        for (int i = 0; i < sortedUsed.Count; i++) compactMapping[sortedUsed[i]] = i;

        var finalMapping = new Dictionary<int, int>();
        foreach (var (oldId, _) in nodeMapping)
        {
            var finalCanonical = GetCanonicalNode(oldId);
            if (compactMapping.ContainsKey(finalCanonical))
                finalMapping[oldId] = compactMapping[finalCanonical];
        }

        Console.WriteLine($"[MergeDuplicateNodes] Merged {mergeCount} nodes: {nNodes} -> {mesh.Count<Node>()} nodes");
        return (mesh, newCoords, finalMapping);
    }

    private static void DiagnoseCrackZeroAreaTriangles(SimplexMesh mesh, double[,] coords, double tolerance = 1e-10)
    {
        var zeroAreaCount = 0;
        for (var i = 0; i < mesh.Count<Tri3>(); i++)
        {
            var nodes = mesh.NodesOf<Tri3, Node>(i);
            if (IsTriangleDegenerate(coords, nodes[0], nodes[1], nodes[2], tolerance))
                zeroAreaCount++;
        }

        if (zeroAreaCount > 0)
            Console.WriteLine($"[Diagnostic] Found {zeroAreaCount} zero-area triangles!");
        else
            Console.WriteLine("[Diagnostic] No zero-area triangles found");
    }
}
